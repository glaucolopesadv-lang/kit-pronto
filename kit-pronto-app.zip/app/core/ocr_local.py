"""Leitura de documentos SEM internet.

1) Texto: PDF com texto (CNH digital, conta em PDF) é lido direto; foto/PDF escaneado passa pelo
   reconhecimento de texto do próprio macOS (Vision, o mesmo do "Texto ao Vivo" do iPhone).
2) Campos: regras para RG, CIN, CNH e comprovantes de residência (nome, CPF, RG, nascimento, sexo,
   naturalidade, endereço, bairro, cidade, UF, CEP)."""
import io, platform, re, unicodedata

try:   # fotos .HEIC do iPhone (no Windows)
    import pillow_heif; pillow_heif.register_heif_opener()
except Exception:
    pass

UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split()


def norm(t):
    return unicodedata.normalize('NFD', t or '').encode('ascii', 'ignore').decode().upper()


# ---------------------------------------------------------------- texto
def disponivel():
    if platform.system() == 'Windows':
        try:
            from winrt.windows.media.ocr import OcrEngine  # noqa
            return True
        except Exception:
            return False
    if platform.system() != 'Darwin':
        return False
    try:
        import Vision  # noqa
        return True
    except Exception:
        return False


def _ocr(img_bytes):
    """Reconhecimento de texto do próprio sistema: Vision no Mac, Windows.Media.Ocr no Windows."""
    if platform.system() == 'Windows':
        return _windows(img_bytes)
    return _vision(img_bytes)


def _windows(img_bytes):
    """OCR embutido no Windows 10/11 (o mesmo da Ferramenta de Captura), em português."""
    import asyncio
    from PIL import Image
    from winrt.windows.media.ocr import OcrEngine
    from winrt.windows.globalization import Language
    from winrt.windows.graphics.imaging import BitmapDecoder
    from winrt.windows.storage.streams import InMemoryRandomAccessStream, DataWriter
    im = Image.open(io.BytesIO(img_bytes)).convert('RGB')
    lim = 2600
    try:
        lim = min(lim, int(OcrEngine.max_image_dimension))
    except Exception:
        pass
    if max(im.size) > lim:
        im.thumbnail((lim, lim))
    buf = io.BytesIO(); im.save(buf, 'PNG'); dados = buf.getvalue()
    W, H = im.size

    async def ler():
        stream = InMemoryRandomAccessStream()
        w = DataWriter(stream)
        w.write_bytes(dados)
        await w.store_async()
        await w.flush_async()
        w.detach_stream()
        stream.seek(0)
        dec = await BitmapDecoder.create_async(stream)
        bmp = await dec.get_software_bitmap_async()
        eng = None
        for lg in ('pt-BR', 'pt-PT', 'pt'):
            try:
                if OcrEngine.is_language_supported(Language(lg)):
                    eng = OcrEngine.try_create_from_language(Language(lg)); break
            except Exception:
                continue
        if eng is None:
            eng = OcrEngine.try_create_from_user_profile_languages()
        if eng is None:
            raise RuntimeError('sem leitor')
        return await eng.recognize_async(bmp)

    res = asyncio.run(ler())
    itens = []
    for ln in res.lines:
        ws = list(ln.words)
        if not ws:
            continue
        rs = [w.bounding_rect for w in ws]
        top = min(r.y for r in rs); x = min(r.x for r in rs); alt = max(r.y + r.height for r in rs) - top
        itens.append((top / H, x / W, alt / H, ln.text))
    return _ordenar(itens)


def _vision(img_bytes):
    """Linhas de texto de uma imagem, em ordem de leitura (de cima para baixo, da esquerda para a direita)."""
    import Vision
    from Foundation import NSData
    dado = NSData.dataWithBytes_length_(img_bytes, len(img_bytes))
    handler = Vision.VNImageRequestHandler.alloc().initWithData_options_(dado, {})
    req = Vision.VNRecognizeTextRequest.alloc().init()
    req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)
    req.setUsesLanguageCorrection_(True)
    try:
        req.setRecognitionLanguages_(['pt-BR', 'en-US'])
    except Exception:
        pass
    ok = handler.performRequests_error_([req], None)
    if isinstance(ok, tuple):
        ok = ok[0]
    linhas = []
    for obs in (req.results() or []):
        cands = obs.topCandidates_(1)
        if not cands:
            continue
        bb = obs.boundingBox()
        topo = 1 - (bb.origin.y + bb.size.height)
        linhas.append((topo, bb.origin.x, bb.size.height, str(cands[0].string())))
    return _ordenar(linhas)


def _ordenar(itens):
    """Agrupa pedaços que estão na mesma altura numa linha só."""
    itens.sort(key=lambda t: (t[0], t[1]))
    linhas, atual, ref = [], [], None
    for topo, x, alt, txt in itens:
        if ref is not None and abs(topo - ref) > max(alt * 0.6, 0.008):
            linhas.append(atual); atual = []
        if not atual:
            ref = topo
        atual.append((x, txt))
    if atual:
        linhas.append(atual)
    return [' '.join(t for _, t in sorted(l)) for l in linhas]


def _pdf_texto(b):
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(b)) as pdf:
            out = []
            for pg in pdf.pages[:4]:
                t = pg.extract_text() or ''
                out += [l for l in t.splitlines() if l.strip()]
            return out
    except Exception:
        return []


def _pdf_imagens(b):
    try:
        import pypdfium2 as pdfium
        doc = pdfium.PdfDocument(b)
        out = []
        for i in range(min(len(doc), 3)):
            img = doc[i].render(scale=2.5).to_pil()
            buf = io.BytesIO(); img.save(buf, 'PNG'); out.append(buf.getvalue())
        return out
    except Exception:
        return []


def texto_do_arquivo(nome, b, mime):
    """Lista de linhas de texto de um arquivo (foto ou PDF)."""
    if mime == 'application/pdf':
        linhas = _pdf_texto(b)
        if sum(len(l) for l in linhas) > 80:
            return linhas
        if not disponivel():
            return linhas
        out = []
        for img in _pdf_imagens(b):
            out += _ocr(img)
        return out
    if not disponivel():
        raise RuntimeError('sem leitor')
    return _ler_foto(b)


def _qualidade(linhas):
    return sum(len(re.findall(r'[A-Za-zÀ-ú]{3,}', l)) for l in linhas)


def _ler_foto(b):
    """Foto de celular: corrige a orientação e, se vier pouco texto, tenta girada (documento fotografado de lado)."""
    try:
        from PIL import Image, ImageOps
        im = ImageOps.exif_transpose(Image.open(io.BytesIO(b))).convert('RGB')
    except Exception:
        return _ocr(b)             # HEIC e outros: o próprio sistema abre
    def jpg(img):
        buf = io.BytesIO(); img.save(buf, 'JPEG', quality=92); return buf.getvalue()
    melhor = _ocr(jpg(im)); q = _qualidade(melhor)
    if q < 12:
        for ang in (90, 270, 180):
            l = _ocr(jpg(im.rotate(ang, expand=True)))
            if _qualidade(l) > q:
                melhor, q = l, _qualidade(l)
    return melhor


# ---------------------------------------------------------------- capitalização / acentos
CIDADES = ['Mossoró', 'Areia Branca', 'Baraúna', 'Grossos', 'Tibau', 'Apodi', 'Açu', 'Assu', 'Caraúbas', 'Felipe Guerra',
           'Governador Dix-Sept Rosado', 'Upanema', 'Serra do Mel', 'Porto do Mangue', 'Itajá', 'Ipanguaçu', 'Alto do Rodrigues',
           'Pendências', 'Macau', 'Guamaré', 'Carnaubais', 'Paraú', 'Triunfo Potiguar', 'Campo Grande', 'Janduís', 'Messias Targino',
           'Patu', 'Olho d\'Água do Borges', 'Umarizal', 'Martins', 'Pau dos Ferros', 'São Miguel', 'Severiano Melo', 'Rodolfo Fernandes',
           'Itaú', 'Caicó', 'Currais Novos', 'Natal', 'Parnamirim', 'São Gonçalo do Amarante', 'Ceará-Mirim', 'Macaíba',
           'Aracati', 'Icapuí', 'Jaguaruana', 'Russas', 'Limoeiro do Norte', 'Quixeré', 'Fortaleza', 'Itaiçaba', 'Tabuleiro do Norte',
           'Morada Nova', 'Jaguaribe', 'Pereiro', 'Sousa', 'Cajazeiras', 'Pombal', 'Catolé do Rocha', 'Patos', 'João Pessoa',
           'Campina Grande', 'São Bento', 'Brejo do Cruz', 'Belém do Brejo do Cruz', 'Uiraúna']
_CID = {norm(c): c for c in CIDADES}
ESTADOS = [('RIO GRANDE DO NORTE', 'RN'), ('RIO GRANDE DO SUL', 'RS'), ('CEARA', 'CE'), ('PARAIBA', 'PB'), ('PERNAMBUCO', 'PE'),
           ('PIAUI', 'PI'), ('ALAGOAS', 'AL'), ('BAHIA', 'BA'), ('MARANHAO', 'MA'), ('SAO PAULO', 'SP'), ('RIO DE JANEIRO', 'RJ'),
           ('MINAS GERAIS', 'MG'), ('SERGIPE', 'SE'), ('DISTRITO FEDERAL', 'DF')]
_MIN = {'DE', 'DA', 'DO', 'DAS', 'DOS', 'E', 'D'}


def titulo(t):
    out = []
    for i, p in enumerate(re.split(r'(\s+)', (t or '').strip())):
        if not p.strip():
            out.append(p); continue
        n = norm(p)
        if re.fullmatch(r'[IVX]+', n) or re.fullmatch(r'[A-Z]{2}', n) and n in UFS and i > 0:
            out.append(p.upper())
        elif n in _MIN and i > 0:
            out.append(p.lower())
        else:
            out.append(p[:1].upper() + p[1:].lower())
    return ''.join(out)


def cidade_bonita(t):
    t = re.sub(r'\s+', ' ', (t or '').strip())
    return _CID.get(norm(t), titulo(t))


# ---------------------------------------------------------------- campos
RE_CPF = re.compile(r'(?<!\d)(\d{3})[\.\s]?(\d{3})[\.\s]?(\d{3})\s?[-–\.]?\s?(\d{2})(?!\d)')
RE_DATA = re.compile(r'(?<!\d)(\d{2})[/\.\-](\d{2})[/\.\-](\d{4})(?!\d)')
RE_CEP = re.compile(r'(?<!\d)(\d{2})\.?(\d{3})\s?-\s?(\d{3})(?!\d)|(?<!\d)(\d{5})(\d{3})(?!\d)')
LOGR = r'(RUA|R\.|R |AV\.?|AVENIDA|TRAVESSA|TV\.?|TRAV\.?|ALAMEDA|AL\.|ESTRADA|ESTR\.?|RODOVIA|ROD\.?|SITIO|FAZENDA|VILA|CONJUNTO|CONJ\.?|LOTEAMENTO|LOT\.?|PRACA|BECO|AREA RURAL|ZONA RURAL|COMUNIDADE|ASSENTAMENTO)'


def cpf_valido(d):
    d = re.sub(r'\D', '', d)
    if len(d) != 11 or d == d[0] * 11:
        return False
    for n in (9, 10):
        s = sum(int(d[i]) * (n + 1 - i) for i in range(n))
        if (s * 10 % 11) % 10 != int(d[n]):
            return False
    return True


def _depois(linhas, rotulo, n=2, filtro=None):
    """Texto logo depois de um rótulo: na mesma linha (se houver) ou nas próximas n linhas."""
    rx = re.compile(rotulo)
    for i, l in enumerate(linhas):
        m = rx.search(norm(l))
        if not m:
            continue
        resto = l[m.end():].strip(' :.-/|')
        cands = ([resto] if resto else []) + linhas[i + 1:i + 1 + n]
        for c in cands:
            c = c.strip(' :|')
            if c and (filtro is None or filtro(c)):
                return c
    return ''


ROTULOS = re.compile(r'\b(NOME|FILIACAO|NATURALIDADE|NASCIMENTO|DATA|CPF|REGISTRO|IDENTIDADE|DOC|ORG|EMISSOR|VALIDADE|'
                     r'HABILITACAO|CATEGORIA|ASSINATURA|SEXO|NACIONALIDADE|REPUBLICA|FEDERATIVA|BRASIL|CARTEIRA|'
                     r'SECRETARIA|SEGURANCA|DETRAN|MINISTERIO|PERMISSAO|LOCAL|EXPEDICAO|VIA|NAME|SURNAME)\b')


def _e_nome(t):
    n = norm(t)
    if ROTULOS.search(n) or re.search(r'\d', n):
        return False
    pal = [p for p in re.split(r'\s+', n) if p]
    return len(pal) >= 2 and len(n) >= 6 and all(re.fullmatch(r"[A-Z'\-]+", p) for p in pal)


def _cpf(texto):
    for m in RE_CPF.finditer(texto):
        d = ''.join(m.groups())
        if cpf_valido(d):
            return f'{d[:3]}.{d[3:6]}.{d[6:9]}-{d[9:]}'
    return ''


def _nascimento(linhas):
    for rot in (r'NASCIMENTO', r'DATA\s+DE\s+NASC', r'NASC\b'):
        alvo = _depois(linhas, rot, 2, lambda c: RE_DATA.search(c))
        m = RE_DATA.search(alvo or '')
        if m:
            return f'{m[3]}-{m[2]}-{m[1]}'
    # sem rótulo: a data mais antiga que pareça nascimento
    datas = []
    for l in linhas:
        if re.search(r'VALID|EXPED|EMISS|HABILIT|VENC|LEITURA|REFER', norm(l)):
            continue
        for m in RE_DATA.finditer(l):
            a = int(m[3])
            if 1910 <= a <= 2025 and 1 <= int(m[2]) <= 12 and 1 <= int(m[1]) <= 31:
                datas.append((a, int(m[2]), int(m[1])))
    if datas:
        a, me, d = min(datas)
        return f'{a:04d}-{me:02d}-{d:02d}'
    return ''


def _rg(linhas):
    for rot in (r'REGISTRO\s+GERAL(?!\s*-\s*CPF)', r'DOC\.?\s*(DE\s+)?IDENTIDADE', r'\bIDENTIDADE\b', r'\bR\.?G\.?\b'):
        rx = re.compile(rot)
        for i, l in enumerate(linhas):
            m = rx.search(norm(l))
            if not m:
                continue
            for c in [l[m.end():]] + linhas[i + 1:i + 3]:
                c = RE_DATA.sub(' ', c)
                for mm in re.finditer(r'(?<![\d\.])(\d[\d\.\-]{3,}[\dxX]|\d{5,})(?![\d])', c):
                    num = mm.group(1).strip('.-')
                    if cpf_valido(num) or len(re.sub(r'\D', '', num)) < 5:
                        continue
                    org = re.search(r'\b(SSP|SESP|SDS|SEDS|PC|PCRN|IGP|SSPDS|DETRAN|SJS|SESDEC|DGPC|IFP|ITEP|POLICIA\s+CIVIL)\b\s*[-/ ]?\s*([A-Z]{2})?', norm(c[mm.end():]))
                    if org:
                        uf = org.group(2) if org.group(2) in UFS else ''
                        return f'{num} {org.group(1).replace(" ", "")}{"/" + uf if uf else ""}'
                    return num
    return ''


def _genero(linhas):
    for l in linhas:
        m = re.search(r'\bSEXO\b\s*(/\s*SEX)?\s*[:\-]?\s*(MASCULINO|FEMININO|M|F)\b', norm(l))
        if m:
            return 'Feminino' if m.group(2).startswith('F') else 'Masculino'
    v = _depois(linhas, r'\bSEXO\b', 1, lambda c: re.match(r'^\s*(M|F|MASC|FEM)', norm(c)))
    n = norm(v)
    if n.startswith('F'):
        return 'Feminino'
    if n.startswith('M'):
        return 'Masculino'
    return ''


NAO_NOME = re.compile(r'\b(ESTADO|GOVERNO|DEPARTAMENTO|NACIONAL|TRANSITO|INSTITUTO|POLICIA|CIVIL|TECNICO|CIENTIFICO|PERICIA|'
                      r'PUBLICA|DEFESA|SOCIAL|CIDADES|INFRAESTRUTURA|IDENTIFICACAO|ASSINATURA|TITULAR|PORTADOR|VALIDA|'
                      r'TERRITORIO|DIRETOR|DIRETORIA|ELETRONICA|DIGITAL|QR|CODE|FILIACAO|PAI|MAE|OBSERVACOES)\b')


def _trecho_nome(t):
    """Nome no começo de um texto que o leitor juntou com outra coluna (ex.: "MARIA DA SILVA 001234567 SSP RN")."""
    pal = []
    for p in re.split(r'\s+', (t or '').strip(' :|-')):
        n = norm(p).strip(".,;")
        if not n:
            continue
        if not re.fullmatch(r"[A-Z'\-]+", n) or ROTULOS.search(n) or (len(n) == 1 and n not in ('E',)):
            break
        pal.append(p.strip(".,;"))
    while pal and norm(pal[-1]) in _MIN:
        pal.pop()
    v = ' '.join(pal)
    return v if len(pal) >= 2 and len(v) >= 6 and not NAO_NOME.search(norm(v)) else ''


def _nome(linhas):
    rot = re.compile(r'(^|\s)(\d[A-Z]?\s+)?NOME(\s+E\s+SOBRENOME|\s*/\s*NAME|\s+CIVIL|\s+SOCIAL|\s+COMPLETO)?\b')
    for i, l in enumerate(linhas):
        m = rot.search(norm(l))
        if not m or re.search(r'NOME\s+(DO|DA)\s+(PAI|MAE)|NOME\s+SOCIAL', norm(l)):
            continue
        resto = l[m.end():]
        for c in ([resto] if resto.strip(' :.-/|') else []) + linhas[i + 1:i + 4]:
            c = c.strip(' :.-/|')
            if not c:
                continue
            v = _trecho_nome(c)
            if v:
                return v
    # sem rótulo legível: primeira linha com cara de nome completo antes da filiação
    for l in linhas:
        n = norm(l)
        if re.search(r'FILIACAO|\bPAI\b|\bMAE\b', n):
            break
        if _e_nome(l) and len(l.split()) >= 3 and not NAO_NOME.search(n):
            return re.sub(r'\s+', ' ', l).strip()
    return ''


def _naturalidade(linhas):
    v = ''
    for rot in (r'NATURALIDADE', r'LOCAL.{0,12}NASCIMENTO'):
        rx = re.compile(rot)
        for i, l in enumerate(linhas):
            m = rx.search(norm(l))
            if not m:
                continue
            for c in [l[m.end():]] + linhas[i + 1:i + 3]:
                c = RE_DATA.sub(' ', c)
                c = re.sub(r'(?i)\b(DATA\s+DE\s+NASCIMENTO|NASCIMENTO|E\s+UF\s+DE)\b', ' ', c).strip(' ,:-/')
                if re.search(r'[A-Za-zÀ-ú]{3,}', c) and not ROTULOS.search(norm(c)):
                    v = c; break
            if v:
                break
        if v:
            break
    if not v:
        return ''
    m = re.match(r"^\s*([A-Za-zÀ-ú' ]+?)\s*[-/,]\s*([A-Za-z]{2})\s*$", v)
    if m and m[2].upper() in UFS:
        return f'{cidade_bonita(m[1])}-{m[2].upper()}'
    return cidade_bonita(v)


def _endereco(linhas):
    out = {'endereco': '', 'bairro': '', 'cidade': '', 'uf': '', 'cep': ''}
    # CEP + cidade/UF
    for i, l in enumerate(linhas):
        n = norm(l)
        if re.search(r'CNPJ|CPF|INSCR', n):
            continue
        m = RE_CEP.search(l)
        if not m:
            continue
        d = ''.join(g for g in m.groups() if g)
        if len(d) != 8:
            continue
        out['cep'] = f'{d[:5]}-{d[5:]}'
        # cidade / UF na mesma linha (antes ou depois do CEP) ou na linha de cima/baixo
        for c in (l, linhas[i - 1] if i else '', linhas[i + 1] if i + 1 < len(linhas) else ''):
            cn = norm(RE_CEP.sub(' ', c)).replace('CEP', ' ')
            mm = re.search(r"([A-Z][A-Z' ]{2,}?)\s*[-/,]?\s*\b(" + '|'.join(UFS) + r")\b\s*$", cn.strip())
            if mm and not re.search(LOGR, mm.group(1)):
                out['cidade'] = cidade_bonita(mm.group(1)); out['uf'] = mm.group(2); break
        # logradouro: procura nas linhas próximas, de cima para baixo
        for j in range(max(0, i - 4), min(len(linhas), i + 2)):
            nj = norm(linhas[j])
            if re.match(r'^\s*(ENDERECO\s*:?\s*)?' + LOGR, nj) and re.search(r'\d|S/?N', nj):
                out['endereco'] = titulo(re.sub(r'^\s*ENDERE[CÇ]O\s*:?\s*', '', linhas[j], flags=re.I))
                # bairro: linha seguinte ao logradouro, se não for a do CEP
                if j + 1 < len(linhas) and j + 1 != i:
                    b = linhas[j + 1].strip()
                    if b and not RE_CEP.search(b) and not re.search(r'\d{3,}', b):
                        out['bairro'] = titulo(re.sub(r'^\s*BAIRRO\s*:?\s*', '', b, flags=re.I))
                break
        if out['endereco'] or out['cidade']:
            break
    if not out['bairro']:
        v = _depois(linhas, r'\bBAIRRO\b', 1, lambda c: not re.search(r'\d{4,}', c))
        if v:
            out['bairro'] = titulo(v)
    if out['bairro'] and out['cep'] and out['bairro'] in out['cidade']:
        out['bairro'] = ''
    return out


def extrair(linhas_por_arquivo):
    """linhas_por_arquivo: [(nome, [linhas])] → dict no mesmo formato da leitura do Gemini."""
    ident, compr = [], []
    for nome, linhas in linhas_por_arquivo:
        n = norm(' '.join(linhas))
        e_ident = re.search(r'IDENTIDADE|HABILITACAO|REGISTRO GERAL|FILIACAO|NATURALIDADE|SECRETARIA DA SEGURANCA|CARTEIRA NACIONAL', n)
        e_compr = re.search(r'FATURA|CONTA DE|VENCIMENTO|CONSUMO|KWH|TOTAL A PAGAR|REFERENCIA|CLIENTE|ENERGIA|AGUA|TELEFON|INTERNET|COSERN|CAERN|ENEL|NEOENERGIA', n)
        (ident if (e_ident and not (e_compr and not e_ident)) else compr if e_compr else ident).append((nome, linhas))
    docs = []
    r = {k: '' for k in ('nome', 'cpf', 'rg', 'nascimento', 'genero', 'nacionalidade', 'naturalidade', 'nome_mae', 'nome_pai',
                         'estado_civil', 'endereco', 'bairro', 'cidade', 'uf', 'cep', 'titular_comprovante')}
    for nome, linhas in ident:
        n = norm(' '.join(linhas))
        docs.append('CNH' if 'HABILITACAO' in n else 'CIN' if 'CARTEIRA DE IDENTIDADE' in n and 'NACIONAL' in n else 'RG / Identidade')
        r['nome'] = r['nome'] or _nome(linhas)
        r['cpf'] = r['cpf'] or _cpf(' \n'.join(linhas))
        r['rg'] = r['rg'] or _rg(linhas)
        if r['rg'] and not re.search(r'[A-Z]{2,}', r['rg']):   # órgão emissor pelo cabeçalho do RG
            uf = next((u for nome_e, u in ESTADOS if nome_e in n), '')
            org = 'ITEP' if 'INSTITUTO TECNICO' in n or 'ITEP' in n else 'SSP' if 'SEGURANCA' in n else ''
            if org:
                r['rg'] = f"{r['rg']} {org}{'/' + uf if uf else ''}"
        r['nascimento'] = r['nascimento'] or _nascimento(linhas)
        r['genero'] = r['genero'] or _genero(linhas)
        r['naturalidade'] = r['naturalidade'] or _naturalidade(linhas)
        if 'BRASIL' in n or 'BRASILEIR' in n:
            r['nacionalidade'] = 'brasileiro(a)'
    for nome, linhas in compr or []:
        docs.append('Comprovante de residência')
        e = _endereco(linhas)
        for k, v in e.items():
            r[k] = r[k] or v
        if not r['nome']:
            pass
    if not compr:   # sem comprovante identificado: tenta endereço em qualquer documento
        for nome, linhas in ident:
            e = _endereco(linhas)
            for k, v in e.items():
                r[k] = r[k] or v
    if not r['cpf']:
        r['cpf'] = _cpf(' \n'.join(l for _, ls in linhas_por_arquivo for l in ls))
    return r, docs
