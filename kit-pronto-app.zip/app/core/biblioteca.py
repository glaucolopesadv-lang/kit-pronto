"""Biblioteca de modelos, timbrados, clientes e configurações.

Tudo fica em pastas comuns no computador (por padrão ~/Documents/Banco de Modelos):

  Modelos/<Categoria>/<Nome do modelo>.html   -> texto do modelo com {{campos}}
  Modelos/<Categoria>/<Nome do modelo>.json   -> ficha do modelo (campos, timbrado, fonte…)
  Timbrados/<id>/fundo.png + timbrado.json    -> papel timbrado (imagem A4) e margens
  Recursos/                                   -> ícones e imagens usados nos modelos
  Originais/                                  -> cópia dos arquivos importados, como vieram
  Gerados/AAAA-MM/                            -> cópia de cada documento baixado
  Lixeira/                                    -> modelos excluídos (podem ser recuperados)
"""
import json, os, re, shutil, unicodedata, uuid, datetime, threading

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAIZ_PROGRAMA = os.path.dirname(APP_DIR)
SEED = os.path.join(RAIZ_PROGRAMA, 'seed')

_lock = threading.RLock()


def pasta_padrao():
    env = os.environ.get('BANCO_MODELOS_DIR')
    if env:
        return os.path.expanduser(env)
    docs = os.path.join(os.path.expanduser('~'), 'Documents')
    if os.name == 'nt':
        try:   # pasta Documentos de verdade do Windows (pode estar no OneDrive ou com nome "Documentos")
            import ctypes
            buf = ctypes.create_unicode_buffer(260)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0 and buf.value:
                docs = buf.value
        except Exception:
            pass
    if not os.path.isdir(docs):
        docs = os.path.expanduser('~')
    return os.path.join(docs, 'Banco de Modelos')


DADOS = pasta_padrao()
# o que você usa fica à vista; o resto fica guardado em "Sistema"
P_MODELOS = os.path.join(DADOS, 'Modelos')
P_TIMBRADOS = os.path.join(DADOS, 'Timbrados')
P_GERADOS = os.path.join(DADOS, 'Documentos Gerados')
P_SISTEMA = os.path.join(DADOS, 'Sistema')
P_RECURSOS = os.path.join(P_SISTEMA, 'Recursos')
P_ORIGINAIS = os.path.join(P_SISTEMA, 'Originais importados')
P_LIXEIRA = os.path.join(P_SISTEMA, 'Lixeira')
P_CLIENTES = os.path.join(P_SISTEMA, 'clientes.json')
P_CONFIG = os.path.join(P_SISTEMA, 'config.json')
P_SEED_MARCA = os.path.join(P_SISTEMA, '.seed_aplicado.json')


def _migrar_organizacao():
    """Versões antigas guardavam tudo solto na pasta principal: arruma."""
    os.makedirs(P_SISTEMA, exist_ok=True)
    for velho, novo in ((os.path.join(DADOS, 'Gerados'), P_GERADOS),
                        (os.path.join(DADOS, 'Recursos'), P_RECURSOS),
                        (os.path.join(DADOS, 'Originais'), P_ORIGINAIS),
                        (os.path.join(DADOS, 'Lixeira'), P_LIXEIRA),
                        (os.path.join(DADOS, 'clientes.json'), P_CLIENTES),
                        (os.path.join(DADOS, 'config.json'), P_CONFIG),
                        (os.path.join(DADOS, '.seed_aplicado.json'), P_SEED_MARCA)):
        try:
            if os.path.exists(velho) and not os.path.exists(novo):
                shutil.move(velho, novo)
            elif os.path.isdir(velho) and os.path.isdir(novo):
                for f in os.listdir(velho):
                    if not os.path.exists(os.path.join(novo, f)):
                        shutil.move(os.path.join(velho, f), os.path.join(novo, f))
                if not os.listdir(velho):
                    os.rmdir(velho)
        except OSError:
            pass

CONFIG_PADRAO = {
    'timbrado_padrao': 'marcos-inacio-marca-dagua',
    'local_padrao': 'Mossoró/RN',
    'salvar_copia': True,
    'gemini_chave': '',
    'gemini_modelo': 'gemini-2.5-flash',
    'usar_ia_importacao': True,
    'ocr_so_local': False,
}


def agora():
    return datetime.datetime.now().replace(microsecond=0).isoformat()


def slug(txt):
    t = unicodedata.normalize('NFKD', txt or '').encode('ascii', 'ignore').decode().lower()
    t = re.sub(r'[^a-z0-9]+', '-', t).strip('-')
    return t[:70] or 'item'


def nome_seguro(txt):
    """Nome válido para arquivo/pasta no Mac e no Windows."""
    t = re.sub(r'[\\/:*?"<>|\n\r\t]+', ' ', (txt or '').strip())
    t = re.sub(r'\s+', ' ', t).strip(' .')
    return t[:120] or 'Sem nome'


def _ler_json(p, padrao=None):
    try:
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return padrao


def _gravar_json(p, dados):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(dados, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


# ------------------------------------------------------------------ inicialização
def _reparar_nomes(raiz):
    """Corrige nomes de pastas/arquivos com acento estragado (ex.: 'Procura├º├╡es' -> 'Procurações')."""
    if not os.path.isdir(raiz):
        return
    for atual, pastas, arquivos in os.walk(raiz, topdown=False):
        for n in pastas + arquivos:
            try:
                certo = n.encode('cp437').decode('utf-8')
            except (UnicodeEncodeError, UnicodeDecodeError):
                continue
            if certo != n:
                a, b = os.path.join(atual, n), os.path.join(atual, certo)
                try:
                    if os.path.exists(b) and os.path.isdir(a):
                        for f in os.listdir(a):
                            if not os.path.exists(os.path.join(b, f)):
                                shutil.move(os.path.join(a, f), os.path.join(b, f))
                        shutil.rmtree(a, ignore_errors=True)
                    elif not os.path.exists(b):
                        os.rename(a, b)
                except OSError:
                    pass


SEED_V1 = '2026-10-17T10:00:00'


def _atualizar_modelos_iniciais():
    """Atualiza os modelos que vieram com o programa, se você ainda não os editou."""
    src = os.path.join(SEED, 'Modelos')
    if not os.path.isdir(src):
        return
    atuais = {m['id']: m for m in listar_modelos()}
    for cat in os.listdir(src):
        pc = os.path.join(src, cat)
        if not os.path.isdir(pc):
            continue
        for f in os.listdir(pc):
            if not f.endswith('.json'):
                continue
            novo = _ler_json(os.path.join(pc, f), {}) or {}
            velho = atuais.get(novo.get('id'))
            if not velho:
                continue
            if int(velho.get('versao_seed', 1)) >= int(novo.get('versao_seed', 1)):
                continue
            if velho.get('atualizado') not in (velho.get('seed_atualizado', SEED_V1), velho.get('criado')):
                continue   # você editou este modelo: não mexe
            for p in _caminhos_modelo(velho):
                if os.path.exists(p):
                    os.remove(p)
            destino = os.path.join(P_MODELOS, velho['categoria'])   # mantém a pasta onde você deixou
            os.makedirs(destino, exist_ok=True)
            base = f[:-5]
            for ext in ('.json', '.html'):
                s = os.path.join(pc, base + ext)
                if os.path.exists(s):
                    shutil.copy2(s, os.path.join(destino, base + ext))


def iniciar():
    """Cria a estrutura de pastas e copia os modelos iniciais na primeira execução.
    Em execuções seguintes só acrescenta o que ainda não existir e atualiza os
    modelos iniciais que você não editou."""
    _migrar_organizacao()
    for p in (P_MODELOS, P_TIMBRADOS, P_RECURSOS, P_ORIGINAIS, P_GERADOS, P_LIXEIRA):
        os.makedirs(p, exist_ok=True)
    _reparar_nomes(P_MODELOS)
    _reparar_nomes(P_TIMBRADOS)
    _reparar_nomes(SEED)
    try:
        _atualizar_modelos_iniciais()
    except Exception:
        pass
    try:
        _esconder_linhas_antigos()
    except Exception:
        pass
    try:
        _valor_extenso_antigos()
    except Exception:
        pass
    try:
        _sem_telefone_fora_da_ficha()
    except Exception:
        pass
    marca = P_SEED_MARCA
    aplicados = set(_ler_json(marca, []) or [])
    ids = {m['id'] for m in listar_modelos()}
    tids = {t['id'] for t in listar_timbrados()}
    novos = []
    # recursos (ícones etc.)
    src = os.path.join(SEED, 'Recursos')
    if os.path.isdir(src):
        for f in os.listdir(src):
            d = os.path.join(P_RECURSOS, f)
            if not os.path.exists(d):
                shutil.copy2(os.path.join(src, f), d)
    # timbrados
    src = os.path.join(SEED, 'Timbrados')
    if os.path.isdir(src):
        for tid in os.listdir(src):
            chave = 'T:' + tid
            if tid in tids or chave in aplicados:
                continue
            shutil.copytree(os.path.join(src, tid), os.path.join(P_TIMBRADOS, tid))
            novos.append(chave)
    # modelos
    src = os.path.join(SEED, 'Modelos')
    if os.path.isdir(src):
        for cat in os.listdir(src):
            for f in os.listdir(os.path.join(src, cat)):
                if not f.endswith('.json'):
                    continue
                meta = _ler_json(os.path.join(src, cat, f), {})
                chave = 'M:' + meta.get('id', f)
                if meta.get('id') in ids or chave in aplicados:
                    continue
                destino = os.path.join(P_MODELOS, cat)
                os.makedirs(destino, exist_ok=True)
                base = f[:-5]
                for ext in ('.json', '.html'):
                    s = os.path.join(src, cat, base + ext)
                    if os.path.exists(s) and not os.path.exists(os.path.join(destino, base + ext)):
                        shutil.copy2(s, os.path.join(destino, base + ext))
                novos.append(chave)
    if novos:
        _gravar_json(marca, sorted(aplicados | set(novos)))
    if not os.path.exists(P_CONFIG):
        _gravar_json(P_CONFIG, CONFIG_PADRAO)


# ------------------------------------------------------------------ configurações
def config():
    c = dict(CONFIG_PADRAO)
    c.update(_ler_json(P_CONFIG, {}) or {})
    return c


def salvar_config(novos):
    c = config()
    for k in CONFIG_PADRAO:
        if k in novos:
            c[k] = novos[k]
    _gravar_json(P_CONFIG, c)
    return c


# ------------------------------------------------------------------ modelos
def _caminhos_modelo(meta):
    pasta = os.path.join(P_MODELOS, meta['categoria'])
    return os.path.join(pasta, meta['_arquivo'] + '.json'), os.path.join(pasta, meta['_arquivo'] + '.html')


def listar_modelos():
    out = []
    if not os.path.isdir(P_MODELOS):
        return out
    for cat in sorted(os.listdir(P_MODELOS)):
        pc = os.path.join(P_MODELOS, cat)
        if not os.path.isdir(pc) or cat.startswith('.'):
            continue
        for f in sorted(os.listdir(pc)):
            if not f.endswith('.json'):
                continue
            meta = _ler_json(os.path.join(pc, f))
            if not isinstance(meta, dict):
                continue
            meta['categoria'] = cat           # a pasta manda
            meta['_arquivo'] = f[:-5]
            meta.setdefault('nome', f[:-5])
            meta.setdefault('id', slug(f[:-5]))
            meta.setdefault('tipo', 'modelo')
            meta.setdefault('campos', [])
            out.append(meta)
    return out


def categorias():
    cats = {}
    if os.path.isdir(P_MODELOS):
        for c in os.listdir(P_MODELOS):
            if os.path.isdir(os.path.join(P_MODELOS, c)) and not c.startswith('.'):
                cats[c] = 0
    for m in listar_modelos():
        cats[m['categoria']] = cats.get(m['categoria'], 0) + 1
    return [{'nome': k, 'qtd': v} for k, v in sorted(cats.items(), key=lambda x: x[0].lower())]


def obter_modelo(mid):
    for m in listar_modelos():
        if m['id'] == mid:
            _, ph = _caminhos_modelo(m)
            m['html'] = ''
            if os.path.exists(ph):
                with open(ph, encoding='utf-8') as f:
                    m['html'] = f.read()
            return m
    return None


def modelo_completo(mid):
    """Modelo pronto para preencher. Para kits, junta os itens e unifica os campos."""
    m = obter_modelo(mid)
    if not m:
        return None
    if m.get('tipo') != 'kit':
        m['itens'] = [{'modelo': m['id'], 'timbrado': None, 'nome': m['nome'], 'html': m['html'],
                       'formato': m.get('formato', 'texto'), 'paginas': m.get('paginas'), 'caixas': m.get('caixas'),
                       'fonte': m.get('fonte'), 'tamanho': m.get('tamanho'), 'espacamento': m.get('espacamento'),
                       'rodape': m.get('rodape', ''), 'margens': m.get('margens'), 'paisagem': m.get('paisagem', False), 'genero': m.get('genero', ''),
                       'timbrado_proprio': m.get('timbrado'), 'valores_maiusculos': m.get('valores_maiusculos', False),
                       'campos_chaves': [c['chave'] for c in m.get('campos', [])]}]
        return m
    itens, campos, vistos = [], [], set()
    for it in m.get('itens', []):
        sub = obter_modelo(it.get('modelo'))
        if not sub:
            continue
        itens.append({'modelo': sub['id'], 'nome': sub['nome'], 'html': sub['html'],
                      'formato': sub.get('formato', 'texto'), 'paginas': sub.get('paginas'), 'caixas': sub.get('caixas'),
                      'timbrado': it.get('timbrado'), 'timbrado_proprio': sub.get('timbrado'),
                      'fonte': sub.get('fonte'), 'tamanho': sub.get('tamanho'), 'espacamento': sub.get('espacamento'),
                      'rodape': sub.get('rodape', ''), 'margens': sub.get('margens'), 'paisagem': sub.get('paisagem', False), 'genero': sub.get('genero', ''),
                      'valores_maiusculos': sub.get('valores_maiusculos', False),
                      'campos_chaves': [c['chave'] for c in sub.get('campos', [])]})
        for c in sub.get('campos', []):
            if c['chave'] not in vistos:
                vistos.add(c['chave'])
                campos.append(c)
    for c in m.get('campos', []):        # campos extras do próprio kit
        if c['chave'] not in vistos:
            vistos.add(c['chave']); campos.append(c)
    m['itens'] = itens
    m['campos'] = campos
    return m


def _nome_livre(categoria, nome, ignorar=None):
    pasta = os.path.join(P_MODELOS, categoria)
    base = nome_seguro(nome)
    cand, n = base, 2
    while True:
        if cand == ignorar or not os.path.exists(os.path.join(pasta, cand + '.json')):
            return cand
        cand = f'{base} ({n})'; n += 1


def salvar_modelo(meta, html=None):
    """Cria ou atualiza. meta precisa de nome e categoria. Retorna o meta salvo."""
    with _lock:
        meta = {k: v for k, v in meta.items() if not k.startswith('_') and k not in ('html', 'itens_resolvidos')}
        meta['nome'] = nome_seguro(meta.get('nome') or 'Modelo sem nome')
        meta['categoria'] = nome_seguro(meta.get('categoria') or 'Outros')
        meta.setdefault('tipo', 'modelo')
        if meta.get('formato') == 'paginas':
            try:   # campo de valor por cima do número: passa a escrever também o extenso
                from . import pdf_paginas as PP
                PP.valor_com_extenso(meta)
            except Exception:
                pass
        atual = obter_modelo(meta['id']) if meta.get('id') else None
        if not meta.get('id'):
            ids = {m['id'] for m in listar_modelos()}
            base = slug(meta['nome']); mid = base
            while mid in ids:
                mid = f'{base}-{uuid.uuid4().hex[:4]}'
            meta['id'] = mid
        meta.setdefault('criado', atual.get('criado') if atual else agora())
        meta['atualizado'] = agora()
        if atual and html is None:
            html = atual.get('html')
        # se mudou nome/categoria, remove os arquivos antigos
        if atual:
            pj, ph = _caminhos_modelo(atual)
            arquivo = _nome_livre(meta['categoria'], meta['nome'],
                                  ignorar=atual['_arquivo'] if atual['categoria'] == meta['categoria'] else None)
        else:
            arquivo = _nome_livre(meta['categoria'], meta['nome'])
        meta['nome'] = arquivo
        pasta = os.path.join(P_MODELOS, meta['categoria'])
        os.makedirs(pasta, exist_ok=True)
        _gravar_json(os.path.join(pasta, arquivo + '.json'), meta)
        if meta.get('tipo') != 'kit':
            with open(os.path.join(pasta, arquivo + '.html'), 'w', encoding='utf-8') as f:
                f.write(html or '')
        if atual and (atual['categoria'] != meta['categoria'] or atual['_arquivo'] != arquivo):
            for p in (pj, ph):
                if os.path.exists(p):
                    os.remove(p)
            _limpar_pasta_vazia(atual['categoria'])
        return obter_modelo(meta['id'])


def _limpar_pasta_vazia(cat):
    p = os.path.join(P_MODELOS, cat)
    try:
        if os.path.isdir(p) and not [f for f in os.listdir(p) if not f.startswith('.')]:
            shutil.rmtree(p)
    except OSError:
        pass


def excluir_modelo(mid):
    with _lock:
        m = obter_modelo(mid)
        if not m:
            return False
        dest = os.path.join(P_LIXEIRA, datetime.date.today().isoformat())
        os.makedirs(dest, exist_ok=True)
        for p in _caminhos_modelo(m):
            if os.path.exists(p):
                shutil.move(p, os.path.join(dest, os.path.basename(p)))
        return True


def duplicar_modelo(mid):
    m = obter_modelo(mid)
    if not m:
        return None
    novo = {k: v for k, v in m.items() if k not in ('id', '_arquivo', 'html', 'criado')}
    novo['nome'] = m['nome'] + ' (cópia)'
    return salvar_modelo(novo, m.get('html', ''))


def criar_categoria(nome):
    p = os.path.join(P_MODELOS, nome_seguro(nome))
    os.makedirs(p, exist_ok=True)
    return nome_seguro(nome)


def renomear_categoria(de, para):
    with _lock:
        para = nome_seguro(para)
        a, b = os.path.join(P_MODELOS, de), os.path.join(P_MODELOS, para)
        if not os.path.isdir(a):
            raise ValueError('Pasta não encontrada')
        if os.path.exists(b) and os.path.normcase(a) != os.path.normcase(b):
            # junta as duas pastas
            for f in os.listdir(a):
                alvo = os.path.join(b, f)
                if os.path.exists(alvo):
                    r, e = os.path.splitext(f); alvo = os.path.join(b, f'{r} ({uuid.uuid4().hex[:3]}){e}')
                shutil.move(os.path.join(a, f), alvo)
            shutil.rmtree(a, ignore_errors=True)
        else:
            tmp = a + '.__tmp'
            os.rename(a, tmp); os.rename(tmp, b)
        return para


# ------------------------------------------------------------------ timbrados
def listar_timbrados():
    out = []
    if not os.path.isdir(P_TIMBRADOS):
        return out
    for tid in sorted(os.listdir(P_TIMBRADOS)):
        meta = _ler_json(os.path.join(P_TIMBRADOS, tid, 'timbrado.json'))
        if isinstance(meta, dict):
            meta['id'] = tid
            meta.setdefault('margens', {'sup': 3, 'inf': 2.5, 'esq': 2.5, 'dir': 2.5})
            meta['tem_fundo'] = os.path.exists(os.path.join(P_TIMBRADOS, tid, 'fundo.png'))
            out.append(meta)
    pad = config().get('timbrado_padrao')
    for t in out:
        t['padrao'] = (t['id'] == pad)
    return sorted(out, key=lambda t: (not t['padrao'], t['nome'].lower()))


def obter_timbrado(tid):
    for t in listar_timbrados():
        if t['id'] == tid:
            return t
    return None


def caminho_fundo(tid):
    p = os.path.join(P_TIMBRADOS, tid, 'fundo.png')
    return p if os.path.exists(p) else None


def salvar_timbrado(tid, dados):
    with _lock:
        p = os.path.join(P_TIMBRADOS, tid, 'timbrado.json')
        meta = _ler_json(p, {}) or {}
        for k in ('nome', 'margens', 'descricao'):
            if k in dados:
                meta[k] = dados[k]
        meta['id'] = tid
        _gravar_json(p, meta)
        if dados.get('padrao'):
            salvar_config({'timbrado_padrao': tid})
        return obter_timbrado(tid)


def criar_timbrado(nome, imagem_png_bytes, margens, origem=''):
    with _lock:
        ids = {t['id'] for t in listar_timbrados()}
        base = slug(nome); tid = base
        while tid in ids:
            tid = f'{base}-{uuid.uuid4().hex[:4]}'
        pasta = os.path.join(P_TIMBRADOS, tid)
        os.makedirs(pasta, exist_ok=True)
        with open(os.path.join(pasta, 'fundo.png'), 'wb') as f:
            f.write(imagem_png_bytes)
        _gravar_json(os.path.join(pasta, 'timbrado.json'),
                     {'id': tid, 'nome': nome, 'margens': margens, 'origem': origem, 'criado': agora()})
        return obter_timbrado(tid)


def excluir_timbrado(tid):
    with _lock:
        p = os.path.join(P_TIMBRADOS, tid)
        if os.path.isdir(p):
            dest = os.path.join(P_LIXEIRA, datetime.date.today().isoformat(), 'timbrado-' + tid)
            if os.path.exists(dest):
                shutil.rmtree(dest)
            shutil.move(p, dest)
            return True
        return False


# ------------------------------------------------------------------ clientes
def listar_clientes():
    return _ler_json(P_CLIENTES, []) or []


def salvar_cliente(nome, dados, cid=None, doc=None):
    """doc (opcional): o documento que estava aberto — modelo + todos os valores — para abrir de novo depois."""
    with _lock:
        lst = listar_clientes()
        dados = {k: v for k, v in (dados or {}).items() if v not in (None, '', False)}
        alvo = None
        for c in lst:
            if (cid and c['id'] == cid) or (not cid and c['nome'].strip().lower() == nome.strip().lower()):
                alvo = c; break
        if alvo:
            alvo['nome'] = nome; alvo['dados'].update(dados); alvo['atualizado'] = agora()
        else:
            alvo = {'id': uuid.uuid4().hex[:10], 'nome': nome, 'dados': dados, 'criado': agora(), 'atualizado': agora()}
            lst.append(alvo)
        if doc and doc.get('modelo'):
            docs = [x for x in alvo.get('docs') or [] if x.get('modelo') != doc['modelo']]
            docs.insert(0, {'modelo': doc['modelo'], 'nome': doc.get('nome') or '', 'valores': doc.get('valores') or {},
                            'ajustes': doc.get('ajustes') or {}, 'kit_on': doc.get('kit_on'), 'salvo': agora()})
            alvo['docs'] = docs[:30]
        lst.sort(key=lambda c: c['nome'].lower())
        _gravar_json(P_CLIENTES, lst)
        return alvo


def excluir_doc_cliente(cid, modelo):
    with _lock:
        lst = listar_clientes()
        for c in lst:
            if c['id'] == cid:
                c['docs'] = [x for x in c.get('docs') or [] if x.get('modelo') != modelo]
        _gravar_json(P_CLIENTES, lst)


def excluir_cliente(cid):
    with _lock:
        lst = [c for c in listar_clientes() if c['id'] != cid]
        _gravar_json(P_CLIENTES, lst)


# ------------------------------------------------------------------ originais e gerados
def guardar_original(nome_arquivo, conteudo):
    os.makedirs(P_ORIGINAIS, exist_ok=True)
    nome = f"{datetime.date.today().isoformat()} - {nome_seguro(nome_arquivo)}"
    p = os.path.join(P_ORIGINAIS, nome)
    with open(p, 'wb') as f:
        f.write(conteudo)
    return nome


def pasta_gerados(cliente=None, subpasta=None):
    """Documentos Gerados/<Nome do cliente>/[subpasta]; sem cliente, vai para Documentos Gerados/AAAA-MM."""
    cli = nome_seguro((cliente or '').strip())[:80].strip(' .') if cliente else ''
    pasta = os.path.join(P_GERADOS, cli) if cli else os.path.join(P_GERADOS, datetime.date.today().strftime('%Y-%m'))
    if subpasta:
        pasta = os.path.join(pasta, nome_seguro(subpasta)[:90].strip(' .'))
    return pasta


def guardar_gerado(nome_arquivo, conteudo, cliente=None, subpasta=None):
    if not config().get('salvar_copia', True):
        return None
    pasta = pasta_gerados(cliente, subpasta)
    os.makedirs(pasta, exist_ok=True)
    base, ext = os.path.splitext(nome_seguro(nome_arquivo))
    p = os.path.join(pasta, base + ext); n = 2
    while os.path.exists(p):
        p = os.path.join(pasta, f'{base} ({n}){ext}'); n += 1
    with open(p, 'wb') as f:
        f.write(conteudo)
    return p


def salvar_paginas_modelo(mid, imagens_png):
    """Grava as imagens das páginas de um modelo 'PDF original'. Retorna a lista de páginas."""
    pasta = os.path.join(P_RECURSOS, 'paginas', mid)
    os.makedirs(pasta, exist_ok=True)
    out = []
    for i, (png, (w, h)) in enumerate(imagens_png):
        nome = f'p{i + 1}.png'
        with open(os.path.join(pasta, nome), 'wb') as f:
            f.write(png)
        out.append({'img': f'recursos/paginas/{mid}/{nome}', 'w': w, 'h': h})
    return out


def _sem_telefone_fora_da_ficha():
    """O telefone do cliente só vai na ficha: sai da qualificação de contratos, procurações etc."""
    for m in listar_modelos():
        if m.get('tipo') == 'kit' or m.get('categoria') == 'Fichas e Cadastros' or re.search(r'registro do cliente|ficha', (m.get('nome') or '').lower()):
            continue
        m = obter_modelo(m['id']) or m
        html = m.get('html') or ''
        novo = re.sub(r'<span data-se="cliente_telefone">\s*,\s*telefone\s*\{\{\s*cliente_telefone\s*\}\}\s*</span>', '', html)
        novo = re.sub(r',?\s*telefone:?\s*\{\{\s*cliente_telefone\s*\}\}', '', novo)
        mudou = novo != html
        for cx in m.get('caixas') or []:
            t = cx.get('texto') or ''
            t2 = re.sub(r',?\s*telefone:?\s*\{\{\s*cliente_telefone\s*\}\}', '', t)
            if t2 != t:
                cx['texto'] = t2; mudou = True
        if not mudou:
            continue
        meta = {kk: v for kk, v in m.items() if not kk.startswith('_')}
        usa = 'cliente_telefone' in novo or any('cliente_telefone' in (c.get('texto') or '') for c in meta.get('caixas') or []) \
            or 'cliente_telefone' in (meta.get('rodape') or '')
        if not usa:
            meta['campos'] = [c for c in meta.get('campos') or [] if c.get('chave') != 'cliente_telefone']
        salvar_modelo(meta, novo)


def _valor_extenso_antigos():
    """Modelos 'PDF original' com caixa de valor só por cima do número: inclui o extenso."""
    from . import pdf_paginas as PP
    for m in listar_modelos():
        if m.get('formato') != 'paginas':
            continue
        meta = {kk: v for kk, v in m.items() if not kk.startswith('_')}
        if PP.valor_com_extenso(meta):
            salvar_modelo(meta, m.get('html', ''))


def _esconder_linhas_antigos():
    """Modelos 'PDF original' importados antes da v1.5: esconde as linhas de preencher à mão."""
    from . import pdf_paginas as PP
    from PIL import Image
    for m in listar_modelos():
        if m.get('formato') != 'paginas' or m.get('versao_cobertura'):
            continue
        imgs = []
        for pg in m.get('paginas') or []:
            caminho = os.path.join(P_RECURSOS, pg['img'][len('recursos/'):])
            imgs.append(Image.open(caminho).convert('RGB') if os.path.exists(caminho) else None)
        if not imgs or None in imgs:
            continue
        k = imgs[0].width / float((m['paginas'][0].get('w') or 595.3))
        for cx in m.get('caixas') or []:
            if cx.get('origem') is None and not cx.get('recuo'):
                txt = cx.get('texto') or ''
                if m.get('valores_maiusculos') or txt.startswith('{{marcar_'):
                    cx['origem'] = 'form'
                elif cx.get('alinhar') == 'centro' and cx.get('negrito') and txt == '{{cliente_nome}}':
                    cx['origem'] = 'assinatura'
                else:
                    cx['origem'] = 'linha'
        PP.aplicar_cobertura(m.get('caixas') or [], imgs, k)
        meta = {kk: v for kk, v in m.items() if not kk.startswith('_')}
        meta['versao_cobertura'] = 1
        salvar_modelo(meta, m.get('html', ''))
