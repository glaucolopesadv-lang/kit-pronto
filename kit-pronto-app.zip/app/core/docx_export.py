"""Converte o documento preenchido (HTML simples, já com os valores) em arquivo Word (.docx).

O papel timbrado entra como imagem de página inteira atrás do texto (no cabeçalho de cada seção),
assim fica idêntico ao PDF e repete em todas as páginas. Cada item de um kit vira uma seção
própria (com o seu timbrado, margens, rodapé e numeração de página).
"""
import base64, copy, io, os, re
from lxml import html as LH, etree
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Cm, Mm, RGBColor, Emu

from . import biblioteca as B

# Espelho de static/documento.css (mesmas classes).
CLASSES = {
    'centro': {'text-align': 'center'}, 'direita': {'text-align': 'right'},
    'esquerda': {'text-align': 'left'}, 'justificado': {'text-align': 'justify'},
    'titulo': {'text-align': 'center', 'font-weight': 'bold', 'font-size': '13pt', 'margin-bottom': '24pt'},
    'titulo-grande': {'text-align': 'center', 'font-weight': 'bold', 'font-size': '20pt', 'margin-bottom': '30pt'},
    'titulo-kit': {'color': '#EA581C', 'font-size': '17pt', 'margin-bottom': '0', 'line-height': '1.15', 'text-align': 'left'},
    'subtitulo-kit': {'color': '#EA581C', 'font-size': '9.5pt', 'margin-bottom': '0', 'text-align': 'left', 'line-height': '1.2'},
    'sec-tit': {'color': '#EA581C', 'font-weight': 'bold', 'font-size': '10.5pt', 'margin-bottom': '2pt', 'text-align': 'left', 'line-height': '1.25'},
    'pequeno': {'font-size': '9pt'}, 'mini': {'font-size': '7.5pt'},
    'laranja': {'color': '#EA581C'}, 'cinza': {'color': '#7F7F7F'}, 'negrito': {'font-weight': 'bold'},
    'lado': {'background': '#D9D9D9', 'width': '9mm', 'text-align': 'center', 'vertical-align': 'middle'},
    'corpo': {'background': '#F2F2F2'}, 'corpo-claro': {'background': '#F7F7F7'},
    'rot': {'font-size': '8pt', 'color': '#555555'},
    'info': {'background': '#D9D9D9', 'font-size': '7.5pt', 'color': '#444444', 'vertical-align': 'middle', 'text-align': 'left', 'line-height': '1.25'},
    'mono': {'font-family': 'Courier New', 'font-size': '10pt', 'line-height': '1.3', 'background': '#F5F5F5', 'text-align': 'left'},
    'assinatura': {'border-top': '0.75pt solid #000', 'margin-top': '34pt', 'margin-left': '15%', 'margin-right': '15%',
                   'text-align': 'center', 'line-height': '1.25'},
    'assinatura-esq': {'border-top': '0.75pt solid #000', 'margin-top': '30pt', 'margin-right': '45%', 'text-align': 'left', 'line-height': '1.25'},
    'vazio': {'margin-bottom': '0'},
}
HERDA = ('color', 'font-size', 'font-weight', 'font-style', 'text-align', 'line-height', 'font-family',
         'text-decoration', 'text-transform')
BLOCOS = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'table', 'ul', 'ol', 'li', 'hr', 'blockquote', 'section'}
TAM_H = {'h1': '16pt', 'h2': '14pt', 'h3': '12.5pt', 'h4': '12pt', 'h5': '11pt', 'h6': '10pt'}
ALINHA = {'center': WD_ALIGN_PARAGRAPH.CENTER, 'right': WD_ALIGN_PARAGRAPH.RIGHT,
          'left': WD_ALIGN_PARAGRAPH.LEFT, 'justify': WD_ALIGN_PARAGRAPH.JUSTIFY}


# ------------------------------------------------------------------ utilidades de estilo
def parse_style(s):
    out = {}
    for parte in (s or '').split(';'):
        if ':' in parte:
            k, v = parte.split(':', 1)
            out[k.strip().lower()] = v.strip()
    return out


def estilo_proprio(el):
    st = {}
    tag = el.tag if isinstance(el.tag, str) else ''
    if tag in TAM_H:
        st.update({'font-weight': 'bold', 'font-size': TAM_H[tag], 'margin-bottom': '8pt'})
    if tag in ('b', 'strong', 'th'):
        st['font-weight'] = 'bold'
    if tag in ('i', 'em'):
        st['font-style'] = 'italic'
    if tag == 'u':
        st['text-decoration'] = 'underline'
    for c in (el.get('class') or '').split():
        st.update(CLASSES.get(c, {}))
    st.update(parse_style(el.get('style')))
    if 'background-color' in st:
        st['background'] = st['background-color']
    return st


def herdar(pai, el):
    st = {k: v for k, v in pai.items() if k in HERDA}
    st.update(estilo_proprio(el))
    return st


def comp_pt(v, base_pt=None):
    """'9pt' '12px' '5mm' '1cm' '1.2em' -> pontos (float)."""
    if v is None:
        return None
    v = str(v).strip().lower()
    m = re.match(r'^(-?[\d.]+)\s*(pt|px|mm|cm|em|%)?$', v)
    if not m:
        return None
    n = float(m.group(1)); u = m.group(2) or 'px'
    if u == 'pt': return n
    if u == 'px': return n * 0.75
    if u == 'mm': return n * 72 / 25.4
    if u == 'cm': return n * 72 / 2.54
    if u == 'em': return n * (base_pt or 12)
    if u == '%': return None
    return None


def cor(v):
    if not v:
        return None
    v = v.strip().lower()
    nomes = {'black': '000000', 'white': 'FFFFFF', 'red': 'FF0000', 'gray': '808080', 'grey': '808080'}
    if v in nomes:
        return nomes[v]
    m = re.match(r'^#([0-9a-f]{3}|[0-9a-f]{6})$', v)
    if m:
        h = m.group(1)
        return (''.join(c * 2 for c in h) if len(h) == 3 else h).upper()
    m = re.match(r'rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)', v)
    if m:
        return '%02X%02X%02X' % tuple(int(x) for x in m.groups())
    return None


def borda(v):
    """'0.5pt solid #000' -> (tamanho em 1/8 pt, cor)"""
    if not v or v.strip() in ('none', '0'):
        return None
    w = 0.5; c = '000000'
    for p in v.split():
        if comp_pt(p) is not None:
            w = comp_pt(p)
        elif cor(p):
            c = cor(p)
    return max(2, int(round(w * 8))), c


def sombrear(elem_pr, hexcor):
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), hexcor)
    elem_pr.append(shd)


# ------------------------------------------------------------------ conversor
class Conversor:
    def __init__(self, doc, largura_pt, fonte, tamanho, espacamento):
        self.doc = doc
        self.largura = largura_pt
        self.base = {'font-family': fonte, 'font-size': f'{tamanho}pt', 'line-height': str(espacamento),
                     'text-align': 'justify', 'color': '#000000'}

    # --- blocos
    def blocos(self, el, alvo, st, largura, em_celula=False):
        """Converte os filhos de `el` (elemento lxml) em parágrafos/tabelas dentro de `alvo`."""
        pendentes = []  # inline acumulado (texto solto, spans...)

        def descarregar():
            if pendentes:
                if any((n.strip() if isinstance(n, str) else True) for n in pendentes):
                    self.paragrafo(pendentes, alvo, st, largura, em_celula=em_celula, implicito=True)
                pendentes.clear()

        if el.text:
            pendentes.append(el.text)
        for filho in el:
            tag = filho.tag if isinstance(filho.tag, str) else ''
            if tag in BLOCOS:
                descarregar()
                self.bloco(filho, alvo, st, largura, em_celula)
            elif tag:
                pendentes.append(filho)
            if filho.tail:
                pendentes.append(filho.tail)
        descarregar()

    def bloco(self, el, alvo, pai_st, largura, em_celula):
        tag = el.tag
        st = herdar(pai_st, el)
        classes = (el.get('class') or '').split()
        if 'quebra-pagina' in classes or tag == 'hr':
            p = alvo.add_paragraph()
            p.add_run().add_break(WD_BREAK.PAGE)
            return
        if tag == 'table':
            self.tabela(el, alvo, st, largura)
            return
        if tag in ('ul', 'ol'):
            for i, li in enumerate([c for c in el if isinstance(c.tag, str) and c.tag == 'li']):
                stl = herdar(st, li)
                marcador = f'{i + 1}. ' if tag == 'ol' else '• '
                self.paragrafo([marcador] + ([li.text] if li.text else []) + list(_filhos_com_tail(li)),
                               alvo, stl, largura, em_celula, recuo_pt=20, el_ref=li)
            return
        if tag in ('div', 'section', 'blockquote', 'li'):
            if any(isinstance(c.tag, str) and c.tag in BLOCOS for c in el):
                junto = 'manter-junto' in classes
                antes = getattr(self, 'manter', False)
                if junto:
                    self.manter = True
                self.blocos(el, alvo, st, largura, em_celula)
                self.manter = antes
                return
        conteudo = ([el.text] if el.text else []) + list(_filhos_com_tail(el))
        self.paragrafo(conteudo, alvo, st, largura, em_celula, el_ref=el)

    def paragrafo(self, nos, alvo, st, largura, em_celula=False, implicito=False, recuo_pt=0, el_ref=None):
        p = alvo.add_paragraph()
        pf = p.paragraph_format
        tam = comp_pt(st.get('font-size')) or 12
        pf.alignment = ALINHA.get(st.get('text-align', 'justify'), WD_ALIGN_PARAGRAPH.JUSTIFY)
        lh = st.get('line-height')
        try:
            pf.line_spacing = max(1.0, float(lh) / 1.15) if lh and not lh.endswith(('pt', 'px')) else (Pt(comp_pt(lh)) if lh else 1.0)
        except ValueError:
            pf.line_spacing = 1.0
        mb = st.get('margin-bottom')
        mt = st.get('margin-top')
        if 'margin' in st:
            partes = st['margin'].split()
            if partes:
                mt = mt or partes[0]
                mb = mb or (partes[2] if len(partes) > 2 else partes[0])
                if len(partes) > 1 and partes[1] != 'auto':
                    st.setdefault('margin-right', partes[1]); st.setdefault('margin-left', partes[3] if len(partes) > 3 else partes[1])
        padrao_mb = '0' if (implicito or em_celula and el_ref is not None and el_ref.tag != 'p') else '6pt'
        if em_celula and implicito:
            padrao_mb = '0'
        pf.space_after = Pt(comp_pt(mb if mb is not None else padrao_mb) or 0)
        pf.space_before = Pt(comp_pt(mt) or 0) if mt else Pt(0)
        for lado, attr in (('margin-left', 'left_indent'), ('margin-right', 'right_indent')):
            v = st.get(lado)
            if v:
                if v.endswith('%'):
                    pts = largura * float(v[:-1]) / 100
                else:
                    pts = comp_pt(v) or 0
                setattr(pf, attr, Pt(pts))
        if recuo_pt:
            pf.left_indent = Pt(recuo_pt); pf.first_line_indent = Pt(-10)
        if st.get('text-indent'):
            pf.first_line_indent = Pt(comp_pt(st['text-indent'], tam) or 0)
        b = borda(st.get('border-top'))
        if b:
            pPr = p._p.get_or_add_pPr()
            bdr = OxmlElement('w:pBdr'); top = OxmlElement('w:top')
            top.set(qn('w:val'), 'single'); top.set(qn('w:sz'), str(b[0])); top.set(qn('w:space'), '2'); top.set(qn('w:color'), b[1])
            bdr.append(top); pPr.append(bdr)
        if st.get('background') and cor(st['background']) and not em_celula:
            sombrear(p._p.get_or_add_pPr(), cor(st['background']))
        self._inline(nos, p, st, largura, [True])
        if getattr(self, 'manter', False):
            pf.keep_with_next = True
            pf.keep_together = True
        return p

    # --- inline
    def _inline(self, nos, p, st, largura, inicio):
        for n in nos:
            if isinstance(n, str):
                self._texto(n, p, st, inicio)
                continue
            tag = n.tag if isinstance(n.tag, str) else ''
            if not tag:
                continue
            if tag == 'br':
                p.add_run().add_break()
                inicio[0] = True
                continue
            if tag == 'img':
                self._imagem(n, p, st, largura)
                inicio[0] = False
                continue
            sti = herdar(st, n)
            filhos = ([n.text] if n.text else []) + list(_filhos_com_tail(n))
            if tag in BLOCOS:   # bloco dentro de inline: trata como quebra
                if not inicio[0]:
                    p.add_run().add_break()
                    inicio[0] = True
            self._inline(filhos, p, sti, largura, inicio)

    def _texto(self, t, p, st, inicio):
        t = re.sub(r'[ \t\r\n]+', ' ', t)
        if inicio[0]:
            t = t.lstrip(' ')
        if not t:
            return
        if '{{pagina}}' in t:
            partes = t.split('{{pagina}}')
            for i, parte in enumerate(partes):
                if parte:
                    self._run(parte, p, st)
                if i < len(partes) - 1:
                    self._campo_pagina(p, st)
            inicio[0] = False
            return
        self._run(t, p, st)
        inicio[0] = t.endswith(' ') and False

    def _run(self, t, p, st):
        if st.get('text-transform') == 'uppercase':
            t = t.upper()
        r = p.add_run(t.replace(' ', ' '))
        self._fmt(r, st)
        return r

    def _fmt(self, r, st):
        f = r.font
        fam = (st.get('font-family') or '').split(',')[0].strip().strip('"\'')
        if fam:
            f.name = fam
            rpr = r._r.get_or_add_rPr()
            rf = rpr.find(qn('w:rFonts'))
            if rf is None:
                rf = OxmlElement('w:rFonts'); rpr.insert(0, rf)
            for a in ('w:ascii', 'w:hAnsi', 'w:cs', 'w:eastAsia'):
                rf.set(qn(a), fam)
        tam = comp_pt(st.get('font-size'))
        if tam:
            f.size = Pt(tam)
        fw = st.get('font-weight', '')
        if fw in ('bold', 'bolder') or (fw.isdigit() and int(fw) >= 600):
            f.bold = True
        if st.get('font-style') == 'italic':
            f.italic = True
        if 'underline' in st.get('text-decoration', ''):
            f.underline = True
        c = cor(st.get('color'))
        if c and c != '000000':
            f.color.rgb = RGBColor.from_string(c)

    def _campo_pagina(self, p, st):
        r = p.add_run(); self._fmt(r, st)
        for tipo, txt in (('begin', None), (None, ' PAGE '), ('separate', None), (None, '1'), ('end', None)):
            if tipo:
                fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), tipo); r._r.append(fc)
            elif txt == ' PAGE ':
                it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = txt; r._r.append(it)
            else:
                tt = OxmlElement('w:t'); tt.text = txt; r._r.append(tt)

    def _imagem(self, el, p, st, largura):
        caminho = resolver_imagem(el.get('src', ''))
        if not caminho:
            return
        sti = herdar(st, el)
        w = comp_pt(sti.get('width')); h = comp_pt(sti.get('height'))
        if 'icone' in (el.get('class') or '').split():
            w = w or comp_pt('5.5mm'); h = h or comp_pt('5.5mm')
        if not w:
            w = min(largura, 200)
        try:
            r = p.add_run()
            if isinstance(caminho, bytes):
                r.add_picture(io.BytesIO(caminho), width=Pt(w), height=Pt(h) if h else None)
            else:
                r.add_picture(caminho, width=Pt(w), height=Pt(h) if h else None)
        except Exception:
            pass

    # --- tabelas
    def tabela(self, el, alvo, st, largura):
        linhas = [tr for tr in el.iter('tr') if _tabela_dona(tr) is el]
        if not linhas:
            return
        grade = []
        for tr in linhas:
            cels = [c for c in tr if isinstance(c.tag, str) and c.tag in ('td', 'th')]
            grade.append(cels)
        ncol = max(sum(int(c.get('colspan', '1') or 1) for c in cels) for cels in grade) or 1
        # larguras das colunas
        larg = [None] * ncol
        for cels in grade:
            i = 0
            for c in cels:
                span = int(c.get('colspan', '1') or 1)
                if span == 1 and larg[i] is None:
                    stc = herdar(st, c)
                    v = stc.get('width')
                    if v:
                        larg[i] = largura * float(v[:-1]) / 100 if v.endswith('%') else comp_pt(v)
                i += span
        fixas = sum(x for x in larg if x); livres = larg.count(None)
        resto = max(largura - fixas, 20 * livres)
        larg = [x if x else resto / max(livres, 1) for x in larg]
        fator = largura / sum(larg) if sum(larg) > largura else 1
        larg = [x * fator for x in larg]

        try:
            t = alvo.add_table(rows=len(grade), cols=ncol)
        except TypeError:
            t = alvo.add_table(len(grade), ncol, Pt(largura))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        grid = t._tbl.tblGrid
        for gc, w in zip(grid.findall(qn('w:gridCol')), larg):
            gc.set(qn('w:w'), str(int(w * 20)))
        tblPr = t._tbl.tblPr
        lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
        tw = OxmlElement('w:tblW'); tw.set(qn('w:w'), str(int(sum(larg) * 20))); tw.set(qn('w:type'), 'dxa')
        for velho in tblPr.findall(qn('w:tblW')):
            tblPr.remove(velho)
        tblPr.append(tw)
        mar = OxmlElement('w:tblCellMar')
        for lado, v in (('top', 30), ('left', 80), ('bottom', 30), ('right', 80)):
            e = OxmlElement(f'w:{lado}'); e.set(qn('w:w'), str(v)); e.set(qn('w:type'), 'dxa'); mar.append(e)
        tblPr.append(mar)
        classes = (el.get('class') or '').split()
        bds = OxmlElement('w:tblBorders')
        for lado in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
            e = OxmlElement(f'w:{lado}')
            if 'bordas' in classes:
                e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), '4'); e.set(qn('w:color'), '000000')
            else:
                e.set(qn('w:val'), 'nil')
            bds.append(e)
        tblPr.append(bds)
        # espaço depois da tabela
        mb = comp_pt(st.get('margin-bottom', '6pt' if 'sem-margem' not in classes else '0'))
        if 'secao' in classes:
            mb = 7

        for ri, cels in enumerate(grade):
            row = t.rows[ri]
            if getattr(self, 'manter', False):
                trPr = row._tr.get_or_add_trPr()
                cs = OxmlElement('w:cantSplit'); trPr.append(cs)
            ci = 0
            for c in cels:
                span = int(c.get('colspan', '1') or 1)
                cell = row.cells[ci]
                if span > 1:
                    cell = cell.merge(row.cells[min(ci + span - 1, ncol - 1)])
                w = sum(larg[ci:ci + span])
                cell.width = Pt(w)
                stc = herdar(st, c)
                if 'rubrica' in (c.get('class') or '').split():
                    cell._tc.set('data-rubrica', '1')
                if 'grade' in classes:
                    stc.setdefault('border-bottom', '0.5pt solid #BFBFBF')
                    stc.setdefault('vertical-align', 'bottom')
                    stc['text-align'] = 'left'
                if 'linhas' in classes:
                    stc.setdefault('border-bottom', '0.5pt solid #D0D0D0')
                tcPr = cell._tc.get_or_add_tcPr()
                if stc.get('background') and cor(stc['background']):
                    sombrear(tcPr, cor(stc['background']))
                tcb = OxmlElement('w:tcBorders'); tem = False
                for lado in ('top', 'bottom', 'left', 'right'):
                    b = borda(stc.get(f'border-{lado}') or stc.get('border'))
                    if b:
                        e = OxmlElement(f'w:{lado}'); e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), str(b[0])); e.set(qn('w:color'), b[1])
                        tcb.append(e); tem = True
                if tem:
                    tcPr.append(tcb)
                va = stc.get('vertical-align')
                cell.vertical_alignment = {'middle': WD_CELL_VERTICAL_ALIGNMENT.CENTER,
                                           'bottom': WD_CELL_VERTICAL_ALIGNMENT.BOTTOM}.get(va, WD_CELL_VERTICAL_ALIGNMENT.TOP)
                primeiro = cell.paragraphs[0]._p
                self.blocos(c, cell, {k: v for k, v in stc.items() if k in HERDA}, max(w - 10, 20), em_celula=True)
                if len(cell._tc.findall(qn('w:p'))) + len(cell._tc.findall(qn('w:tbl'))) > 1 and not primeiro.findall(qn('w:r')):
                    cell._tc.remove(primeiro)
                # célula precisa terminar com parágrafo
                if cell._tc[-1].tag == qn('w:tbl'):
                    cell.add_paragraph()
                ci += span
        if mb:
            p = alvo.add_paragraph()
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = Pt(max(mb, 1))
            r = p.add_run(''); r.font.size = Pt(1)


def _filhos_com_tail(el):
    for c in el:
        yield c
        if c.tail:
            yield c.tail


def _tabela_dona(tr):
    p = tr.getparent()
    while p is not None and p.tag != 'table':
        p = p.getparent()
    return p


def resolver_imagem(src):
    if not src:
        return None
    if src.startswith('data:'):
        try:
            return base64.b64decode(src.split(',', 1)[1])
        except Exception:
            return None
    src = re.sub(r'^https?://[^/]+/', '', src).lstrip('/')
    src = src.split('?')[0]
    if src.startswith('recursos/'):
        p = os.path.join(B.P_RECURSOS, src[len('recursos/'):])
        return p if os.path.exists(p) else None
    if src.startswith('timbrado/'):
        partes = src.split('/')
        return B.caminho_fundo(partes[1]) if len(partes) > 1 else None
    return None


# ------------------------------------------------------------------ timbrado como fundo
def _ancorar_fundo(run, imagem, largura_cm, altura_cm):
    run.add_picture(imagem, width=Cm(largura_cm), height=Cm(altura_cm))
    inline = run._r.find('.//' + qn('wp:inline'))
    anchor = OxmlElement('wp:anchor')
    for k, v in (('distT', '0'), ('distB', '0'), ('distL', '0'), ('distR', '0'), ('simplePos', '0'),
                 ('relativeHeight', '0'), ('behindDoc', '1'), ('locked', '1'), ('layoutInCell', '1'), ('allowOverlap', '1')):
        anchor.set(k, v)
    sp = OxmlElement('wp:simplePos'); sp.set('x', '0'); sp.set('y', '0'); anchor.append(sp)
    for eixo in ('positionH', 'positionV'):
        pos = OxmlElement(f'wp:{eixo}'); pos.set('relativeFrom', 'page')
        off = OxmlElement('wp:posOffset'); off.text = '0'; pos.append(off); anchor.append(pos)
    anchor.append(copy.deepcopy(inline.find(qn('wp:extent'))))
    ee = OxmlElement('wp:effectExtent')
    for k in ('l', 't', 'r', 'b'):
        ee.set(k, '0')
    anchor.append(ee)
    anchor.append(OxmlElement('wp:wrapNone'))
    anchor.append(copy.deepcopy(inline.find(qn('wp:docPr'))))
    anchor.append(OxmlElement('wp:cNvGraphicFramePr'))
    anchor.append(copy.deepcopy(inline.find(qn('a:graphic'))))
    inline.getparent().replace(inline, anchor)


def _limpar(hf):
    for el in list(hf._element):
        hf._element.remove(el)
    return hf.add_paragraph()


# ---------------------------------------------------------------- rubrica do rodapé só fora da última página
def _r(tipo=None, instr=None, texto=None, rpr=None):
    r = OxmlElement('w:r')
    if rpr is not None:
        r.append(copy.deepcopy(rpr))
    if tipo:
        fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), tipo); r.append(fc)
    if instr is not None:
        it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = instr; r.append(it)
    if texto is not None:
        t = OxmlElement('w:t'); t.set(qn('xml:space'), 'preserve'); t.text = texto; r.append(t)
    return r


def _se_nao_ultima(p_el):
    """Envolve o conteúdo do parágrafo num campo { IF { PAGE } < { SECTIONPAGES } "conteúdo" "" }:
    no Word a rubrica aparece em todas as páginas do documento, menos na última."""
    runs = [c for c in p_el if c.tag == qn('w:r')]
    if not runs:
        return
    for r in runs:
        p_el.remove(r)
    em_codigo = []
    for r in runs:
        c = copy.deepcopy(r)
        for t in c.findall(qn('w:t')):
            t.tag = qn('w:instrText'); t.set(qn('xml:space'), 'preserve')
            t.text = (t.text or '').replace('"', "'")
        em_codigo.append(c)
    seq = [_r('begin'), _r(instr=' IF '), _r('begin'), _r(instr=' PAGE '), _r('separate'), _r(texto='1'), _r('end'),
           _r(instr=' < '), _r('begin'), _r(instr=' SECTIONPAGES '), _r('separate'), _r(texto='2'), _r('end'),
           _r(instr=' "')] + em_codigo + [_r(instr='" "" '), _r('separate')] + runs + [_r('end')]
    for e in seq:
        p_el.append(e)


def _rubrica_fora_da_ultima(footer, largura_pt):
    for tbl in footer._element.iter(qn('w:tbl')):
        for tc in tbl.iter(qn('w:tc')):
            if tc.get('data-rubrica') != '1':
                continue
            del tc.attrib['data-rubrica']
            w = tc.find(qn('w:tcPr') + '/' + qn('w:tcW'))
            larg = (int(w.get(qn('w:w'))) / 20) if w is not None and (w.get(qn('w:w')) or '').isdigit() else largura_pt * 0.6
            for p in list(tc.iter(qn('w:p'))):
                ppr = p.find(qn('w:pPr'))
                bdr = ppr.find(qn('w:pBdr')) if ppr is not None else None
                if bdr is not None and bdr.find(qn('w:top')) is not None:
                    # a linha (borda) vira uma linha de "_" para também sumir na última página
                    ppr.remove(bdr)
                    linha = copy.deepcopy(p)
                    for c in list(linha):
                        if c.tag != qn('w:pPr'):
                            linha.remove(c)
                    rpr = OxmlElement('w:rPr'); sz = OxmlElement('w:sz'); sz.set(qn('w:val'), '15'); rpr.append(sz)
                    linha.append(_r(texto='_' * max(10, int(larg / (0.556 * 7.5)) - 2), rpr=rpr))
                    p.addprevious(linha)
                    _se_nao_ultima(linha)
                _se_nao_ultima(p)


def _paginas_originais(doc, it, nova_secao):
    """Modelo 'PDF original': cada página é a imagem do PDF + caixas de texto posicionadas."""
    for pg in it['paginas']:
        sec = nova_secao()
        wpt, hpt = float(pg.get('w') or 595.3), float(pg.get('h') or 841.9)
        sec.page_width, sec.page_height = Pt(wpt), Pt(hpt)
        for a in ('top_margin', 'bottom_margin', 'left_margin', 'right_margin'):
            setattr(sec, a, Cm(0.5))
        sec.header_distance = Cm(0.01); sec.footer_distance = Cm(0.01)
        sec.header.is_linked_to_previous = False
        sec.footer.is_linked_to_previous = False
        hp = _limpar(sec.header); hp.paragraph_format.space_after = Pt(0)
        img = resolver_imagem(pg.get('img', ''))
        if img:
            r = hp.add_run(); r.font.size = Pt(1)
            _ancorar_fundo(r, img if isinstance(img, str) else io.BytesIO(img), wpt * 2.54 / 72, hpt * 2.54 / 72)
        _limpar(sec.footer)
        conv = Conversor(doc, wpt, 'Arial', 9, 1.15)
        colocou = False
        for cx in pg.get('caixas') or []:
            html = cx.get('html') or ''
            if not re.sub(r'<[^>]+>|&nbsp;|\s', '', html):
                if not cx.get('cobrir'):
                    continue
                html = '&nbsp;'      # vazio, mas cobre o que está impresso embaixo (linha ou rótulo)
            tam = float(cx.get('tam') or 9)
            st = dict(conv.base); st.update({'font-size': f'{tam}pt', 'font-family': 'Arial',
                                              'text-align': {'centro': 'center', 'direita': 'right', 'justificado': 'justify'}.get(cx.get('alinhar'), 'left')})
            if cx.get('negrito'):
                st['font-weight'] = 'bold'
            if cx.get('fonte'):
                st['font-family'] = cx['fonte'].split(',')[0].strip().strip('"\'')
            if cx.get('cor'):
                st['color'] = cx['cor']
            raiz = LH.fragment_fromstring(html, create_parent='div')
            nos = ([raiz.text] if raiz.text else []) + list(_filhos_com_tail(raiz))
            p = conv.paragrafo(nos, doc, st, float(cx.get('w') or 100), implicito=True)
            pf = p.paragraph_format
            pf.space_after = Pt(0); pf.space_before = Pt(0)
            if cx.get('recuo'):
                pf.first_line_indent = Pt(float(cx['recuo']))
            lh = cx.get('lh')
            from docx.enum.text import WD_LINE_SPACING
            pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
            pf.line_spacing = Pt(float(lh) if lh else tam * 1.2)
            pPr = p._p.get_or_add_pPr()
            fr = OxmlElement('w:framePr')
            y = float(cx.get('y') or 0)
            alt = float(cx.get('h') or tam * 1.3)
            if not lh:     # uma linha: encosta o texto na base da caixa
                y = y + max(alt - tam * 1.25, 0)
                alt = tam * 1.25
            for k, v in (('w', cx.get('w')), ('h', alt), ('x', cx.get('x')), ('y', y)):
                fr.set(qn('w:' + k), str(int(float(v or 0) * 20)))
            fr.set(qn('w:hRule'), 'exact'); fr.set(qn('w:hAnchor'), 'page'); fr.set(qn('w:vAnchor'), 'page')
            fr.set(qn('w:wrap'), 'around')
            pPr.insert(0, fr)
            if cx.get('cobrir'):
                sombrear(pPr, (cx.get('fundo') or '#FFFFFF').lstrip('#').upper())
            colocou = True
        fim = doc.add_paragraph()          # parágrafo comum no fim da página (âncora estável)
        fim.paragraph_format.space_after = Pt(0)
        fim.add_run('').font.size = Pt(1)


def gerar_docx(itens):
    """itens: [{html, timbrado, margens{sup,inf,esq,dir}, rodape, fonte, tamanho, espacamento}]"""
    doc = Document()
    estilo = doc.styles['Normal']
    primeiro = itens[0] if itens else {}
    estilo.font.name = primeiro.get('fonte') or 'Calibri'
    estilo.font.size = Pt(float(primeiro.get('tamanho') or 12))
    estilo.paragraph_format.space_after = Pt(0)
    # remove o parágrafo vazio inicial
    for p in list(doc.element.body):
        if p.tag == qn('w:p'):
            doc.element.body.remove(p)

    primeira = [True]

    def nova_secao():
        if primeira[0]:
            primeira[0] = False
            return doc.sections[0]
        return doc.add_section(WD_SECTION.NEW_PAGE)

    for idx, it in enumerate(itens):
        if it.get('paginas'):
            _paginas_originais(doc, it, nova_secao)
            continue
        sec = nova_secao()
        deitada = bool(it.get('paisagem'))
        if deitada:
            from docx.enum.section import WD_ORIENT
            sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width, sec.page_height = (Mm(297), Mm(210)) if deitada else (Mm(210), Mm(297))
        m = it.get('margens') or {'sup': 3, 'inf': 2.5, 'esq': 2.5, 'dir': 2.5}
        tem_rodape = bool((it.get('rodape') or '').strip())
        sec.top_margin = Cm(m['sup'])
        sec.left_margin = Cm(m['esq']); sec.right_margin = Cm(m['dir'])
        sec.bottom_margin = Cm(m['inf'] + (1.1 if tem_rodape else 0))
        sec.header_distance = Cm(0.01)
        sec.footer_distance = Cm(max(m['inf'] - 0.2, 0.4))
        sec.header.is_linked_to_previous = False
        sec.footer.is_linked_to_previous = False
        # numeração de página reinicia em cada item
        pg = OxmlElement('w:pgNumType'); pg.set(qn('w:start'), '1'); sec._sectPr.append(pg)
        hp = _limpar(sec.header)
        hp.paragraph_format.space_after = Pt(0)
        fundo = B.caminho_fundo(it['timbrado']) if it.get('timbrado') and it['timbrado'] != 'nenhum' else None
        if fundo:
            r = hp.add_run(); r.font.size = Pt(1)
            _ancorar_fundo(r, fundo, *((29.7, 21.0) if deitada else (21.0, 29.7)))
        fp = _limpar(sec.footer)
        largura = ((29.7 if deitada else 21.0) - m['esq'] - m['dir']) * 72 / 2.54
        conv = Conversor(doc, largura, it.get('fonte') or 'Calibri', float(it.get('tamanho') or 12),
                         float(it.get('espacamento') or 1.4))
        if tem_rodape:
            raiz = LH.fragment_fromstring(it['rodape'], create_parent='div')
            sec.footer._element.remove(fp._p)
            conv.blocos(raiz, sec.footer, dict(conv.base), largura)
            _rubrica_fora_da_ultima(sec.footer, largura)
        raiz = LH.fragment_fromstring(it.get('html') or '<p></p>', create_parent='div')
        conv.blocos(raiz, doc, dict(conv.base), largura)
    # Word: não esticar a linha que termina em quebra manual (igual ao navegador)
    st = doc.settings.element
    compat = st.find(qn('w:compat'))
    if compat is None:
        compat = OxmlElement('w:compat'); st.append(compat)
    if compat.find(qn('w:doNotExpandShiftReturn')) is None:
        compat.insert(0, OxmlElement('w:doNotExpandShiftReturn'))
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
