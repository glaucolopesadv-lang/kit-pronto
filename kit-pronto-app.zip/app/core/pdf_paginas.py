"""Importação de PDF SEM mexer na formatação.

Cada página do PDF vira uma imagem (exatamente como foi desenhada) e os campos
preenchíveis são caixas posicionadas por cima dela, nos lugares das linhas
"____", das linhas de formulário e das caixinhas de marcar.
Um PDF com vários documentos (kit) é separado em documentos pelos títulos.
Coordenadas em pontos (pt), origem no canto superior esquerdo da página.
"""
import io, re

from . import importador as I

QUALIF = ('{{cliente_nome}}, {{cliente_nacionalidade}}, {{cliente_estado_civil}}, {{cliente_profissao}}, '
          'portador(a) do RG nº {{cliente_rg}}, inscrito(a) no CPF sob o nº {{cliente_cpf}}, residente e domiciliado(a) em '
          '{{cliente_endereco}}, bairro {{cliente_bairro}}, {{cliente_cidade}}/{{cliente_uf}}, CEP {{cliente_cep}}, '
          'telefone {{cliente_telefone}}')

CAMPOS_PADRAO = {
    'cliente_nome': ('Nome completo', 'texto', 'Cliente', 'nome'),
    'cliente_genero': ('Gênero (ajusta o/a no texto)', 'opcoes', 'Cliente', None),
    'cliente_nacionalidade': ('Nacionalidade', 'texto', 'Cliente', 'minusculo'),
    'cliente_estado_civil': ('Estado civil', 'opcoes', 'Cliente', None),
    'cliente_profissao': ('Profissão', 'texto', 'Cliente', 'minusculo'),
    'cliente_rg': ('RG / Identidade', 'texto', 'Cliente', None),
    'cliente_cpf': ('CPF', 'cpf', 'Cliente', None),
    'cliente_nascimento': ('Data de nascimento', 'data', 'Cliente', None),
    'cliente_apelido': ('Apelido', 'texto', 'Cliente', 'nome'),
    'cliente_endereco': ('Endereço (rua, nº)', 'texto', 'Endereço', 'nome'),
    'cliente_bairro': ('Bairro', 'texto', 'Endereço', 'nome'),
    'cliente_cidade': ('Cidade', 'texto', 'Endereço', 'nome'),
    'cliente_uf': ('UF', 'uf', 'Endereço', None),
    'cliente_cep': ('CEP', 'cep', 'Endereço', None),
    'cliente_referencia': ('Ponto de referência', 'texto', 'Endereço', 'nome'),
    'cliente_telefone': ('Telefone', 'telefone', 'Contato', None),
    'cliente_whatsapp': ('WhatsApp', 'telefone', 'Contato', None),
    'cliente_instagram': ('Instagram', 'texto', 'Contato', None),
    'cliente_facebook': ('Facebook', 'texto', 'Contato', None),
    'cliente_email': ('E-mail', 'email', 'Contato', None),
    'rep_nome': ('Representante legal — nome', 'texto', 'Representante legal', 'nome'),
    'rep_cpf': ('Representante — CPF', 'cpf', 'Representante legal', None),
    'rep_telefone': ('Representante — telefone', 'telefone', 'Representante legal', None),
    'rep_email': ('Representante — e-mail', 'email', 'Representante legal', None),
    'rep_relacao': ('Relação com o cliente', 'texto', 'Representante legal', None),
    'ficha_escritorio': ('Escritório', 'texto', 'Atendimento', None),
    'ficha_protocolo': ('Protocolo de atendimento', 'texto', 'Atendimento', None),
    'ficha_tipo_acao': ('Tipo de ação', 'texto', 'Atendimento', None),
    'ficha_setor': ('Setor', 'texto', 'Atendimento', None),
    'ficha_contato': ('Contato (como chegou)', 'texto', 'Atendimento', None),
    'ficha_responsavel': ('Responsável', 'texto', 'Atendimento', None),
    'ficha_ajuizar_ate': ('Ajuizar até', 'data', 'Informações adicionais', None),
    'ficha_razao': ('Razão', 'texto', 'Informações adicionais', None),
    'ficha_meu_inss': ('Acesso Meu INSS', 'texto', 'Informações adicionais', None),
    'ficha_outros_sistemas': ('Acesso a outros sistemas', 'texto', 'Informações adicionais', None),
    'ficha_outros_processos': ('Existem outros processos?', 'texto_longo', 'Informações adicionais', None),
    'ficha_outro_servico': ('Serviço de outra área do direito?', 'texto_longo', 'Informações adicionais', None),
    'ficha_pendencias': ('Pendências', 'texto_longo', 'Informações adicionais', None),
    'local': ('Local da assinatura', 'texto', 'Data e local', None),
    'data_documento': ('Data do documento', 'data', 'Data e local', None),
    'testemunha1_nome': ('Testemunha 1 — nome', 'texto', 'Testemunhas', 'nome'),
    'testemunha1_cpf': ('Testemunha 1 — CPF', 'cpf', 'Testemunhas', None),
    'testemunha2_nome': ('Testemunha 2 — nome', 'texto', 'Testemunhas', 'nome'),
    'testemunha2_cpf': ('Testemunha 2 — CPF', 'cpf', 'Testemunhas', None),
}
EC = ['solteiro(a)', 'casado(a)', 'divorciado(a)', 'separado(a) judicialmente', 'viúvo(a)', 'em união estável']

# rótulos de ficha (formulário com linhas) -> chave
ROTULOS_FICHA = [
    (r'^escritorio', 'ficha_escritorio'), (r'protocolo', 'ficha_protocolo'), (r'tipo de acao', 'ficha_tipo_acao'),
    (r'^setor', 'ficha_setor'), (r'^contato', 'ficha_contato'), (r'^responsavel', 'ficha_responsavel'),
    (r'representante', 'rep_nome'), (r'relacao com', 'rep_relacao'), (r'^apelido', 'cliente_apelido'),
    (r'ponto de referencia', 'cliente_referencia'), (r'whats', 'cliente_whatsapp'), (r'instagram', 'cliente_instagram'),
    (r'facebook', 'cliente_facebook'), (r'ajuizar', 'ficha_ajuizar_ate'), (r'^razao', 'ficha_razao'),
    (r'meu inss', 'ficha_meu_inss'), (r'outro\(s\) sistema|outros sistemas', 'ficha_outros_sistemas'),
    (r'outros processos', 'ficha_outros_processos'), (r'outra area do direito|servico que possamos', 'ficha_outro_servico'),
    (r'pendencia', 'ficha_pendencias'), (r'^nome$|^nome completo', 'cliente_nome'), (r'^cpf', 'cliente_cpf'),
    (r'identidade|^rg', 'cliente_rg'), (r'estado civil', 'cliente_estado_civil'), (r'profiss', 'cliente_profissao'),
    (r'nascimento', 'cliente_nascimento'), (r'endereco', 'cliente_endereco'), (r'^bairro', 'cliente_bairro'),
    (r'^cidade|municipio', 'cliente_cidade'), (r'^cep', 'cliente_cep'), (r'telefone', 'cliente_telefone'),
    (r'e-?mail', 'cliente_email'),
]


def campo_def(chave, rotulo=None, tipo=None, grupo=None):
    if chave in CAMPOS_PADRAO:
        r, t, g, f = CAMPOS_PADRAO[chave]
        d = {'chave': chave, 'rotulo': r, 'tipo': t, 'grupo': g, 'padrao': I.PADROES_CAMPO.get(chave, '')}
        if f:
            d['formato'] = f
        if chave == 'cliente_estado_civil':
            d['opcoes'] = EC
        if chave == 'cliente_genero':
            d['opcoes'] = ['Masculino', 'Feminino']
        if chave == 'cliente_nacionalidade':
            d['padrao'] = 'brasileiro(a)'
        return d
    return {'chave': chave, 'rotulo': rotulo or chave, 'tipo': tipo or 'texto', 'grupo': grupo or 'Geral', 'padrao': ''}


def _linhas_texto(pg):
    """Linhas de texto (sem os sublinhados), separadas em blocos quando há espaço grande."""
    # tira os "_" antes de juntar as palavras: no PDF do Word a linha vem grudada na pontuação ("______,")
    sem = pg.filter(lambda o: not (o.get('object_type') == 'char' and o.get('text') == '_'))
    words = sem.extract_words(keep_blank_chars=False, use_text_flow=False, extra_attrs=['size'])
    words = [w for w in words if not re.fullmatch(r'[_\s.,;:/\-]+', w['text'])]
    words.sort(key=lambda w: (round(w['top']), w['x0']))
    linhas = []
    for w in words:
        alvo = None
        for ln in linhas:
            if abs(ln['top'] - w['top']) < 2.5 and w['x0'] - ln['x1'] < 14 and w['x0'] >= ln['x0']:
                alvo = ln
                break
        if alvo:
            alvo['texto'] += ' ' + w['text']; alvo['x1'] = max(alvo['x1'], w['x1']); alvo['bottom'] = max(alvo['bottom'], w['bottom'])
            alvo['size'] = max(alvo['size'], w['size'])
        else:
            linhas.append({'texto': w['text'], 'x0': w['x0'], 'x1': w['x1'], 'top': w['top'], 'bottom': w['bottom'], 'size': w['size']})
    for ln in linhas:   # "P rotocolo" -> "Protocolo" (PDF do Word separa a 1ª letra)
        ln['texto'] = re.sub(r'\b([A-ZÀ-Ú]) (?=[a-zà-ú]{2,})', r'\1', ln['texto'])
    return linhas


def _sublinhados(pg):
    """Sequências de '_' na página -> segmentos (x0, x1, top, bottom, size)."""
    chars = sorted([c for c in pg.chars if c['text'] == '_'], key=lambda c: (round(c['top']), c['x0']))
    segs = []
    for c in chars:
        if segs and abs(segs[-1]['top'] - c['top']) < 1.5 and c['x0'] - segs[-1]['x1'] < 2.5:
            segs[-1]['x1'] = c['x1']; segs[-1]['n'] += 1
        else:
            segs.append({'x0': c['x0'], 'x1': c['x1'], 'top': c['top'], 'bottom': c['bottom'], 'size': c.get('size', 10), 'n': 1})
    return [s for s in segs if s['n'] >= 3]


def _texto_linha_completa(pg, top, bottom):
    """Texto da linha (com sublinhados) entre top/bottom."""
    cs = sorted([c for c in pg.chars if c['top'] >= top - 2 and c['bottom'] <= bottom + 2], key=lambda c: c['x0'])
    return ''.join(c['text'] for c in cs)


def _caixa(chave, pagina, x0, top, x1, bottom, tam=9, alinhar='esquerda', texto=None, cobrir=False, lh=None, negrito=False, origem=None):
    return {'origem': origem, 'pagina': pagina, 'x': round(x0, 1), 'y': round(top, 1), 'w': round(max(x1 - x0, 12), 1),
            'h': round(max(bottom - top, 8), 1), 'tam': round(tam, 1), 'alinhar': alinhar,
            'texto': texto or ('{{' + chave + '}}'), 'cobrir': cobrir, 'lh': lh, 'negrito': negrito}


def _detectar_sublinhados(pg, n, linhas, caixas, usados):
    segs = _sublinhados(pg)
    W = float(pg.width)
    feitos = set()
    # 1) local e data: "____/____, ____ de ____ de ____"
    for s in segs:
        if id(s) in feitos:
            continue
        linha = _texto_linha_completa(pg, s['top'], s['bottom'])
        if re.search(r'_{2,}(\s*[/\-]\s*_{1,})?\s*,\s*_{1,}\s*de\s*_{2,}\s*de\s*_{2,}', linha):
            mesma = [t for t in segs if abs(t['top'] - s['top']) < 1.5]
            x0 = min(t['x0'] for t in mesma); x1 = max(t['x1'] for t in mesma)
            # inclui o texto entre os traços (/, de) — cobre tudo com fundo branco
            fim = [c for c in pg.chars if abs(c['top'] - s['top']) < 2 and c['x0'] >= x0 - 1]
            x1 = max([x1] + [c['x1'] for c in fim if c['x1'] <= x1 + 25 and c['text'] in '._'])
            caixas.append(_caixa('', n, x0, s['top'] - 1, x1, s['bottom'] + 1, tam=min(10, s['size']),
                                 alinhar='centro', texto='{{local}}, {{data_documento}}', cobrir=True, origem='linha'))
            usados.update(['local', 'data_documento'])
            for t in mesma:
                feitos.add(id(t))
    # 1b) data só com traços: "Mossoró/RN, ____/________/____"
    for s in segs:
        if id(s) in feitos:
            continue
        mesma = sorted([t for t in segs if abs(t['top'] - s['top']) < 1.5 and id(t) not in feitos], key=lambda t: t['x0'])
        if len(mesma) == 3 and all(0 <= mesma[i + 1]['x0'] - mesma[i]['x1'] < 14 for i in range(2)):
            linha = _texto_linha_completa(pg, s['top'], s['bottom'])
            if re.search(r'_{2,}\s*/\s*_{2,}\s*/\s*_{2,}', linha):
                antes = I.norm(linha.split('_')[0])
                txt = '{{data_documento}}' if re.search(r'[a-z]{3,}', antes) else '{{local}}, {{data_documento}}'
                caixas.append(_caixa('', n, mesma[0]['x0'] - 1, s['top'] - 1, mesma[-1]['x1'] + 2, s['bottom'] + 1.5,
                                     tam=min(11, s['size']), alinhar='esquerda', texto=txt, cobrir=True, origem='linha'))
                usados.add('data_documento')
                if 'local' in txt:
                    usados.add('local')
                for t in mesma:
                    feitos.add(id(t))
    # 2) várias linhas seguidas de "____" (qualificação, pendências…)
    resto = [s for s in segs if id(s) not in feitos]
    grupos, atual = [], []
    for s in sorted(resto, key=lambda s: (s['top'], s['x0'])):
        largo = (s['x1'] - s['x0']) > W * 0.45
        parcial = not largo and s['x1'] > W * 0.75 and (s['x1'] - s['x0']) > 40
        inicio_de_linha = not [l for l in linhas if abs(l['top'] - s['top']) < 4 and l['x1'] <= s['x0'] + 2]
        segue = atual and largo and 6 < s['top'] - atual[-1]['top'] < 26 and (
            abs(s['x0'] - atual[-1]['x0']) < 12 or (len(atual) == 1 and atual[0].get('_parcial') and s['x0'] < atual[0]['x0'] - 20
                                                    and inicio_de_linha))
        if segue:
            atual.append(s)
        else:
            if len(atual) >= 2:
                grupos.append(atual)
            if parcial:
                s['_parcial'] = True
            atual = [s] if (largo or parcial) else []
    if len(atual) >= 2:
        grupos.append(atual)
    for g in grupos:
        for t in g:
            feitos.add(id(t))
        esp = (g[-1]['top'] - g[0]['top']) / (len(g) - 1)
        titulo = ''
        acima = [l for l in linhas if l['bottom'] <= g[0]['top'] + 1 and g[0]['top'] - l['bottom'] < 40
                 and re.search(r'[A-Za-zÀ-ú]{3,}', l['texto'])]
        if acima:
            titulo = I.norm(max(acima, key=lambda l: l['bottom'])['texto'])
        recuo = 0
        if g[0].get('_parcial'):
            # começa no meio da linha: o texto antes dos traços também diz o que é ("e por outro lado ____")
            antes = [l for l in linhas if abs(l['top'] - g[0]['top']) < 4 and l['x1'] <= g[0]['x0'] + 2]
            titulo = ' '.join(I.norm(l['texto']) for l in antes) + ' ' + titulo
            margem = min(t['x0'] for t in g[1:])
            recuo = round(g[0]['x0'] - margem, 1)
            for t in g:   # cobre só os traços (o texto do começo da 1ª linha continua aparecendo)
                caixas.append(_caixa(None, n, t['x0'] - 1, t['top'] - 1, t['x1'] + 3, t['bottom'] + 1.5, texto='&nbsp;', origem='linha'))
            g = [dict(g[0], x0=margem)] + g[1:]
        tam = min(10, esp * 0.78)
        if re.search(r'outorgante|contratante|declarante|requerente|qualifica|outro lado', titulo):
            texto = QUALIF
            usados.update(['cliente_nome', 'cliente_genero', 'cliente_nacionalidade', 'cliente_estado_civil', 'cliente_profissao',
                           'cliente_rg', 'cliente_cpf', 'cliente_endereco', 'cliente_bairro', 'cliente_cidade', 'cliente_uf',
                           'cliente_cep', 'cliente_telefone'])
            chave = None
        else:
            c = I.rotulo_para_campo(titulo or 'texto', {})
            chave = c['chave'] if c['chave'] not in ('campo_1',) else 'texto_livre'
            texto = None
            usados.add(chave)
        top = g[0]['bottom'] - esp + 1.5
        cx = _caixa(chave, n, g[0]['x0'] - 1, top, max(s['x1'] for s in g) + 3, g[-1]['bottom'] + 1.5, tam=tam,
                    texto=texto, lh=round(esp, 2), alinhar='justificado' if texto else 'esquerda', origem=None if recuo else 'linha')
        if recuo:
            cx['recuo'] = recuo
        caixas.append(cx)
        for s in g:
            feitos.add(id(s))
    # 3) linhas soltas com rótulo à esquerda ("CPF Nº ____") e linhas de assinatura
    rot_test = sorted([l for l in linhas if re.search(r'\btestemunha', I.norm(l['texto']))], key=lambda l: (round(l['top']), l['x0']))

    def testemunha_de(seg):
        """Qual testemunha (1 ou 2) é dona deste traço: rótulo na mesma linha, à esquerda, ou logo acima na mesma coluna."""
        cands = [l for l in rot_test if (abs(l['top'] - seg['top']) < 4 and l['x0'] <= seg['x0'] + 2)
                 or (0 < seg['top'] - l['top'] < 75 and abs(l['x0'] - seg['x0']) < 200)]
        if not cands:
            return None
        dono = max(cands, key=lambda l: (round(l['top']), l['x0']))
        return min(2, rot_test.index(dono) + 1)

    for s in segs:
        if id(s) in feitos:
            continue
        esquerda = [l for l in linhas if abs(l['top'] - s['top']) < 4 and l['x1'] <= s['x0'] + 2 and s['x0'] - l['x1'] < 40]
        if esquerda:
            rot = max(esquerda, key=lambda l: l['x1'])['texto']
            r = I.norm(rot)
            k_test = testemunha_de(s)
            if k_test and 'cpf' in r:
                # "CPF: ____" impresso no PDF: some tudo se o CPF não for preenchido; se for, mostra "CPF: 000…"
                lab = max(esquerda, key=lambda l: l['x1'])
                x_ini = lab['x0'] if len(r) <= 12 else s['x0']
                rot_txt = rot.strip() if len(r) <= 12 else ''
                ch = f'testemunha{k_test}_cpf'
                caixas.append(_caixa(None, n, x_ini - 1, s['top'] - 1.5, s['x1'] + 3, s['bottom'] + 1.5,
                                     tam=min(11, round(lab['size'], 1)), origem='linha',
                                     texto=f'<span data-se="{ch}">{rot_txt + " " if rot_txt else ""}{{{{{ch}}}}}</span>'))
                usados.add(ch)
                continue
            elif k_test and 'testemunha' in r:
                # a linha continua livre para a assinatura; o nome sai pequeno logo abaixo dela
                ch = f'testemunha{k_test}_nome'
                caixas.append(_caixa(ch, n, s['x0'], s['bottom'] + 0.3, s['x1'], s['bottom'] + 9.5,
                                     tam=min(8, round(s['size'] * 0.75, 1)), alinhar='centro'))
                usados.add(ch)
                continue
            else:
                c = I.rotulo_para_campo(rot, {})
                chave = c['chave']
                if chave.startswith('campo_'):
                    chave = I.slug_chave(rot)
                lab = max(esquerda, key=lambda l: l['x1'])
                if 'cpf' in r and len(r) <= 12 and lab['x1'] >= s['x0'] - 15:
                    # "CPF Nº ____" sozinho: rótulo e linha só aparecem com o CPF preenchido
                    caixas.append(_caixa(None, n, lab['x0'] - 1, s['top'] - 1.5, s['x1'] + 3, s['bottom'] + 1.5,
                                         tam=min(11, round(lab['size'], 1)), origem='linha',
                                         texto=f'<span data-se="{chave}">{rot.strip()} {{{{{chave}}}}}</span>'))
                    usados.add(chave)
                    continue
            usados.add(chave)
            caixas.append(_caixa(chave, n, s['x0'] - 1, s['top'] - 1.5, s['x1'] + 3, s['bottom'] + 1.5, tam=min(12, round(s['size'] * 0.95, 1)), origem='linha'))
            continue
        # linha de assinatura: nome embaixo do rótulo (OUTORGANTE / CONTRATANTE)
        abaixo = [l for l in linhas if 0 <= l['top'] - s['bottom'] < 16 and l['x0'] >= s['x0'] - 20 and l['x1'] <= s['x1'] + 20]
        if abaixo:
            rot = I.norm(abaixo[0]['texto'])
            livre = not [l for l in linhas if 0 < l['top'] - abaixo[0]['bottom'] < 13 and l['x0'] < s['x1'] and l['x1'] > s['x0']]
            if re.match(r'^(outorgante|contratante|declarante|requerente|representado)', rot) and livre:
                caixas.append(_caixa('cliente_nome', n, s['x0'], abaixo[0]['bottom'] + 0.5, s['x1'], abaixo[0]['bottom'] + 12,
                                     tam=9, alinhar='centro', negrito=True))
                usados.add('cliente_nome')
                # "CONTRATANTE - CPF nº.:" sem traço: o CPF vai logo depois do rótulo, na mesma linha
                if re.search(r'\bcpf\b', rot) and not [t for t in segs if abs(t['top'] - abaixo[0]['top']) < 4 and t['x0'] >= abaixo[0]['x1'] - 2]:
                    lb = abaixo[0]
                    pal = sorted([w for w in pg.extract_words() if abs(w['top'] - lb['top']) < 3 and lb['x0'] - 1 <= w['x0'] <= lb['x1'] + 1],
                                 key=lambda w: w['x0'])
                    i_cpf = next((i for i, w in enumerate(pal) if I.norm(w['text']).startswith('cpf')), None)
                    if i_cpf is not None:
                        i0 = i_cpf - 1 if i_cpf > 0 and re.fullmatch(r'[-–—/|]', pal[i_cpf - 1]['text']) else i_cpf
                        rot_cpf = ' '.join(w['text'] for w in pal[i0:])
                        x_fim = max(s['x1'], lb['x1'] + 110)
                        caixas.append(_caixa(None, n, pal[i0]['x0'] - 1.5, lb['top'] - 1, x_fim, lb['bottom'] + 1.5,
                                             tam=min(10, round(lb['size'], 1)), negrito=True, origem='linha',
                                             texto=f'<span data-se="cliente_cpf">{rot_cpf} {{{{cliente_cpf}}}}</span>'))
                        usados.add('cliente_cpf')
        elif (s['x1'] - s['x0']) > W * 0.35 and 'cliente_nome' in usados:
            # linha de assinatura sozinha (sem rótulo embaixo): o nome do cliente vai logo abaixo dela
            ocupado = [l for l in linhas if 0 <= l['top'] - s['bottom'] < 18 and l['x0'] < s['x1'] and l['x1'] > s['x0']]
            if not ocupado and s['bottom'] + 14 < float(pg.height) - 20:
                caixas.append(_caixa('cliente_nome', n, s['x0'], s['bottom'] + 1.5, s['x1'], s['bottom'] + 13,
                                     tam=min(10, s['size']), alinhar='centro', negrito=True))


def _detectar_formulario(pg, n, linhas, caixas, usados):
    """Ficha com linhas de tabela: o valor vai na faixa logo abaixo do rótulo."""
    hs = [r for r in pg.rects if r['height'] < 2.5 and r['width'] > 25]
    hs += [{'x0': l['x0'], 'x1': l['x1'], 'top': l['top'], 'width': l['x1'] - l['x0']} for l in pg.lines if abs(l['top'] - l['bottom']) < 1]
    if len(hs) < 15:
        return False
    longas = [l for l in linhas if len(l['texto']) > 70]
    if len(longas) > 5:          # página de texto corrido (contrato, procuração): não é ficha
        return False
    quadr = [r for r in pg.rects if 6 < r['width'] < 17 and 6 < r['height'] < 17 and abs(r['width'] - r['height']) < 4.5]
    colunas = {}
    for q in quadr:
        colunas[round(q['x0'])] = colunas.get(round(q['x0']), 0) + 1
    quadr_todos = list(quadr)
    quadr = [q for q in quadr if colunas[round(q['x0'])] < 3]      # quadrados em coluna = enfeite
    titulo_pg = ''
    if linhas:
        titulo_pg = max(linhas, key=lambda l: l['size'])['texto']
    contexto_rep = False
    # caixinhas de marcar (com texto logo à direita)
    usadas_label = set()
    melhor = {}
    for q in quadr:
        perto = [l for l in linhas if abs((l['top'] + l['bottom']) / 2 - (q['top'] + q['bottom']) / 2) < 8 and 0 <= l['x0'] - q['x1'] < 26]
        for l in perto:
            gap = l['x0'] - q['x1']
            if id(l) not in melhor or gap < melhor[id(l)][0]:
                melhor[id(l)] = (gap, q, l)
    for gap, q, l in melhor.values():
        if True:
            ch = 'marcar_' + I.slug_chave(l['texto'])
            caixas.append(_caixa(ch, n, q['x0'], q['top'], q['x1'], q['bottom'], tam=9, alinhar='centro', negrito=True))
            usados.add(ch)
            usadas_label.add(id(l))
    for l in sorted(linhas, key=lambda l: (l['top'], l['x0'])):
        if id(l) in usadas_label or l['size'] > 12 or l['texto'] == titulo_pg:
            continue
        r = I.norm(l['texto']).strip(' :')
        if re.match(r'^(dados do cliente|informacoes adicionais|registro do cliente)$', r):
            continue
        if 'representante' in r:
            contexto_rep = True
        # rótulo de caixinha de marcar ("☐ Vencimento"): não é campo de texto
        caixinha = [q for q in quadr if abs((l['top'] + l['bottom']) / 2 - (q['top'] + q['bottom']) / 2) < 8 and 0 <= l['x0'] - q['x1'] < 30]
        if not caixinha and re.match(r'^(prescricao|decadencia|vencimento|outros|autor|reu)\b', r):
            peq = [q for q in pg.rects if 6 < q['width'] < 20 and 6 < q['height'] < 20]
            caixinha = [q for q in peq if abs((l['top'] + l['bottom']) / 2 - (q['top'] + q['bottom']) / 2) < 8 and 0 <= l['x0'] - q['x1'] < 30]
            if not caixinha:
                continue          # opção de marcar sem quadradinho reconhecível: não vira campo de texto
        if caixinha:
            q = min(caixinha, key=lambda q: l['x0'] - q['x1'])
            ch = 'marcar_' + I.slug_chave(l['texto'])
            if ch not in usados:
                caixas.append(_caixa(ch, n, q['x0'], q['top'], q['x1'], q['bottom'], tam=9, alinhar='centro', negrito=True))
                usados.add(ch)
            continue
        abaixo = sorted([h for h in hs if h['top'] > l['bottom'] + 4 and h['x0'] <= l['x0'] + 3 and h['x0'] + h['width'] >= l['x0'] + 10
                         and h['top'] - l['bottom'] < 26], key=lambda h: h['top'])
        if not abaixo:
            continue
        base = abaixo[0]
        x1 = base['x0'] + base['width']
        # emenda segmentos vizinhos na mesma altura (célula mesclada)
        for h in sorted(hs, key=lambda h: h['x0']):
            if abs(h['top'] - base['top']) < 1 and h['x0'] - x1 < 14 and h['x0'] > x1 - 2:
                x1 = h['x0'] + h['width']
        top = l['bottom'] + 0.5
        # não invade o próximo rótulo / caixinha da mesma faixa
        obst = [o['x0'] for o in linhas if o is not l and o['x0'] > l['x0'] + 30 and o['top'] < base['top'] and o['bottom'] > top - 2]
        obst += [q['x0'] for q in quadr if q['x0'] > l['x0'] + 30 and q['top'] < base['top'] and q['bottom'] > top - 9]
        if obst:
            x1 = min(x1, min(obst) - 4)
        # várias linhas (pendências etc.)
        fundo = base['top']; esp = None
        seguintes = sorted([h for h in hs if h['top'] > base['top'] + 6 and abs(h['x0'] - base['x0']) < 6], key=lambda h: h['top'])
        ultimo = base; penult = base
        for h in seguintes:
            if h['top'] - ultimo['top'] > 26 or [o for o in linhas if ultimo['top'] < o['top'] < h['top']]:
                break
            esp = h['top'] - ultimo['top']; penult = ultimo; ultimo = h
        chave = None
        for pad, ch in ROTULOS_FICHA:
            if re.search(pad, r):
                chave = ch; break
        if contexto_rep and chave in ('cliente_cpf', 'cliente_telefone', 'cliente_email', 'cliente_whatsapp'):
            chave = {'cliente_cpf': 'rep_cpf', 'cliente_telefone': 'rep_telefone', 'cliente_whatsapp': 'rep_telefone',
                     'cliente_email': 'rep_email'}[chave]
        if not chave:
            chave = I.slug_chave(l['texto'])
        multi = ultimo is not base
        if multi and chave in CAMPOS_PADRAO and CAMPOS_PADRAO[chave][1] != 'texto_longo':
            # CPF, cidade, telefone…: uma linha só — dentro da caixa desenhada (entre as duas últimas linhas)
            multi = False; esp = None
            top = penult['top'] + 0.5; fundo = ultimo['top']
        if multi:
            fundo = ultimo['top']
        if x1 - 2 - l['x0'] < 30:          # espaço apertado demais: não é campo
            continue
        if chave in usados and not multi and chave not in ('cliente_nome',):
            chave = chave + '_2' if chave + '_2' not in usados else chave
        usados.add(chave)
        alt = fundo - top
        # letra proporcional à faixa e igual em toda a ficha (sem um campo maior que o outro)
        tam = min(9.5, max(7, esp * 0.62)) if multi else round(min(8.5, max(7, alt * 0.82)), 1)
        filtro = '|curta' if CAMPOS_PADRAO.get(chave, (0, ''))[1] == 'data' else ''
        caixas.append(_caixa(chave, n, l['x0'], top, x1 - 2, fundo - 0.5, tam=tam, negrito=True,
                             texto='{{' + chave + filtro + '}}', lh=round(esp, 2) if multi else None))
    return True


def _cor_hex(c):
    try:
        if c is None:
            return '#000000'
        if isinstance(c, (int, float)):
            c = (c, c, c)
        c = list(c)
        if len(c) == 1:
            c = c * 3
        if len(c) == 4:   # CMYK
            k = c[3]; c = [(1 - c[i]) * (1 - k) for i in range(3)]
        return '#%02X%02X%02X' % tuple(int(max(0, min(1, float(v))) * 255) for v in c[:3])
    except Exception:
        return '#000000'


def _fonte_css(nome):
    n = (nome or '').lower()
    if 'avenir' in n: return '"Avenir Next", Avenir, "Nunito Sans", Arial, sans-serif'
    if 'calibri' in n: return 'Calibri, Carlito, Arial, sans-serif'
    if 'times' in n: return '"Times New Roman", Times, serif'
    if 'courier' in n: return '"Courier New", Courier, monospace'
    if 'helvetica' in n: return 'Helvetica, Arial, sans-serif'
    return 'Arial, Helvetica, sans-serif'


def palavras_da_pagina(pg):
    """Palavras com posição, tamanho, fonte e cor (para escolher trechos que viram variáveis)."""
    out = []
    try:
        ws = pg.extract_words(keep_blank_chars=False, use_text_flow=False, extra_attrs=['size', 'fontname', 'non_stroking_color'])
    except Exception:
        ws = pg.extract_words(keep_blank_chars=False, use_text_flow=False, extra_attrs=['size', 'fontname'])
    for w in ws:
        if re.fullmatch(r'[_\s.]+', w['text']):
            continue
        fn = w.get('fontname') or ''
        out.append({'t': w['text'], 'x0': round(w['x0'], 1), 'top': round(w['top'], 1), 'x1': round(w['x1'], 1),
                    'bottom': round(w['bottom'], 1), 'size': round(w.get('size') or 9, 1), 'fonte': _fonte_css(fn),
                    'negrito': bool(re.search(r'bold|black|heavy|semibold|demi', fn, re.I)),
                    'cor': _cor_hex(w.get('non_stroking_color'))})
    return out


def cor_fundo(img, cx, k):
    """Cor predominante (clara) da área da caixa na imagem da página — para esconder as linhas de preencher à mão."""
    try:
        x0, y0 = max(0, int(cx['x'] * k)), max(0, int(cx['y'] * k))
        x1, y1 = min(img.width, int((cx['x'] + cx['w']) * k)), min(img.height, int((cx['y'] + cx['h']) * k))
        if x1 - x0 < 2 or y1 - y0 < 2:
            return '#FFFFFF'
        reg = img.crop((x0, y0, x1, y1)).convert('RGB').resize((max(1, (x1 - x0) // 3), max(1, (y1 - y0) // 3)))
        cont = {}
        for r, g, b in reg.getdata():
            if r + g + b > 520:
                q = (r // 4 * 4, g // 4 * 4, b // 4 * 4)
                cont[q] = cont.get(q, 0) + 1
        if not cont:
            return '#FFFFFF'
        r, g, b = max(cont, key=cont.get)
        return '#%02X%02X%02X' % (r, g, b)
    except Exception:
        return '#FFFFFF'


def aplicar_cobertura(caixas, imagens_pil, k):
    """As linhas "____" ficam escondidas por baixo do texto (cor do fundo de cada trecho)."""
    for cx in caixas:
        if cx.get('origem') == 'linha' and cx.get('pagina') is not None and cx['pagina'] < len(imagens_pil):
            cx['cobrir'] = True
            f = cor_fundo(imagens_pil[cx['pagina']], cx, k)
            try:   # quase branco vira branco (não deixa faixa cinza visível)
                if f and all(int(f[i:i + 2], 16) >= 244 for i in (1, 3, 5)):
                    f = '#FFFFFF'
            except ValueError:
                pass
            cx['fundo'] = f


def analisar(nome_arquivo, conteudo):
    import pdfplumber, pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(conteudo)
    imagens, tamanhos, pils = [], [], []
    for i in range(len(pdf)):
        pg = pdf[i]
        w, h = pg.get_size()
        img = pg.render(scale=150 / 72).to_pil().convert('RGB')
        pils.append(img)
        b = io.BytesIO(); img.save(b, 'PNG', optimize=True)
        imagens.append(b.getvalue()); tamanhos.append((round(w, 2), round(h, 2)))
    docs = []
    palavras = []
    with pdfplumber.open(io.BytesIO(conteudo)) as p:
        for n, pg in enumerate(p.pages):
            palavras.append(palavras_da_pagina(pg))
            linhas = _linhas_texto(pg)
            caixas, usados = [], set()
            topo = [l for l in linhas if l['top'] < float(pg.height) * 0.28 and l['size'] >= 12.5]
            titulo = max(topo, key=lambda l: l['size'])['texto'] if topo else ''
            eh_form = _detectar_formulario(pg, n, linhas, caixas, usados)
            _detectar_sublinhados(pg, n, linhas, caixas, usados)
            texto = '\n'.join(l['texto'] for l in linhas)
            repete = docs and titulo and I.norm(titulo) == I.norm(docs[-1]['titulo'] or '')   # cabeçalho repetido em cada página
            if (titulo and not repete) or not docs:
                docs.append({'titulo': titulo, 'paginas': [n], 'caixas': caixas, 'usados': usados, 'texto': texto,
                             'formulario': eh_form})
            else:
                d = docs[-1]
                d['paginas'].append(n); d['caixas'] += caixas; d['usados'] |= usados; d['texto'] += '\n' + texto
    # fonte do corpo do texto de cada página (os campos usam a mesma)
    fonte_pg = []
    for ws in palavras:
        cont = {}
        for w in ws:
            cont[w['fonte']] = cont.get(w['fonte'], 0) + len(w['t'])
        fonte_pg.append(max(cont, key=cont.get) if cont else None)
    for d in docs:
        aplicar_cobertura(d['caixas'], pils, 150 / 72)
        for cx in d['caixas']:
            if not cx.get('fonte') and cx.get('pagina') is not None and fonte_pg[cx['pagina']]:
                cx['fonte'] = fonte_pg[cx['pagina']]
    tema = I.titulo_bonito(re.sub(r'\b(kit|20\d\d)\b|[-–—_]+', ' ', I.limpar_nome_arquivo(nome_arquivo), flags=re.I))
    tema = re.sub(r'\s+', ' ', tema).strip()
    from . import biblioteca as B
    cats = [c['nome'] for c in B.categorias()]
    saida = []
    for d in docs:
        tit = I.titulo_bonito(d['titulo']) if d['titulo'] else I.titulo_bonito(I.limpar_nome_arquivo(nome_arquivo))
        nome = tit
        if tema and I.norm(tema) not in I.norm(tit):
            p_tit = set(re.findall(r'[a-z]{3,}', I.norm(tit))); p_tema = set(re.findall(r'[a-z]{3,}', I.norm(tema)))
            nome = tema if p_tit and p_tit <= p_tema else f'{tit} — {tema}'   # sem "Recibo X — Recibo X Y"
        cat, area = I.classificar(d['texto'], d['titulo'], nome_arquivo, cats)
        if cat == 'Kits de Atendimento':
            cat, area = I.classificar(d['texto'], d['titulo'], '', cats)
            if cat == 'Kits de Atendimento':
                cat = 'Outros'
        if re.search(r'\bcivel\b', I.norm(nome_arquivo + ' ' + d['texto'][:400])) and area in ('Geral', 'Previdenciário'):
            area = 'Cível'
        usados = list(d['usados'])
        if any(re.search(r'\w\([aA]\)', d['texto']) for _ in [0]) or 'cliente_nome' in usados:
            if 'cliente_genero' not in usados and re.search(r'\w\([aA]\)', d['texto']):
                usados.append('cliente_genero')
        campos = []
        ordem = list(CAMPOS_PADRAO.keys())
        for k in sorted(usados, key=lambda k: ordem.index(k) if k in ordem else 999):
            if k.startswith('marcar_'):
                campos.append({'chave': k, 'rotulo': k[7:].replace('_', ' ').capitalize(), 'tipo': 'caixa', 'grupo': 'Marcar', 'padrao': ''})
            elif k in CAMPOS_PADRAO:
                campos.append(campo_def(k))
            else:
                campos.append(campo_def(k, k.replace('_', ' ').capitalize(), 'texto_longo' if k in ('texto_livre',) else 'texto'))
        saida.append({'nome': nome, 'categoria': cat, 'area': area, 'descricao': '', 'paginas': d['paginas'],
                      'caixas': d['caixas'], 'campos': campos, 'genero': 'cliente_genero' if 'cliente_genero' in usados else '',
                      'valores_maiusculos': bool(d['formulario'] and re.search(r'registro|ficha|cadastro', I.norm(d['titulo'])))})
    kit_nome = ('Kit — ' + tema) if tema else 'Kit — ' + I.titulo_bonito(I.limpar_nome_arquivo(nome_arquivo))
    return {'modo': 'paginas', 'documentos': saida, 'imagens': imagens, 'tamanhos': tamanhos, 'palavras': palavras,
            'kit': {'criar': len(saida) > 1, 'nome': kit_nome, 'categoria': 'Kits de Atendimento'}}


# ------------------------------------------------------------------ valor com extenso (modelo "PDF original")
def _linhas_de_palavras(ws):
    linhas = []
    for w in sorted(ws, key=lambda w: (round(w['top']), w['x0'])):
        if linhas and abs(linhas[-1][0]['top'] - w['top']) < max(2.0, w.get('size', 10) * 0.3):
            linhas[-1].append(w)
        else:
            linhas.append([w])
    return [sorted(l, key=lambda w: w['x0']) for l in linhas]


def valor_com_extenso(meta):
    """Caixa de um campo de valor (R$) por cima de "180,00 (cento e oitenta reais)": o extenso do PDF ficava
    parado na imagem. Aqui a caixa passa a cobrir o valor E o extenso (até o fim da linha, reescrevendo o resto
    da frase), e o campo escreve os dois sozinho: "R$ 200,00 (duzentos reais)". Devolve True se mudou algo."""
    if meta.get('formato') != 'paginas':
        return False
    tipos = {c.get('chave'): c.get('tipo') for c in meta.get('campos') or []}
    palavras = meta.get('palavras') or []
    caixas = meta.get('caixas') or []
    mudou = False
    for cx in list(caixas):
        m = re.fullmatch(r'\{\{\s*([\w]+)\s*(\|\s*\w+\s*)?\}\}', (cx.get('texto') or '').strip())
        if not m or tipos.get(m.group(1)) != 'moeda' or cx.get('origem') == 'valor_extenso':
            continue
        ch = m.group(1)
        pg = cx.get('pagina', 0)
        ws = [w for w in (palavras[pg] if pg < len(palavras) else []) if w.get('t')]
        linhas = _linhas_de_palavras(ws)
        cy = cx['y'] + cx['h'] / 2
        li = next((i for i, l in enumerate(linhas)
                   if abs((l[0]['top'] + l[0]['bottom']) / 2 - cy) < max(cx['h'], l[0]['bottom'] - l[0]['top']) * 0.75), None)
        if li is None:
            continue
        linha = linhas[li]
        sob = lambda w: min(w['x1'], cx['x'] + cx['w']) - max(w['x0'], cx['x'])
        dentro = [i for i, w in enumerate(linha) if sob(w) > 0.5 * (w['x1'] - w['x0'])]
        if not dentro or not all(re.fullmatch(r'(R\$)?[\d\.,]+|R\$', linha[i]['t']) for i in dentro):
            continue
        ini, fim = dentro[0], dentro[-1]
        if ini > 0 and linha[ini - 1]['t'] == 'R$' and linha[ini]['x0'] - linha[ini - 1]['x1'] < 15:
            ini -= 1
        # o extenso logo depois: "(cento e oitenta reais)" — pode continuar nas linhas de baixo
        seq = [(li, j) for j in range(fim + 1, len(linha))] + [(k, j) for k in range(li + 1, min(li + 3, len(linhas)))
                                                                 for j in range(len(linhas[k]))]
        if not seq or not linhas[seq[0][0]][seq[0][1]]['t'].startswith('('):
            continue
        fecha = next((n for n, (k, j) in enumerate(seq) if ')' in linhas[k][j]['t']), None)
        if fecha is None:
            continue
        kf, jf = seq[fecha]
        ult = linhas[kf][jf]['t']
        resto = ult[ult.index(')') + 1:]
        depois = ''
        for w in linhas[kf][jf + 1:]:
            depois += ('' if re.fullmatch(r'[,.;:!?)\]]+', w['t']) or not depois else ' ') + w['t']
        texto = '{{' + ch + '}}' + resto + ((' ' + depois) if depois and not re.match(r'[,.;:]', depois) else depois)
        # o ponto final sozinho não fica guardado nas palavras: fim de parágrafo sem pontuação ganha o ponto
        prox = linhas[kf + 1] if kf + 1 < len(linhas) else None
        esp_ref = (linhas[kf][0]['top'] - linhas[kf - 1][0]['top']) if kf > 0 else 14
        fim_par = prox is None or prox[0]['top'] - linhas[kf][0]['top'] > esp_ref * 1.3
        if fim_par and not re.search(r'[.;:!?]$', texto):
            texto += '.'
        w0 = linha[ini]
        tam = round(w0.get('size') or cx.get('tam') or 11, 1)
        base = dict(origem='valor_extenso', pagina=pg, fonte=w0.get('fonte') or cx.get('fonte'), negrito=False, lh=None)
        fundo = cx.get('fundo') or '#FFFFFF'
        novas = []
        envolvidas = list(range(li, kf + 1))
        x_ini = w0['x0'] - 0.5
        alt = max(w['bottom'] for w in linha) - min(w['top'] for w in linha)
        if len(envolvidas) == 1:
            x_fim = linha[-1]['x1'] + 1
            novas.append(dict(base, x=round(x_ini, 1), y=round(min(w['top'] for w in linha) - 1, 1), w=round(x_fim - x_ini, 1),
                              h=round(alt + 2, 1), tam=tam, alinhar='esquerda', texto=texto, cobrir=True, fundo=fundo))
        else:
            esq = min(linhas[k][0]['x0'] for k in envolvidas[1:])
            dir_ = max(linhas[k][-1]['x1'] for k in envolvidas)
            esp = (linhas[envolvidas[-1]][0]['top'] - linha[0]['top']) / (len(envolvidas) - 1)
            for k in envolvidas:   # cobre o valor antigo, o extenso e o resto da frase
                l = linhas[k]
                xa = x_ini if k == li else l[0]['x0'] - 0.5
                xb = l[-1]['x1'] + 1
                topo = min(w['top'] for w in l)
                novas.append(dict(base, x=round(xa, 1), y=round(topo - 1, 1), w=round(xb - xa, 1), h=round(alt + 2, 1),
                                  tam=tam, alinhar='esquerda', texto='&nbsp;', cobrir=True, fundo=fundo))
            topo = min(w['top'] for w in linha) - max(0.0, (esp - alt) / 2)
            novas.append(dict(base, x=round(esq, 1), y=round(topo, 1), w=round(dir_ - esq, 1), h=round(esp * len(envolvidas), 1),
                              tam=tam, alinhar='esquerda', texto=texto, cobrir=False, fundo=None,
                              lh=round(esp, 2), recuo=round(w0['x0'] - esq, 1)))
        caixas.remove(cx)
        caixas.extend(novas)
        mudou = True
    return mudou
