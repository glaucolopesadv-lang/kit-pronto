"""Importação de papel timbrado (PDF, imagem ou Word) e detecção automática de margens."""
import io, os, platform, shutil, subprocess, tempfile, zipfile
from PIL import Image, ImageChops, ImageOps

A4_PX = (1654, 2339)   # 200 dpi
PX_CM = A4_PX[0] / 21.0


def _a4(img):
    img = img.convert('RGBA')
    fundo = Image.new('RGBA', img.size, (255, 255, 255, 255))
    fundo.alpha_composite(img)
    img = fundo.convert('RGB')
    # ajusta para A4 mantendo proporção
    alvo = A4_PX
    r = min(alvo[0] / img.width, alvo[1] / img.height)
    novo = img.resize((max(1, int(img.width * r)), max(1, int(img.height * r))), Image.LANCZOS)
    pg = Image.new('RGB', alvo, 'white')
    pg.paste(novo, ((alvo[0] - novo.width) // 2, (alvo[1] - novo.height) // 2))
    return pg


def png_bytes(img):
    b = io.BytesIO(); img.save(b, 'PNG', optimize=True); return b.getvalue()


def de_pdf(conteudo, pagina=0):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(conteudo)
    pg = pdf[min(pagina, len(pdf) - 1)]
    w = pg.get_width()
    img = pg.render(scale=A4_PX[0] / w).to_pil()
    return _a4(img)


def de_imagem(conteudo):
    return _a4(ImageOps.exif_transpose(Image.open(io.BytesIO(conteudo))))


def _docx_sem_corpo(conteudo, sem_texto_cabecalho=False):
    from docx import Document
    d = Document(io.BytesIO(conteudo))
    body = d.element.body
    for el in list(body):
        if not el.tag.endswith('}sectPr'):
            body.remove(el)
    if sem_texto_cabecalho:   # o texto do cabeçalho vai para o modelo; no papel timbrado ficam só as imagens
        W_T = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'
        for sec in d.sections:
            for hf in (sec.header, sec.first_page_header, sec.even_page_header):
                try:
                    for t in hf._element.iter(W_T):
                        t.text = ''
                except Exception:
                    pass
    d.add_paragraph('')
    b = io.BytesIO(); d.save(b); return b.getvalue()


def de_docx(conteudo, sem_texto_cabecalho=False):
    """Desenha a página do Word sem o texto (só cabeçalho/rodapé/marca d'água)."""
    vazio = _docx_sem_corpo(conteudo, sem_texto_cabecalho)
    tmp = tempfile.mkdtemp(prefix='bm-timb-')
    try:
        arq = os.path.join(tmp, 'timbrado.docx')
        with open(arq, 'wb') as f:
            f.write(vazio)
        soffice = shutil.which('soffice') or shutil.which('libreoffice')
        mac_lo = '/Applications/LibreOffice.app/Contents/MacOS/soffice'
        if not soffice and os.path.exists(mac_lo):
            soffice = mac_lo
        if soffice:
            try:
                subprocess.run([soffice, '--headless', '--convert-to', 'pdf', '--outdir', tmp, arq],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
                pdf = os.path.join(tmp, 'timbrado.pdf')
                if os.path.exists(pdf):
                    with open(pdf, 'rb') as f:
                        return de_pdf(f.read())
            except Exception:
                pass
        if platform.system() == 'Windows':
            try:   # Word do próprio Windows desenha o cabeçalho/rodapé
                from . import importador as _I
                pdf = _I.word_windows(arq, 'pdf')
                if pdf:
                    with open(pdf, 'rb') as f:
                        return de_pdf(f.read())
            except Exception:
                pass
        if platform.system() == 'Darwin' and shutil.which('qlmanage'):
            try:   # Quick Look do Mac desenha .docx nativamente
                subprocess.run(['qlmanage', '-t', '-s', '2339', '-o', tmp, arq],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
                png = arq + '.png'
                if os.path.exists(png):
                    return _a4(Image.open(png))
            except Exception:
                pass
        return _compor_docx(conteudo)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _compor_docx(conteudo):
    """Último recurso: posiciona as imagens do cabeçalho/rodapé conforme as âncoras do Word."""
    from lxml import etree
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
          'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
          'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
          'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
          'rel': 'http://schemas.openxmlformats.org/package/2006/relationships'}
    z = zipfile.ZipFile(io.BytesIO(conteudo))
    pg = Image.new('RGB', A4_PX, 'white')
    emu_px = A4_PX[0] / 7560000  # 21 cm em EMU
    for nome in z.namelist():
        if not (nome.startswith('word/header') or nome.startswith('word/footer')) or not nome.endswith('.xml'):
            continue
        xml = etree.fromstring(z.read(nome))
        rels = {}
        rp = 'word/_rels/' + os.path.basename(nome) + '.rels'
        if rp in z.namelist():
            for r in etree.fromstring(z.read(rp)).findall('rel:Relationship', ns):
                rels[r.get('Id')] = 'word/' + r.get('Target').lstrip('/').replace('../', '')
        for anc in xml.iter('{%s}anchor' % ns['wp']):
            try:
                ext = anc.find('wp:extent', ns)
                cx, cy = int(ext.get('cx')), int(ext.get('cy'))
                x = int(anc.find('wp:positionH/wp:posOffset', ns).text or 0)
                y = int(anc.find('wp:positionV/wp:posOffset', ns).text or 0)
                relH = anc.find('wp:positionH', ns).get('relativeFrom')
                if relH in ('margin', 'column'):
                    x += int(2.5 / 21 * 7560000)
                blip = anc.find('.//a:blip', ns)
                alvo = rels.get(blip.get('{%s}embed' % ns['r']))
                if not alvo or alvo.endswith('.svg'):
                    continue
                im = Image.open(io.BytesIO(z.read(alvo))).convert('RGBA')
                im = im.resize((max(1, int(cx * emu_px)), max(1, int(cy * emu_px))), Image.LANCZOS)
                pos = (int(x * emu_px), int(y * emu_px))
                if nome.startswith('word/footer') and anc.find('wp:positionV', ns).get('relativeFrom') not in ('page',):
                    pos = (pos[0], A4_PX[1] - int(2.5 * PX_CM) + pos[1])
                pg.paste(im, pos, im)
            except Exception:
                continue
    return pg


def detectar_margens(img):
    """Acha onde termina o cabeçalho e começa o rodapé (ignora marca d'água clara)."""
    g = img.convert('L').resize((A4_PX[0] // 4, A4_PX[1] // 4))
    w, h = g.size
    escuro = g.point(lambda v: 255 if v < 175 else 0)
    linhas = []
    px = escuro.load()
    for y in range(h):
        linhas.append(sum(1 for x in range(w) if px[x, y]) > 2)
    cm = h / 29.7
    topo = 0
    for y in range(int(h * 0.30)):
        if linhas[y]:
            topo = y
    base = h
    for y in range(h - 1, int(h * 0.72), -1):
        if linhas[y]:
            base = y
    sup = round(max(2.0, topo / cm + 0.9), 1) if topo else 2.5
    inf = round(max(1.5, (h - base) / cm + 0.8), 1) if base < h else 2.0
    return {'sup': sup, 'inf': inf, 'esq': 2.5, 'dir': 2.5}


def parecido(img_a, img_b):
    """0 = idênticos; quanto maior, mais diferentes."""
    a = img_a.convert('L').resize((60, 85)); b = img_b.convert('L').resize((60, 85))
    d = ImageChops.difference(a, b)
    return sum(d.getdata()) / (60 * 85)


def importar(nome_arquivo, conteudo, sem_texto_cabecalho=False):
    ext = os.path.splitext(nome_arquivo)[1].lower()
    if ext == '.pdf':
        img = de_pdf(conteudo)
    elif ext in ('.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.tif', '.tiff', '.heic'):
        img = de_imagem(conteudo)
    elif ext == '.docx':
        img = de_docx(conteudo, sem_texto_cabecalho)
    else:
        raise ValueError('Formato não suportado para timbrado. Use PDF, imagem (PNG/JPG) ou Word (.docx).')
    return img, detectar_margens(img)
