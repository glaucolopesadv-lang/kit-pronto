"""Tirar a foto dos documentos com o celular.

Um servidor pequeno e separado, na rede Wi-Fi, que só sabe duas coisas: mostrar a página da câmera
e receber as fotos — e só para quem tem o código (token) do QR. O resto do programa continua
fechado no próprio computador (127.0.0.1)."""
import secrets, socket, threading, time

from flask import Flask, request, jsonify, abort

VALIDADE = 20 * 60          # o QR vale 20 minutos
MAX_FOTOS = 3               # até 3 fotos por envio (ex.: RG frente, RG verso, comprovante)
SESSOES = {}                # token -> {'arquivos': [(nome, bytes)], 'pronto': bool, 'criado': t, 'visto': bool}
_trava = threading.Lock()
_srv = {'porta': None}


def ip_local():
    """IP do computador na rede (Wi-Fi). Não envia nada pela internet."""
    for alvo in ('8.8.8.8', '192.168.0.1', '10.0.0.1'):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((alvo, 80)); ip = s.getsockname()[0]; s.close()
            if ip and not ip.startswith('127.'):
                return ip
        except OSError:
            continue
    return None


def _limpar():
    agora = time.time()
    for t in [t for t, s in SESSOES.items() if agora - s['criado'] > VALIDADE]:
        SESSOES.pop(t, None)


def _sessao(tok):
    with _trava:
        _limpar()
        s = SESSOES.get(tok)
    if not s:
        abort(404)
    return s


app_cel = Flask('kitpronto_celular')
app_cel.config['MAX_CONTENT_LENGTH'] = 60 * 1024 * 1024


@app_cel.route('/m/<tok>')
def pagina(tok):
    s = _sessao(tok); s['visto'] = True
    return PAGINA.replace('__TOKEN__', tok), 200, {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'}


@app_cel.route('/m/<tok>/enviar', methods=['POST'])
def enviar(tok):
    s = _sessao(tok)
    for f in request.files.getlist('fotos')[:MAX_FOTOS]:
        b = f.read()
        if b:
            s['arquivos'].append((f.filename or 'foto.jpg', b))
    s['arquivos'] = s['arquivos'][:MAX_FOTOS]
    s['pronto'] = True
    return jsonify(ok=True, n=len(s['arquivos']))


def _subir():
    if _srv['porta']:
        return _srv['porta']
    from werkzeug.serving import make_server
    for porta in range(5090, 5110):
        try:
            srv = make_server('0.0.0.0', porta, app_cel, threaded=True)
        except OSError:
            continue
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        _srv['porta'] = porta
        return porta
    raise RuntimeError('Não achei uma porta livre para o celular.')


def nova_sessao():
    ip = ip_local()
    if not ip:
        raise RuntimeError('O computador não está conectado a uma rede Wi-Fi.')
    porta = _subir()
    tok = secrets.token_urlsafe(9)
    with _trava:
        _limpar()
        SESSOES[tok] = {'arquivos': [], 'pronto': False, 'criado': time.time(), 'visto': False}
    return tok, f'http://{ip}:{porta}/m/{tok}'


def estado(tok):
    s = SESSOES.get(tok)
    if not s:
        return None
    return {'visto': s['visto'], 'pronto': s['pronto'], 'n': len(s['arquivos'])}


def retirar(tok):
    """Entrega as fotos recebidas e apaga a sessão (as fotos não ficam guardadas)."""
    with _trava:
        s = SESSOES.pop(tok, None)
    return s['arquivos'] if s else []


PAGINA = r'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Kit Pronto — Fotos dos documentos</title>
<style>
  :root { --navy:#14213D; --ouro:#C9A240; --fundo:#EEF0F4; }
  * { box-sizing: border-box; }
  body { margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; background:var(--fundo); color:#1B2233; }
  header { background:var(--navy); color:#fff; padding:18px 20px 16px; border-bottom:4px solid var(--ouro); }
  header h1 { margin:0; font-size:20px; letter-spacing:.02em; }
  header p { margin:4px 0 0; color:var(--ouro); font-size:13px; }
  main { padding:16px; max-width:560px; margin:0 auto; }
  .card { background:#fff; border-radius:16px; padding:16px; box-shadow:0 2px 10px rgba(20,33,61,.08); margin-bottom:14px; }
  .dica { color:#687387; font-size:14px; line-height:1.45; margin:0 0 12px; }
  .bt { display:flex; align-items:center; justify-content:center; gap:10px; width:100%; border:0; border-radius:14px; padding:17px; font-size:17px; font-weight:700; cursor:pointer; }
  .bt + .bt { margin-top:10px; }
  .foto { background:var(--ouro); color:var(--navy); }
  .galeria { background:#fff; color:var(--navy); border:1.5px solid #C9CFDA; }
  .enviar { background:var(--navy); color:#fff; }
  .bt:disabled { opacity:.45; }
  .grade { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; }
  .grade div { position:relative; aspect-ratio:3/4; border-radius:10px; overflow:hidden; background:#DDE1E8; }
  .grade img { width:100%; height:100%; object-fit:cover; }
  .grade button { position:absolute; top:4px; right:4px; width:28px; height:28px; border-radius:50%; border:0; background:rgba(0,0,0,.6); color:#fff; font-size:16px; }
  .vazio { color:#9AA3B2; font-size:14px; text-align:center; padding:14px 0; }
  .fim { text-align:center; padding:30px 10px; }
  .fim b { display:block; font-size:22px; color:var(--navy); margin:10px 0 6px; }
  .barra { height:6px; background:#E6E9EF; border-radius:3px; overflow:hidden; margin-top:12px; display:none; }
  .barra i { display:block; height:100%; width:0; background:var(--ouro); transition:width .2s; }
  input[type=file] { display:none; }
</style></head><body>
<header><h1>KIT PRONTO</h1><p>Fotos dos documentos do cliente</p></header>
<main id="tela">
  <div class="card">
    <p class="dica">Tire <b>até 3 fotos</b>: por exemplo <b>RG/CNH frente</b>, <b>verso</b> e <b>comprovante de residência</b>. Apoie numa mesa, com boa luz e sem reflexo.</p>
    <button class="bt foto" id="btFoto" onclick="document.getElementById('cam').click()">📷 Tirar foto</button>
    <button class="bt galeria" id="btGal" onclick="document.getElementById('gal').click()">🖼️ Escolher da galeria / PDF</button>
    <input type="file" id="cam" accept="image/*" capture="environment">
    <input type="file" id="gal" accept="image/*,application/pdf" multiple>
  </div>
  <div class="card">
    <div class="grade" id="grade"></div><div class="vazio" id="vazio">Nenhuma foto ainda</div>
    <button class="bt enviar" id="btEnviar" disabled onclick="enviar()" style="margin-top:14px">Enviar para o computador</button>
    <div class="barra" id="barra"><i id="prog"></i></div>
  </div>
</main>
<script>
const TOKEN = '__TOKEN__';
const fotos = []; const MAX = 3;
function desenhar() {
  const g = document.getElementById('grade');
  g.innerHTML = fotos.map((f, i) => `<div>${f.tipo === 'pdf' ? '<span style="display:grid;place-items:center;height:100%;font-weight:700">PDF</span>' : `<img src="${f.url}">`}<button onclick="tirar(${i})">×</button></div>`).join('');
  document.getElementById('vazio').style.display = fotos.length ? 'none' : 'block';
  const cheio = fotos.length >= MAX;
  document.getElementById('btFoto').disabled = cheio; document.getElementById('btGal').disabled = cheio;
  document.getElementById('btFoto').textContent = cheio ? 'Limite de 3 fotos (apague uma para trocar)' : (fotos.length ? `📷 Tirar foto ${fotos.length + 1} de ${MAX}` : '📷 Tirar foto');
  const b = document.getElementById('btEnviar'); b.disabled = !fotos.length;
  b.textContent = fotos.length ? `Enviar ${fotos.length} arquivo${fotos.length > 1 ? 's' : ''} para o computador` : 'Enviar para o computador';
}
function tirar(i) { fotos.splice(i, 1); desenhar(); }
function reduzir(file) {   // fotos grandes ficam com ~2400 px para enviar mais rápido
  return new Promise((ok) => {
    if (!file.type.startsWith('image/')) return ok(file);
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = () => {
      const max = 2400, esc = Math.min(1, max / Math.max(img.width, img.height));
      if (esc === 1 && file.size < 2500000) return ok(file);
      const c = document.createElement('canvas'); c.width = Math.round(img.width * esc); c.height = Math.round(img.height * esc);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      c.toBlob((b) => ok(b ? new File([b], (file.name || 'foto').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file), 'image/jpeg', 0.88);
    };
    img.onerror = () => ok(file); img.src = url;
  });
}
async function adicionar(lista) {
  for (const f of lista) {
    if (fotos.length >= MAX) { alert('Cabem até 3 fotos. As demais não foram adicionadas.'); break; }
    const r = await reduzir(f);
    fotos.push({ arq: r, tipo: r.type === 'application/pdf' ? 'pdf' : 'img', url: URL.createObjectURL(r) });
  }
  desenhar();
}
document.getElementById('cam').onchange = (e) => { const l = Array.from(e.target.files); e.target.value = ''; adicionar(l); };
document.getElementById('gal').onchange = (e) => { const l = Array.from(e.target.files); e.target.value = ''; adicionar(l); };
function enviar() {
  const fd = new FormData(); fotos.forEach((f, i) => fd.append('fotos', f.arq, f.arq.name || `foto${i + 1}.jpg`));
  const x = new XMLHttpRequest(); x.open('POST', `/m/${TOKEN}/enviar`);
  document.getElementById('barra').style.display = 'block'; document.getElementById('btEnviar').disabled = true;
  x.upload.onprogress = (e) => { if (e.lengthComputable) document.getElementById('prog').style.width = (e.loaded / e.total * 100) + '%'; };
  x.onload = () => {
    if (x.status === 200) document.getElementById('tela').innerHTML = '<div class="card fim"><div style="font-size:54px">✅</div><b>Fotos enviadas!</b><p class="dica">O computador já está lendo os documentos. Pode guardar o celular.</p></div>';
    else { alert('Não consegui enviar (o código pode ter expirado). Gere um novo QR no computador.'); document.getElementById('btEnviar').disabled = false; }
  };
  x.onerror = () => { alert('Sem conexão com o computador. Confira se o celular está no mesmo Wi-Fi.'); document.getElementById('btEnviar').disabled = false; };
  x.send(fd);
}
desenhar();
</script></body></html>'''
