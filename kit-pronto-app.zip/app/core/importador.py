"""Importação de modelos: lê o arquivo, transforma em modelo com {{campos}}, classifica,
sugere nome e pasta. Funciona sem internet (regras). Se houver chave do Gemini nas
configurações, a IA refina a classificação e acha campos que as regras não pegaram."""
import base64, collections, html as H, io, json, os, platform, re, shutil, ssl, subprocess, tempfile, unicodedata, urllib.request

from lxml import html as LH, etree

from . import biblioteca as B

# ===================================================================== utilidades
def norm(t):
    return unicodedata.normalize('NFKD', t or '').encode('ascii', 'ignore').decode().lower()


SIGLAS = {'INSS', 'BPC', 'LOAS', 'RPV', 'CPF', 'CNPJ', 'OAB', 'CNIS', 'LGPD', 'JEF', 'TRF', 'RN', 'PB', 'CE', 'PE',
          'CTPS', 'FGTS', 'CLT', 'NB', 'DER', 'DIB', 'RG', 'CEP', 'PIS', 'NIT', 'JRPS', 'CRPS', 'TNU', 'STJ', 'STF',
          'II', 'III', 'IV', 'VI', 'VII', 'VIII', 'IX', 'XI', 'XII', 'XIII', 'PAB', 'MEI', 'CNH', 'SUS'}
MINUSC = {'de', 'da', 'do', 'das', 'dos', 'e', 'a', 'o', 'as', 'os', 'em', 'para', 'por', 'com', 'no', 'na',
          'nos', 'nas', 'à', 'às', 'ao', 'aos', 'ou', 'et', 'um', 'uma', 'sem', 'sob'}


def titulo_bonito(t):
    t = re.sub(r'\s+', ' ', (t or '').strip(' -–—:.'))
    palavras = []
    for i, p in enumerate(t.split(' ')):
        limpo = re.sub(r'[^\wÀ-ú]', '', p)
        if limpo.upper() in SIGLAS and (limpo.isupper() or len(limpo) <= 4):
            palavras.append(p.upper())
        elif i > 0 and p.lower() in MINUSC:
            palavras.append(p.lower())
        elif p in ('-', '–', '—'):
            palavras.append('—')
        else:
            palavras.append(p[:1].upper() + p[1:].lower())
    s = ' '.join(palavras)
    return re.sub(r'\s*—\s*', ' — ', s).strip()


def plural(p):
    lp = p.lower()
    if lp.endswith('ção'): return p[:-3] + 'ções'
    if lp.endswith('são'): return p[:-3] + 'sões'
    if lp.endswith('ão'): return p[:-2] + 'ões'
    if lp.endswith(('r', 'z')): return p + 'es'
    if lp.endswith('l'): return p[:-1] + 'is'
    if lp.endswith('m'): return p[:-1] + 'ns'
    if lp.endswith('s'): return p
    return p + 's'


# ===================================================================== leitura dos arquivos
def _esc(t):
    return H.escape(t or '', quote=False)


def docx_para_html(conteudo):
    """Word -> HTML simples do modelo. Retorna (html, info)."""
    from docx import Document
    from docx.oxml.ns import qn
    d = Document(io.BytesIO(conteudo))
    fontes, tamanhos = collections.Counter(), collections.Counter()
    estilo_normal = d.styles['Normal']
    fonte_padrao = estilo_normal.font.name
    try:
        rf = d.styles.element.find(qn('w:docDefaults')).find('.//' + qn('w:rFonts'))
        fonte_padrao = fonte_padrao or (rf.get(qn('w:ascii')) if rf is not None else None)
        tema = rf.get(qn('w:asciiTheme')) if rf is not None else None
        if not fonte_padrao and tema:
            fonte_padrao = 'Calibri'
    except Exception:
        pass
    tam_padrao = estilo_normal.font.size.pt if estilo_normal.font.size else 11
    partes = []

    def run_html(r, p):
        t = r.text or ''
        if not t:
            if r._r.findall('.//' + qn('w:br')):
                for br in r._r.findall('.//' + qn('w:br')):
                    if br.get(qn('w:type')) == 'page':
                        return '\x00PAGEBREAK\x00'
                return '<br>'
            return ''
        if r.font.name: fontes[r.font.name] += len(t)
        if r.font.size: tamanhos[r.font.size.pt] += len(t)
        t = _esc(t).replace('\t', ' ').replace('\n', '<br>')
        b = r.bold if r.bold is not None else (p.style.font.bold if p.style is not None else None)
        it = r.italic if r.italic is not None else None
        u = r.underline
        estilo = []
        if r.font.color is not None and r.font.color.type is not None and r.font.color.rgb not in (None,) and str(r.font.color.rgb) not in ('000000', 'auto'):
            estilo.append(f'color:#{r.font.color.rgb}')
        if r.font.size and abs(r.font.size.pt - tam_padrao) >= 1.5:
            estilo.append(f'font-size:{r.font.size.pt:g}pt')
        if estilo: t = f'<span style="{";".join(estilo)}">{t}</span>'
        if u: t = f'<u>{t}</u>'
        if it: t = f'<i>{t}</i>'
        if b: t = f'<b>{t}</b>'
        return t

    def par_html(p):
        al = p.alignment if p.alignment is not None else (p.style.paragraph_format.alignment if p.style is not None else None)
        cls = {1: 'centro', 2: 'direita', 3: None, 0: 'esquerda'}.get(int(al) if al is not None else -1)
        conteudo_p = ''.join(run_html(r, p) for r in _juntar_runs(p))
        if '\x00PAGEBREAK\x00' in conteudo_p:
            antes, _, depois = conteudo_p.partition('\x00PAGEBREAK\x00')
            return (par_html_txt(antes, cls) if antes.strip() else '') + '<div class="quebra-pagina"></div>' + (par_html_txt(depois, cls) if depois.strip() else '')
        if not p.text.strip() and '<br>' not in conteudo_p:
            return '<p class="vazio">&nbsp;</p>'
        return par_html_txt(conteudo_p, cls)

    def _juntar_runs(p):
        """Word quebra o texto em muitos pedaços; junta os vizinhos com a mesma formatação."""
        import copy as _c
        out = []
        for r in p.runs:
            chave = (r.bold, r.italic, bool(r.underline), r.font.size, str(r.font.color.rgb) if r.font.color is not None and r.font.color.type is not None else None)
            tem_br = bool(r._r.findall('.//' + qn('w:br')))
            if out and out[-1][0] == chave and not tem_br and not out[-1][2]:
                out[-1][1].text = (out[-1][1].text or '') + (r.text or '')
            else:
                novo = r
                if not tem_br:
                    from docx.text.run import Run
                    novo = Run(_c.deepcopy(r._r), p)
                out.append([chave, novo, tem_br])
        return [x[1] for x in out]

    def par_html_txt(c, cls):
        return f'<p class="{cls}">{c}</p>' if cls else f'<p>{c}</p>'

    body = d.element.body
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    for el in body.iterchildren():
        if el.tag == qn('w:p'):
            partes.append(par_html(Paragraph(el, d)))
        elif el.tag == qn('w:tbl'):
            t = Table(el, d)
            linhas = []
            for row in t.rows:
                cels, vistos = [], set()
                for c in row.cells:
                    if id(c._tc) in vistos:
                        continue
                    vistos.add(id(c._tc))
                    cels.append('<td>' + ''.join(par_html(p) for p in c.paragraphs) + '</td>')
                linhas.append('<tr>' + ''.join(cels) + '</tr>')
            partes.append('<table class="bordas">' + ''.join(linhas) + '</table>')
    # remove vazios do fim
    while partes and partes[-1] == '<p class="vazio">&nbsp;</p>':
        partes.pop()
    fonte = (fontes.most_common(1)[0][0] if fontes else None) or fonte_padrao or 'Calibri'
    tam = tamanhos.most_common(1)[0][0] if tamanhos else tam_padrao
    # o documento tem timbrado (imagens no cabeçalho/rodapé)?
    tem_timbrado = False
    for s in d.sections:
        for hf in (s.header, s.footer, s.first_page_header):
            try:
                if hf._element.findall('.//' + qn('w:drawing')) or hf._element.findall('.//' + qn('w:pict')):
                    tem_timbrado = True
            except Exception:
                pass
    s0 = d.sections[0]
    margens = None
    try:
        margens = {'sup': round(s0.top_margin.cm, 1), 'inf': round(s0.bottom_margin.cm, 1),
                   'esq': round(s0.left_margin.cm, 1), 'dir': round(s0.right_margin.cm, 1)}
    except Exception:
        pass
    return '\n'.join(partes), {'fonte': fonte, 'tamanho': round(float(tam) * 2) / 2, 'tem_timbrado': tem_timbrado, 'margens': margens}


def pdf_para_html(conteudo):
    import pdfplumber
    partes, fontes, tamanhos = [], collections.Counter(), collections.Counter()
    with pdfplumber.open(io.BytesIO(conteudo)) as pdf:
        for npg, pg in enumerate(pdf.pages):
            if npg:
                partes.append('<div class="quebra-pagina"></div>')
            try:
                linhas = pg.extract_text_lines(return_chars=True, strip=True)
            except Exception:
                linhas = []
            W = float(pg.width)
            ult_base, ult_alt, atual, atual_cls = None, None, [], None

            def fecha():
                if atual:
                    txt = ' '.join(atual)
                    partes.append(f'<p class="{atual_cls}">{txt}</p>' if atual_cls else f'<p>{txt}</p>')

            for ln in linhas:
                chars = ln.get('chars') or []
                txt = ln['text']
                if not txt.strip():
                    continue
                alt = (ln['bottom'] - ln['top']) or 10
                negrito = sum(1 for c in chars if 'bold' in (c.get('fontname') or '').lower()) > len(chars) * 0.6
                for c in chars:
                    fontes[re.sub(r'^[A-Z]{6}\+', '', c.get('fontname') or '')] += 1
                    tamanhos[round(c.get('size', 10))] += 1
                centro = (ln['x0'] + ln['x1']) / 2
                larg = ln['x1'] - ln['x0']
                cls = None
                if abs(centro - W / 2) < W * 0.04 and larg < W * 0.7:
                    cls = 'centro'
                elif ln['x0'] > W * 0.5:
                    cls = 'direita'
                t = _esc(txt)
                if negrito:
                    t = f'<b>{t}</b>'
                novo_par = (ult_base is None or ln['top'] - ult_base > alt * 0.9 or cls != atual_cls or cls == 'centro')
                if novo_par:
                    fecha()
                    atual, atual_cls = [t], cls
                else:
                    atual.append(t)
                ult_base = ln['bottom']
            fecha()
    fonte = fontes.most_common(1)[0][0] if fontes else 'Arial'
    fonte = re.sub(r'(PSMT|MT|PS|LTPro|LT)?[-,]?(Bold|Roman|Book|Regular|Italic|Light|Medium).*$', '', fonte) or 'Arial'
    fonte = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', fonte).replace('  ', ' ').strip()
    tam = tamanhos.most_common(1)[0][0] if tamanhos else 11
    return '\n'.join(partes), {'fonte': fonte, 'tamanho': tam, 'tem_timbrado': False}


def texto_para_html(t):
    pars = re.split(r'\n\s*\n', t.replace('\r', ''))
    return '\n'.join(f'<p>{_esc(p).replace(chr(10), "<br>")}</p>' for p in pars if p.strip()), {'fonte': 'Calibri', 'tamanho': 12}


def _converter_mac(arquivo, destino_ext='docx'):
    """.doc/.rtf/.odt -> .docx com o textutil do macOS."""
    if platform.system() != 'Darwin' or not shutil.which('textutil'):
        return None
    saida = os.path.splitext(arquivo)[0] + '.' + destino_ext
    subprocess.run(['textutil', '-convert', destino_ext, arquivo, '-output', saida],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
    return saida if os.path.exists(saida) else None


def _pages_para_docx(arquivo):
    """Usa o próprio Pages (se instalado) para exportar como Word."""
    if platform.system() != 'Darwin':
        return None
    saida = os.path.splitext(arquivo)[0] + '.docx'
    script = f'''
    set entrada to POSIX file "{arquivo}"
    set saida to POSIX file "{saida}"
    tell application "Pages"
        set d to open entrada
        export d to saida as Microsoft Word
        close d saving no
    end tell'''
    try:
        subprocess.run(['osascript', '-e', script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    except Exception:
        return None
    return saida if os.path.exists(saida) else None


def word_windows(arquivo, destino_ext='docx'):
    """No Windows: usa o próprio Microsoft Word (se instalado) para converter (.doc → .docx, .docx → .pdf)."""
    if platform.system() != 'Windows':
        return None
    saida = os.path.splitext(arquivo)[0] + '.' + destino_ext
    fmt = {'docx': 16, 'pdf': 17}[destino_ext]
    a = arquivo.replace("'", "''"); o = saida.replace("'", "''")
    ps = ("$w = New-Object -ComObject Word.Application; $w.Visible = $false; $w.DisplayAlerts = 0; "
          f"try {{ $d = $w.Documents.Open('{a}', $false, $true); $d.SaveAs2('{o}', {fmt}); $d.Close(0) }} finally {{ $w.Quit() }}")
    try:
        subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120, creationflags=0x08000000)
    except Exception:
        return None
    return saida if os.path.exists(saida) else None


def _soffice_docx(arquivo):
    soffice = shutil.which('soffice') or ('/Applications/LibreOffice.app/Contents/MacOS/soffice'
                                          if os.path.exists('/Applications/LibreOffice.app/Contents/MacOS/soffice') else None)
    if not soffice:
        return None
    pasta = os.path.dirname(arquivo)
    subprocess.run([soffice, '--headless', '--convert-to', 'docx', '--outdir', pasta, arquivo],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    saida = os.path.splitext(arquivo)[0] + '.docx'
    return saida if os.path.exists(saida) else None


def ler(nome, conteudo):
    """Retorna (html, info, docx_bytes|None)."""
    ext = os.path.splitext(nome)[1].lower()
    if ext in ('.docx', '.dotx', '.docm'):
        h, info = docx_para_html(conteudo); return h, info, conteudo
    if ext == '.pdf':
        h, info = pdf_para_html(conteudo); return h, info, None
    if ext in ('.txt', '.md'):
        h, info = texto_para_html(conteudo.decode('utf-8', 'replace')); return h, info, None
    if ext in ('.html', '.htm'):
        raiz = LH.fromstring(conteudo.decode('utf-8', 'replace'))
        for bad in raiz.xpath('//script|//style|//head'):
            bad.getparent().remove(bad)
        corpo = raiz.find('body') if raiz.find('body') is not None else raiz
        return ''.join(etree.tostring(c, encoding='unicode', method='html') for c in corpo), {'fonte': 'Calibri', 'tamanho': 12}, None
    if ext in ('.doc', '.rtf', '.odt', '.pages', '.wpd'):
        tmp = tempfile.mkdtemp(prefix='bm-imp-')
        try:
            arq = os.path.join(tmp, 'entrada' + ext)
            with open(arq, 'wb') as f:
                f.write(conteudo)
            docx = None
            if ext == '.pages':
                docx = _pages_para_docx(arq)
                if not docx:
                    raise ValueError('Para importar arquivo do Pages, o programa usa o próprio Pages do Mac. '
                                     'Se não funcionar, abra o arquivo no Pages e use Arquivo > Exportar para > Word, '
                                     'e importe o .docx gerado.')
            else:
                docx = _converter_mac(arq) or word_windows(arq) or _soffice_docx(arq)
            if not docx:
                raise ValueError(f'Não consegui converter o arquivo {ext}. Salve-o como Word (.docx) ou PDF e importe de novo.')
            with open(docx, 'rb') as f:
                dados = f.read()
            h, info = docx_para_html(dados)
            return h, info, dados
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    raise ValueError('Formato não suportado. Use Word (.docx/.doc), PDF, Pages, RTF, ODT, TXT ou HTML.')


# ===================================================================== campos
def _carregar_fixos():
    """Dados fixos do escritório (CPFs/CNPJs/nomes dos advogados) que NÃO são do cliente.
    Ficam fora do código: em seed/escritorio.json e/ou em config.json ('escritorio_fixos')."""
    fx = {'cpf': set(), 'cnpj': set(), 'nomes': []}
    fontes = [os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'seed', 'escritorio.json')]
    try:
        from . import biblioteca as _B
        fontes.append(_B.P_CONFIG)
    except Exception:
        pass
    for f in fontes:
        try:
            with open(f, encoding='utf-8') as fh:
                d = json.load(fh)
            d = d.get('escritorio_fixos', d) if f.endswith('config.json') else d
            if not isinstance(d, dict):
                continue
            fx['cpf'] |= set(d.get('cpf') or [])
            fx['cnpj'] |= set(d.get('cnpj') or [])
            fx['nomes'] += [n for n in (d.get('nomes') or []) if n not in fx['nomes']]
        except Exception:
            pass
    return fx


ESCRITORIO_FIXOS = _carregar_fixos()

# (padrão no rótulo, chave, rótulo bonito, tipo, grupo)
MAPA_ROTULOS = [
    (r'testemunha.*cpf|cpf.*testemunha', 'testemunha1_cpf', 'Testemunha — CPF', 'cpf', 'Testemunhas'),
    (r'testemunha', 'testemunha1_nome', 'Testemunha — nome', 'texto', 'Testemunhas'),
    (r'nascimento|nascid', 'cliente_nascimento', 'Data de nascimento', 'data', 'Cliente'),
    (r'\bcnpj\b', 'cnpj', 'CNPJ', 'cnpj', 'Cliente'),
    (r'\bcpf\b', 'cliente_cpf', 'CPF', 'cpf', 'Cliente'),
    (r'\brg\b|identidade|registro geral', 'cliente_rg', 'RG / Identidade', 'texto', 'Cliente'),
    (r'nacionalidade', 'cliente_nacionalidade', 'Nacionalidade', 'texto', 'Cliente'),
    (r'estado civil', 'cliente_estado_civil', 'Estado civil', 'opcoes', 'Cliente'),
    (r'profiss', 'cliente_profissao', 'Profissão', 'texto', 'Cliente'),
    (r'\bcep\b', 'cliente_cep', 'CEP', 'cep', 'Endereço'),
    (r'bairro', 'cliente_bairro', 'Bairro', 'texto', 'Endereço'),
    (r'municipio|cidade', 'cliente_cidade', 'Cidade', 'texto', 'Endereço'),
    (r'\buf\b', 'cliente_uf', 'UF', 'uf', 'Endereço'),
    (r'endereco|resid|domicil|\brua\b|logradouro|\bmoro\b', 'cliente_endereco', 'Endereço', 'texto', 'Endereço'),
    (r'whats|telefone|celular|\bfone\b|contato tel', 'cliente_telefone', 'Telefone / WhatsApp', 'telefone', 'Contato'),
    (r'e-?mail', 'cliente_email', 'E-mail', 'email', 'Contato'),
    (r'\bnb\b|numero do beneficio|beneficio n', 'numero_beneficio', 'Número do benefício (NB)', 'texto', 'Processo'),
    (r'processo n|n.? do processo|autos', 'numero_processo', 'Número do processo', 'texto', 'Processo'),
    (r'\bnit\b|\bpis\b', 'cliente_nit', 'NIT / PIS', 'texto', 'Cliente'),
    (r'valor|quantia|importancia|r\$', 'valor', 'Valor (R$)', 'moeda', 'Pagamento'),
    (r'^data\b|\bdata:?$', 'data_documento', 'Data do documento', 'data', 'Data e local'),
    (r'nome|outorgante|contratante|declarante|requerente|^eu$|eu,?$', 'cliente_nome', 'Nome completo', 'texto', 'Cliente'),
]

PADROES_CAMPO = {
    'cliente_cidade': 'Mossoró', 'cliente_uf': 'RN', 'local': 'Mossoró/RN', 'data_documento': 'hoje',
}
EC = ['solteiro(a)', 'casado(a)', 'divorciado(a)', 'separado(a) judicialmente', 'viúvo(a)', 'em união estável']


def _campo(chave, rotulo, tipo='texto', grupo='Geral', **extra):
    d = {'chave': chave, 'rotulo': rotulo, 'tipo': tipo, 'grupo': grupo, 'padrao': PADROES_CAMPO.get(chave, '')}
    if chave == 'cliente_estado_civil':
        d['opcoes'] = EC
    d.update(extra)
    return d


def rotulo_para_campo(rotulo, usados):
    r = norm(rotulo).strip(' :.-–—_º°ª')
    r = re.sub(r'\b(n|no|nº|n°|numero|sob o)\.?$', '', r).strip(' :.-')
    for pad, chave, bonito, tipo, grupo in MAPA_ROTULOS:
        if re.search(pad, r):
            return _campo(chave, bonito, tipo, grupo)
    palavras = [p for p in re.findall(r'[a-z0-9]+', r) if p not in ('de', 'da', 'do', 'e', 'o', 'a', 'em', 'no', 'na')][-3:]
    if not palavras:
        n = 1
        while f'campo_{n}' in usados:
            n += 1
        return _campo(f'campo_{n}', f'Campo {n}')
    chave = '_'.join(palavras)[:40]
    bonito = re.sub(r'\s+', ' ', rotulo.strip(' :.-_')).strip()
    bonito = bonito[:1].upper() + bonito[1:] if bonito else chave
    return _campo(chave, bonito[:60])


RE_LOCAL_DATA = re.compile(r'_{2,}\s*[/\-]\s*_{1,}\s*,\s*_{1,}\s*(?:de\s*)?_{2,}\s*(?:de\s*)?_{2,}\.?')
RE_DATA_BARRA = re.compile(r'_{1,}\s*/\s*_{1,}\s*/\s*_{2,}')
RE_DATA_EXT = re.compile(r'_{1,}\s*de\s*_{2,}\s*de\s*_{2,}')
RE_BRANCO = re.compile(r'_{3,}|\.{6,}|\[\s*[A-Za-zÀ-ú _]*\s*\]|«[^»]{1,40}»|<<[^>]{1,40}>>|\bX{3,}\b')
RE_CPF = re.compile(r'\b\d{3}\.\d{3}\.\d{3}-\d{2}\b')
RE_VALOR = re.compile(r'(?P<v>R\$\s?\d{1,3}(?:\.\d{3})*(?:,\d{2})?|R\$\s?\d+(?:,\d{2})?)(?P<ext>\s*\([^)]{3,120}\))?', re.I)
MESES = 'janeiro|fevereiro|março|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro'
RE_DATA_LONGA = re.compile(r'(?P<local>[A-ZÀ-Ú][\wÀ-ú\' ]{2,40}\s*[/\-]\s*[A-Z]{2}\s*,\s*)?'
                           r'(?P<sem>(?:segunda|terça|terca|quarta|quinta|sexta)-feira,\s*|sábado,\s*|sabado,\s*|domingo,\s*)?'
                           r'(?P<d>\d{1,2})º?\s+de\s+(?P<m>' + MESES + r')\s+de\s+(?P<a>\d{4})', re.I)
RE_NOME_DEPOIS = re.compile(r'(?:recebi\s+de|recebemos\s+de|eu,|eu|outorgante:?|contratante:?|declarante:?|requerente:?)\s+'
                            r'(?P<nome>(?:[A-ZÀ-Ú][A-Za-zÀ-ú\']+|d[aeo]s?|e)(?:\s+(?:[A-ZÀ-Ú][A-Za-zÀ-ú\']+|d[aeo]s?|e)){1,7})'
                            r'(?=\s*(?:-|,|–)\s*(?:CPF|inscrit|portador|brasileir|RG|residente|OAB|nascid))')


def _blocos_texto(raiz):
    """Elementos-folha de texto (p, td sem blocos, li...)."""
    for el in raiz.iter():
        if not isinstance(el.tag, str):
            continue
        if el.tag in ('p', 'li', 'h1', 'h2', 'h3', 'h4', 'td', 'th', 'div'):
            if el.tag in ('td', 'th', 'div') and any(isinstance(c.tag, str) and c.tag in ('p', 'div', 'table', 'li') for c in el):
                continue
            yield el


def _nos_texto(el):
    """Lista de (obj, attr) com texto, em ordem de leitura, dentro de um bloco."""
    out = []
    def rec(e):
        if e.text:
            out.append((e, 'text'))
        for c in e:
            rec(c)
            if c.tail:
                out.append((c, 'tail'))
    rec(el)
    return out


def detectar_campos(html_doc, nome_original=''):
    """Troca lacunas e dados preenchidos por {{campos}}. Retorna (html, campos, avisos)."""
    raiz = LH.fragment_fromstring(html_doc or '<p></p>', create_parent='div')
    campos, usados, avisos = [], {}, []

    def registrar(c):
        if c['chave'] not in usados:
            usados[c['chave']] = c
            campos.append(c)
        return c['chave']

    texto_total = raiz.text_content()
    # --- 1) dados preenchidos (documento usado como exemplo)
    cpfs = [c for c in dict.fromkeys(RE_CPF.findall(texto_total)) if c not in ESCRITORIO_FIXOS['cpf']]
    mapa_cpf = {}
    for i, c in enumerate(cpfs[:4]):
        if i == 0:
            mapa_cpf[c] = registrar(_campo('cliente_cpf', 'CPF', 'cpf', 'Cliente'))
        else:
            mapa_cpf[c] = registrar(_campo(f'cpf_{i + 1}', f'CPF {i + 1}', 'cpf', 'Outras pessoas'))
    nomes = []
    for m in RE_NOME_DEPOIS.finditer(texto_total):
        n = m.group('nome').strip()
        if norm(n) in [norm(x) for x in ESCRITORIO_FIXOS['nomes']] or len(n.split()) < 2:
            continue
        if n not in nomes:
            nomes.append(n)
    mapa_nome = {}
    for i, n in enumerate(nomes[:3]):
        mapa_nome[n] = registrar(_campo('cliente_nome' if i == 0 else f'nome_{i + 1}',
                                        'Nome completo' if i == 0 else f'Nome {i + 1}', 'texto', 'Cliente'))
    achou_valor = [False]; achou_data = [False]

    anterior_ctx = ['']

    def sub_preenchidos(t):
        for c, k in mapa_cpf.items():
            t = t.replace(c, '{{' + k + '}}')
        for n, k in sorted(mapa_nome.items(), key=lambda x: -len(x[0])):
            filtro = '|maiusculo' if n.isupper() else ''
            t = re.sub(re.escape(n), '{{' + k + filtro + '}}', t)
            if not n.isupper():
                t = re.sub(re.escape(n.upper()), '{{' + k + '|maiusculo}}', t)

        def fval(m):
            ctx = norm((anterior_ctx[0] + t[:m.start()])[-40:])
            if not re.search(r'(quantia|valor|importancia|montante|pagamento|total)\s+(total\s+)?(de|da|do)?\s*$', ctx):
                return m.group(0)
            achou_valor[0] = True
            registrar(_campo('valor', 'Valor (R$)', 'moeda', 'Pagamento'))
            return '{{valor}}'
        t = RE_VALOR.sub(fval, t)

        def fdata(m):
            # só troca datas de assinatura (com cidade/UF antes ou dia da semana)
            if not (m.group('local') or m.group('sem')):
                return m.group(0)
            achou_data[0] = True
            registrar(_campo('data_documento', 'Data do documento', 'data', 'Data e local'))
            pre = ''
            if m.group('local'):
                registrar(_campo('local', 'Local da assinatura', 'texto', 'Data e local',
                                 padrao=re.sub(r'\s*,\s*$', '', m.group('local')).replace(' - ', '/').strip()))
                pre = '{{local}}, '
            return pre + '{{data_documento' + ('|semana' if m.group('sem') else '') + '}}'
        t = RE_DATA_LONGA.sub(fdata, t)
        return t

    # --- 2) lacunas (____)
    pars_so_linha = []
    blocos = list(_blocos_texto(raiz))
    ultimo_titulo = ''
    for bl in blocos:
        nos = _nos_texto(bl)
        texto_bloco = ''.join(getattr(o, a) or '' for o, a in nos)
        so_linha = bool(re.fullmatch(r'[\s_\.]*_{5,}[\s_\.]*', texto_bloco or ''))
        if so_linha:
            pars_so_linha.append((bl, ultimo_titulo))
            continue
        if texto_bloco.strip():
            tb = texto_bloco.strip()
            ultimo_titulo = tb if len(tb) < 60 and not RE_BRANCO.search(tb) else ''
        anterior = ''
        for o, a in nos:
            t = getattr(o, a) or ''
            anterior_ctx[0] = anterior
            t = sub_preenchidos(t)

            def flocal(m):
                registrar(_campo('local', 'Local da assinatura', 'texto', 'Data e local', padrao='Mossoró/RN'))
                registrar(_campo('data_documento', 'Data do documento', 'data', 'Data e local'))
                return '{{local}}, {{data_documento}}'
            t = RE_LOCAL_DATA.sub(flocal, t)

            def fdbarra(m):
                ctx = norm((anterior + t[:m.start()])[-40:])
                if 'nasc' in ctx:
                    k = registrar(_campo('cliente_nascimento', 'Data de nascimento', 'data', 'Cliente'))
                else:
                    k = registrar(_campo('data_documento', 'Data do documento', 'data', 'Data e local'))
                return '{{' + k + '|curta}}'
            t = RE_DATA_BARRA.sub(fdbarra, t)

            def fdext(m):
                k = registrar(_campo('data_documento', 'Data do documento', 'data', 'Data e local'))
                return '{{' + k + '}}'
            t = RE_DATA_EXT.sub(fdext, t)

            def fbranco(m):
                bruto = m.group(0)
                if bruto.startswith(('[', '«', '<<')):
                    rot = bruto.strip('[]«»<> ')
                else:
                    ctx = re.sub(r'\{\{[^}]*\}\}', ' ', anterior + t[:m.start()])
                    ctx = re.split(r'[\n;.()]|\s{3,}|_{3,}', ctx)[-1]
                    rot = ' '.join(ctx.split()[-4:])
                    if not rot.strip(' ,.:-') and bruto.startswith('_'):
                        # linha sozinha no começo do parágrafo = linha de assinatura
                        bl.set('class', 'assinatura')
                        return ''
                c = rotulo_para_campo(rot, usados)
                chave = c['chave']
                if chave in usados and not chave.startswith('cliente_') and chave not in ('valor', 'data_documento', 'local'):
                    n = 2
                    while f'{chave}_{n}' in usados:
                        n += 1
                    c['chave'] = f'{chave}_{n}'; c['rotulo'] += f' ({n})'
                registrar(c)
                return '{{' + c['chave'] + '}}'
            t = RE_BRANCO.sub(fbranco, t)
            # caixas de marcar "( )"
            if t.count('( )') + t.count('(  )') >= 1 and texto_total.count('( )') >= 3:
                def fcx(m):
                    seg = re.split(r'\(', t[m.end():])[0]
                    rot = ' '.join(seg.split()[:6]) or 'opção'
                    base = 'marcar_' + '_'.join(re.findall(r'[a-z0-9]+', norm(rot)))[:30]
                    k = base; n = 2
                    while k in usados:
                        k = f'{base}_{n}'; n += 1
                    registrar(_campo(k, rot[:50], 'caixa', 'Marcar'))
                    return '( {{' + k + '}} )'
                t = re.sub(r'\(\s{1,3}\)', fcx, t)
            setattr(o, a, t)
            anterior += t
    # parágrafos formados só por linhas (ex.: qualificação em várias linhas)
    grupos = []
    for bl, tit in pars_so_linha:
        prev = bl.getprevious()
        if grupos and grupos[-1][-1][0] is prev:
            grupos[-1].append((bl, tit))
        else:
            grupos.append([(bl, tit)])
    for g in grupos:
        bl0, tit = g[0]
        rot = tit or 'Texto livre'
        if len(g) == 1 and not (tit or '').endswith(':'):
            # linha sozinha = linha de assinatura: vira traço de assinatura
            prox = bl0.getnext()
            if prox is not None and prox.text_content().strip() and len(prox.text_content()) < 80:
                prox.set('class', 'assinatura'); bl0.getparent().remove(bl0)
            continue
        if len(g) == 1:
            c = rotulo_para_campo(rot, usados)
        else:
            c = _campo('qualificacao_' + '_'.join(re.findall(r'[a-z0-9]+', norm(rot)))[:30] if tit else 'texto_livre',
                       f'{titulo_bonito(rot)} (texto)', 'texto_longo', 'Geral')
            if norm(rot).strip() in ('contratante', 'outorgante', 'declarante', 'requerente'):
                c['ajuda'] = 'Ex.: nome, nacionalidade, estado civil, profissão, CPF, endereço.'
        registrar(c)
        for e in list(bl0):
            bl0.remove(e)
        bl0.text = '{{' + c['chave'] + '}}'
        for bl, _ in g[1:]:
            bl.getparent().remove(bl)
    for el in raiz.iter('p'):
        if 'assinatura' in (el.get('class') or ''):
            while len(el) and el[0].tag == 'br' and not (el.text or '').strip():
                br = el[0]; el.text = (el.text or '') + (br.tail or ''); el.remove(br)
            while len(el) and el[-1].tag == 'br' and not (el[-1].tail or '').strip():
                el.remove(el[-1])
    novo = ''.join(etree.tostring(c, encoding='unicode', method='html') for c in raiz)
    if raiz.text and raiz.text.strip():
        novo = _esc(raiz.text) + novo
    if not campos:
        avisos.append('Não encontrei campos em branco automaticamente. Use "Editar modelo" e selecione um trecho > "Virar campo".')
    return novo, campos, avisos


# ===================================================================== classificação
CATEGORIAS = [
    ('Recibos', ['recibo', 'recebi a quantia', 'recebi de', 'declaro que recebi', 'quitação', 'quitacao'], ['recibo']),
    ('Contratos de Honorários', ['contrato de honorários', 'honorários advocatícios', 'contratada', 'êxito'], ['contrato de honor']),
    ('Contratos', ['contrato', 'contratante', 'contratado', 'cláusula', 'clausula'], ['contrato']),
    ('Procurações', ['procuração', 'outorgante', 'outorgado', 'ad judicia', 'poderes', 'mandato'], ['procura']),
    ('Substabelecimentos', ['substabeleço', 'substabelecimento', 'substabelece'], ['substabelec']),
    ('Declarações', ['declaração', 'declaro', 'para os devidos fins', 'hipossuficiência', 'residência'], ['declara']),
    ('Fichas e Cadastros', ['ficha', 'cadastro', 'registro do cliente', 'questionário', 'entrevista', 'triagem'], ['ficha', 'cadastro', 'registro do cliente', 'questionario']),
    ('Termos e Formulários do INSS', ['inss', 'portaria conjunta', 'termo de representação', 'anexo', 'previdência social', 'meu inss'], ['anexo', 'termo de representa', 'formulario', 'requerimento de beneficio']),
    ('Requerimentos Administrativos', ['requerimento', 'requer', 'ilustríssimo', 'ilmo', 'gerente', 'senhor(a)'], ['requerimento']),
    ('Petições', ['excelentíssimo', 'exmo', 'meritíssimo', 'vara', 'juizado', 'nestes termos', 'pede deferimento', 'petição'], ['peticao', 'acao', 'manifesta', 'recurso', 'contrarrazo']),
    ('Notificações e Ofícios', ['notificação', 'notificamos', 'ofício', 'notifica'], ['notifica', 'oficio']),
    ('Termos e Acordos', ['termo de acordo', 'acordo', 'confissão de dívida', 'transação'], ['acordo', 'termo de']),
    ('Comunicados e Cartas', ['prezado', 'prezada', 'atenciosamente', 'comunicamos'], ['carta', 'comunicado']),
]
AREAS = [
    ('Previdenciário', ['inss', 'benefício', 'beneficio', 'aposentadoria', 'previdenci', 'bpc', 'loas', 'segurado', 'auxílio', 'pensão por morte', 'salário-maternidade', 'cnis']),
    ('Trabalhista', ['reclamante', 'reclamada', 'clt', 'trabalhista', 'rescisão', 'fgts', 'empregador', 'ctps', 'aviso prévio']),
    ('Consumidor', ['consumidor', 'cdc', 'fornecedor', 'procon', 'cobrança indevida']),
    ('Família', ['alimentos', 'divórcio', 'guarda', 'pensão alimentícia', 'união estável']),
    ('Cível', ['indenização', 'danos morais', 'responsabilidade civil', 'código civil', 'cível']),
    ('Administrativo do escritório', ['diária', 'diarista', 'prestação de serviço', 'limpeza', 'funcionário', 'colaborador', 'reembolso']),
]


def classificar(texto, titulo, nome_arquivo, categorias_existentes):
    tn = norm(texto)[:20000]
    titn = norm(titulo + ' ' + nome_arquivo)
    placar = []
    for cat, palavras, nos_titulo in CATEGORIAS:
        s = sum(tn.count(norm(p)) for p in palavras)
        s += sum(12 for p in nos_titulo if p in titn)
        placar.append((s, cat))
    placar.sort(reverse=True)
    # kit: vários tipos fortes no mesmo arquivo
    fortes = {c for s, c in placar if s >= 6}
    tipos_kit = fortes & {'Contratos de Honorários', 'Contratos', 'Procurações', 'Fichas e Cadastros', 'Declarações', 'Termos e Formulários do INSS'}
    if len(tipos_kit) >= 3 and tn.count('procura') and ('contrat' in tn):
        cat = 'Kits de Atendimento'
    elif placar[0][0] > 0:
        cat = placar[0][1]
        if cat == 'Contratos' and 'honorar' in tn:
            cat = 'Contratos de Honorários'
    else:
        primeira = (titulo.split() or ['Outros'])[0]
        cat = plural(titulo_bonito(primeira)) if len(primeira) > 3 else 'Outros'
    # aproveita pasta que já existe com nome parecido
    for existente in categorias_existentes:
        if norm(existente) == norm(cat) or norm(existente).rstrip('s') == norm(cat).rstrip('s'):
            cat = existente
            break
    area = 'Geral'; melhor = 0
    for a, palavras in AREAS:
        s = sum(tn.count(norm(p)) for p in palavras)
        if s > melhor:
            area, melhor = a, s
    return cat, area


def achar_titulo(html_doc):
    raiz = LH.fragment_fromstring(html_doc or '<p></p>', create_parent='div')
    for el in raiz.iter('p', 'h1', 'h2', 'h3', 'td'):
        t = re.sub(r'\{\{[^}]*\}\}', '', el.text_content()).strip()
        if not t or len(t) > 110 or len(t) < 4:
            continue
        cls = el.get('class') or ''
        letras = re.sub(r'[^A-Za-zÀ-ú]', '', t)
        if (letras.isupper() and len(letras) > 3) or 'centro' in cls or el.find('.//b') is not None or el.tag.startswith('h'):
            if not re.match(r'^(data|nome|cpf|eu|excelent)', norm(t)):
                return t
    return ''


def limpar_nome_arquivo(n):
    base = os.path.splitext(os.path.basename(n))[0]
    base = re.sub(r'^[0-9a-f]{8}[-_]', '', base)
    base = base.replace('_', ' ')
    base = re.sub(r'\b(c[oó]pia|copy|final|v\d+|novo|modelo)\b', '', base, flags=re.I)
    base = re.sub(r'\s+', ' ', base).strip(' -')
    return base


def sugerir_nome(titulo, nome_arquivo, campos_nomes):
    t = titulo_bonito(titulo) if titulo else ''
    arq = titulo_bonito(limpar_nome_arquivo(nome_arquivo))
    # remove nomes próprios de pessoas preenchidas
    for n in campos_nomes:
        arq = re.sub(re.escape(titulo_bonito(n)), '', arq, flags=re.I).strip(' -—')
    if not t or len(t.split()) <= 2:
        if arq and len(arq.split()) > len(t.split()):
            return arq
    return t or arq or 'Modelo sem nome'


# ===================================================================== IA (opcional)
def _ssl_ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def gemini(prompt, chave, modelo='gemini-2.5-flash', timeout=60, anexos=None):
    """anexos: lista de (mime, bytes) — imagens/PDFs enviados junto com o texto."""
    import base64
    url = f'https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={chave}'
    partes = [{'inline_data': {'mime_type': m, 'data': base64.b64encode(b).decode()}} for m, b in (anexos or [])]
    partes.append({'text': prompt})
    corpo = json.dumps({'contents': [{'parts': partes}],
                        'generationConfig': {'responseMimeType': 'application/json', 'temperature': 0.1}}).encode()
    req = urllib.request.Request(url, data=corpo, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
        dados = json.loads(r.read().decode())
    txt = dados['candidates'][0]['content']['parts'][0]['text']
    return json.loads(txt)


def refinar_com_ia(html_doc, campos, cats_existentes, cfg):
    raiz = LH.fragment_fromstring(html_doc, create_parent='div')
    texto = raiz.text_content()[:14000]
    prompt = f'''Você é assistente de um escritório de advocacia brasileiro (previdenciário, trabalhista, cível).
Abaixo está o texto de um MODELO de documento. Trechos {{{{assim}}}} já são campos variáveis.
Tarefas:
1) Classifique em UMA categoria (pasta). Prefira uma destas se servir: {json.dumps(cats_existentes + [c for c, _, _ in CATEGORIAS], ensure_ascii=False)}. Se nenhuma servir, crie um nome curto no plural (ex.: "Notificações").
2) Diga a área do direito (Previdenciário, Trabalhista, Cível, Consumidor, Família, Administrativo do escritório ou Geral).
3) Dê um nome profissional para o arquivo, em português, Título Com Maiúsculas, sem nomes de clientes nem datas (ex.: "Declaração de Hipossuficiência Econômica").
4) Uma descrição de uma frase.
5) Encontre DADOS ESPECÍFICOS DE UM CLIENTE/CASO que ainda estão escritos no texto e deveriam virar campo (nomes de pessoas, CPF, RG, endereços, valores, datas, número de processo/benefício). NÃO inclua dados fixos do escritório (nomes dos advogados e do escritório{(': ' + ', '.join(ESCRITORIO_FIXOS['nomes'])) if ESCRITORIO_FIXOS['nomes'] else ''}, OABs e CNPJs do escritório). Para cada um devolva o trecho EXATO como aparece no texto.
Responda só JSON: {{"categoria":"","area":"","nome":"","descricao":"","campos":[{{"trecho":"","chave":"snake_case","rotulo":"","tipo":"texto|texto_longo|cpf|cnpj|data|moeda|numero|telefone|cep|email|opcoes"}}]}}
Use chaves padrão quando couber: cliente_nome, cliente_cpf, cliente_rg, cliente_endereco, cliente_bairro, cliente_cidade, cliente_uf, cliente_cep, cliente_telefone, cliente_estado_civil, cliente_profissao, cliente_nacionalidade, valor, data_documento, local, numero_processo, numero_beneficio.

TEXTO:
{texto}'''
    r = gemini(prompt, cfg['gemini_chave'], cfg.get('gemini_modelo') or 'gemini-2.5-flash')
    usados = {c['chave'] for c in campos}
    for c in (r.get('campos') or [])[:25]:
        trecho = (c.get('trecho') or '').strip()
        chave = re.sub(r'[^a-z0-9_]', '', norm(c.get('chave') or ''))[:40]
        if not trecho or not chave or len(trecho) < 3 or '{{' in trecho:
            continue
        trocou = False
        for el in raiz.iter():
            for attr in ('text', 'tail'):
                v = getattr(el, attr, None)
                if v and trecho in v:
                    setattr(el, attr, v.replace(trecho, '{{' + chave + '}}')); trocou = True
        if trocou and chave not in usados:
            tipo = c.get('tipo') if c.get('tipo') in ('texto', 'texto_longo', 'cpf', 'cnpj', 'data', 'moeda', 'numero', 'telefone', 'cep', 'email', 'opcoes') else 'texto'
            campos.append(_campo(chave, c.get('rotulo') or chave, tipo, 'Geral'))
            usados.add(chave)
    novo = ''.join(etree.tostring(c, encoding='unicode', method='html') for c in raiz)
    return novo, campos, r


# ===================================================================== ponto de entrada
def analisar(nome_arquivo, conteudo):
    html_doc, info, docx_bytes = ler(nome_arquivo, conteudo)
    titulo_cru = achar_titulo(html_doc)
    html_campos, campos, avisos = detectar_campos(html_doc, nome_arquivo)
    texto = LH.fragment_fromstring(html_campos or '<p></p>', create_parent='div').text_content()
    cats = [c['nome'] for c in B.categorias()]
    categoria, area = classificar(texto, titulo_cru, nome_arquivo, cats)
    nomes_preenchidos = [m.group('nome') for m in RE_NOME_DEPOIS.finditer(LH.fragment_fromstring(html_doc or '<p></p>', create_parent='div').text_content())]
    nome = sugerir_nome(titulo_cru if categoria != 'Kits de Atendimento' else '', nome_arquivo, nomes_preenchidos)
    descricao = ''
    usou_ia = False
    cfg = B.config()
    if cfg.get('gemini_chave') and cfg.get('usar_ia_importacao', True):
        try:
            html_campos, campos, r = refinar_com_ia(html_campos, campos, cats, cfg)
            categoria = (r.get('categoria') or categoria).strip()
            area = (r.get('area') or area).strip()
            nome = (r.get('nome') or nome).strip()
            descricao = (r.get('descricao') or '').strip()
            usou_ia = True
        except Exception as e:
            avisos.append(f'A IA não respondeu ({type(e).__name__}); usei a classificação automática por regras.')
    # gênero: se o texto usa o(a), liga ao gênero do cliente
    genero = ''
    if re.search(r'\w\(a\)', texto) and any(c['chave'].startswith('cliente_') for c in campos):
        genero = 'cliente_genero'
        if 'cliente_genero' not in {c['chave'] for c in campos}:
            campos.insert(1, _campo('cliente_genero', 'Gênero (ajusta o/a no texto)', 'opcoes', 'Cliente',
                                    opcoes=['Masculino', 'Feminino']))
    # timbrado embutido no Word
    timbrado = None
    if info.get('tem_timbrado') and docx_bytes:
        try:
            from . import timbrados as T
            img, margens = T.importar('x.docx', docx_bytes)
            if info.get('margens'):
                margens['sup'] = max(margens['sup'], min(info['margens']['sup'], 5))
            melhor, dist = None, 99
            from PIL import Image
            for t in B.listar_timbrados():
                f = B.caminho_fundo(t['id'])
                if f:
                    d = T.parecido(img, Image.open(f))
                    if d < dist:
                        melhor, dist = t, d
            timbrado = {'existente': melhor['id'] if melhor and dist < 6 else None,
                        'existente_nome': melhor['nome'] if melhor and dist < 6 else None,
                        'imagem': 'data:image/png;base64,' + base64.b64encode(T.png_bytes(img.resize((413, 585)))).decode(),
                        'margens': margens}
        except Exception as e:
            avisos.append(f'O arquivo tem papel timbrado, mas não consegui extraí-lo ({type(e).__name__}).')
    return {
        'nome': nome, 'categoria': categoria, 'area': area, 'descricao': descricao,
        'html': html_campos, 'campos': campos, 'fonte': info.get('fonte') or 'Calibri',
        'tamanho': info.get('tamanho') or 12, 'espacamento': 1.4, 'genero': genero,
        'timbrado_detectado': timbrado, 'avisos': avisos, 'usou_ia': usou_ia,
        'categorias': cats,
    }


def slug_chave(t):
    palavras = [p for p in re.findall(r'[a-z0-9]+', norm(t)) if p not in ('de', 'da', 'do', 'e', 'o', 'a', 'se', 'ou', 'com')][:4]
    return ('_'.join(palavras) or 'campo')[:40]
