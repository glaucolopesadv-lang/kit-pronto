"""Word (.docx) -> HTML do modelo, mantendo a formatação do documento.

Entende: estilos do Word (Normal, Título, estilos próprios), fonte/tamanho/cor de cada trecho,
negrito/itálico/sublinhado/tachado/maiúsculas, alinhamento, recuos (esquerdo, direito, 1ª linha, deslocamento),
espaço antes/depois, entrelinhas, bordas e sombreamento de parágrafo (caixas), listas numeradas e com marcadores
(1., 1.1, a), •), tabelas (larguras, células mescladas, bordas célula a célula, sombreamento, tabelas dentro de
tabelas), imagens no texto e o texto do cabeçalho (vai para o cabeçalho do modelo, em todas as páginas).
"""
import collections, hashlib, html as H, io, os, re, zipfile
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
V = 'urn:schemas-microsoft-com:vml'
MC = 'http://schemas.openxmlformats.org/markup-compatibility/2006'
NS = {'w': W, 'r': R, 'a': A, 'wp': WP, 'v': V}


def q(t):
    p, n = t.split(':')
    return '{%s}%s' % (NS[p], n)


def wval(el, attr='val'):
    if el is None:
        return None
    return el.get(q('w:' + attr))


def ligado(el):
    """<w:b/> = sim; <w:b w:val="0|false|off"/> = não."""
    if el is None:
        return None
    v = el.get(q('w:val'))
    return v not in ('0', 'false', 'off', 'none')


def pt(twips):
    try:
        return int(float(twips)) / 20.0
    except (TypeError, ValueError):
        return None


def fmt(n):
    return ('%.2f' % n).rstrip('0').rstrip('.')


def esc(t):
    return H.escape(t, quote=False)


# ----------------------------------------------------------------- numeração
def romano(n):
    vals = [(1000, 'm'), (900, 'cm'), (500, 'd'), (400, 'cd'), (100, 'c'), (90, 'xc'), (50, 'l'), (40, 'xl'),
            (10, 'x'), (9, 'ix'), (5, 'v'), (4, 'iv'), (1, 'i')]
    out = ''
    for v, s in vals:
        while n >= v:
            out += s; n -= v
    return out


def letra(n):
    s = ''
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(97 + r) + s
    return s


def formatar_num(n, f):
    if f in ('lowerLetter',):
        return letra(n)
    if f == 'upperLetter':
        return letra(n).upper()
    if f == 'lowerRoman':
        return romano(n)
    if f == 'upperRoman':
        return romano(n).upper()
    if f == 'decimalZero':
        return '%02d' % n
    if f == 'ordinal':
        return f'{n}º'
    if f == 'none':
        return ''
    return str(n)


BULLETS = {'': '•', '': '▪', '': '➢', '': '✓', '': '❖', '': '□', 'o': '◦', '§': '▪', '': '●', '': '■'}


class Numeracao:
    def __init__(self, xml):
        self.abs, self.num = {}, {}
        self.cont = collections.defaultdict(dict)
        if xml is None:
            return
        for an in xml.findall(q('w:abstractNum')):
            niveis = {}
            for lv in an.findall(q('w:lvl')):
                il = int(lv.get(q('w:ilvl')) or 0)
                niveis[il] = {
                    'start': int(wval(lv.find(q('w:start'))) or 1),
                    'fmt': wval(lv.find(q('w:numFmt'))) or 'decimal',
                    'texto': wval(lv.find(q('w:lvlText'))) or '',
                    'ppr': lv.find(q('w:pPr')), 'rpr': lv.find(q('w:rPr')),
                    'suff': wval(lv.find(q('w:suff'))) or 'tab',
                }
            self.abs[an.get(q('w:abstractNumId'))] = niveis
        for n in xml.findall(q('w:num')):
            over = {}
            for o in n.findall(q('w:lvlOverride')):
                so = o.find(q('w:startOverride'))
                if so is not None:
                    over[int(o.get(q('w:ilvl')) or 0)] = int(wval(so) or 1)
            self.num[n.get(q('w:numId'))] = (wval(n.find(q('w:abstractNumId'))), over)

    def nivel(self, num_id, ilvl):
        if num_id not in self.num:
            return None
        a, _ = self.num[num_id]
        return (self.abs.get(a) or {}).get(ilvl)

    def proximo(self, num_id, ilvl):
        """Avança o contador e devolve o rótulo ('4.1', 'a)', '•')."""
        if num_id not in self.num or num_id == '0':
            return None
        a, over = self.num[num_id]
        niveis = self.abs.get(a) or {}
        lv = niveis.get(ilvl)
        if not lv:
            return None
        c = self.cont[a]
        ini = over.get(ilvl, lv['start'])
        c[ilvl] = c.get(ilvl, ini - 1) + 1
        for k in list(c):
            if k > ilvl:
                del c[k]
        if lv['fmt'] == 'bullet':
            t = lv['texto'] or '•'
            return ''.join(BULLETS.get(ch, ch) for ch in t) or '•'

        def troca(m):
            k = int(m.group(1)) - 1
            n = c.get(k, (niveis.get(k) or {}).get('start', 1))
            f = (niveis.get(k) or {}).get('fmt', 'decimal')
            if k < ilvl and lv['fmt'] != 'none':
                f = 'decimal' if f in ('lowerLetter', 'upperLetter') and False else f
            return formatar_num(n, f)
        return re.sub(r'%(\d)', troca, lv['texto'])


# ----------------------------------------------------------------- estilos
class Estilos:
    def __init__(self, xml, tema_fontes):
        self.e = {}
        self.tema = tema_fontes
        self.rpr_def = self.ppr_def = None
        self.normal = None
        self.tabela_padrao = None
        if xml is None:
            return
        dd = xml.find(q('w:docDefaults'))
        if dd is not None:
            self.rpr_def = dd.find('w:rPrDefault/w:rPr', NS)
            self.ppr_def = dd.find('w:pPrDefault/w:pPr', NS)
        for s in xml.findall(q('w:style')):
            sid = s.get(q('w:styleId'))
            self.e[sid] = {'tipo': s.get(q('w:type')), 'base': wval(s.find(q('w:basedOn'))),
                           'ppr': s.find(q('w:pPr')), 'rpr': s.find(q('w:rPr')), 'tblpr': s.find(q('w:tblPr')),
                           'tcpr': s.find(q('w:tcPr'))}
            if s.get(q('w:default')) in ('1', 'true'):
                if s.get(q('w:type')) == 'paragraph':
                    self.normal = sid
                if s.get(q('w:type')) == 'table':
                    self.tabela_padrao = sid

    def cadeia(self, sid):
        out, vistos = [], set()
        while sid and sid in self.e and sid not in vistos:
            vistos.add(sid); out.append(self.e[sid]); sid = self.e[sid]['base']
        return list(reversed(out))

    def fonte(self, rfonts):
        if rfonts is None:
            return None
        f = rfonts.get(q('w:ascii')) or rfonts.get(q('w:hAnsi'))
        if f:
            return f
        t = rfonts.get(q('w:asciiTheme')) or rfonts.get(q('w:hAnsiTheme'))
        if t:
            return self.tema.get('major' if t.startswith('major') else 'minor')
        return None


def juntar_rpr(props, rpr, est):
    if rpr is None:
        return
    for tag, chave in (('b', 'b'), ('i', 'i'), ('strike', 's'), ('dstrike', 's'), ('caps', 'caps'), ('smallCaps', 'caps'), ('vanish', 'oculto')):
        el = rpr.find(q('w:' + tag))
        if el is not None:
            props[chave] = ligado(el)
    u = rpr.find(q('w:u'))
    if u is not None:
        props['u'] = wval(u) not in ('none', None) or wval(u) is None
        if wval(u) == 'none':
            props['u'] = False
    sz = rpr.find(q('w:sz'))
    if sz is not None and wval(sz):
        try:
            props['sz'] = int(wval(sz)) / 2.0
        except ValueError:
            pass
    c = rpr.find(q('w:color'))
    if c is not None and wval(c) and wval(c) != 'auto':
        props['cor'] = wval(c)
    f = est.fonte(rpr.find(q('w:rFonts')))
    if f:
        props['fonte'] = f
    hl = rpr.find(q('w:highlight'))
    if hl is not None and wval(hl) not in (None, 'none', 'white'):
        props['marca'] = wval(hl)
    shd = rpr.find(q('w:shd'))
    if shd is not None and (wval(shd, 'fill') or 'auto').upper() not in ('AUTO', 'FFFFFF'):
        props['fundo'] = wval(shd, 'fill')
    va = rpr.find(q('w:vertAlign'))
    if va is not None:
        props['va'] = wval(va)


def juntar_ppr(props, ppr):
    if ppr is None:
        return
    jc = ppr.find(q('w:jc'))
    if jc is not None:
        props['jc'] = wval(jc)
    ind = ppr.find(q('w:ind'))
    if ind is not None:
        for a, k in (('left', 'esq'), ('start', 'esq'), ('right', 'dir'), ('end', 'dir'), ('firstLine', 'prim'), ('hanging', 'desl')):
            v = ind.get(q('w:' + a))
            if v is not None:
                props[k] = pt(v)
        if ind.get(q('w:hanging')) is not None:
            props.pop('prim', None)
        if ind.get(q('w:firstLine')) is not None:
            props.pop('desl', None)
    sp = ppr.find(q('w:spacing'))
    if sp is not None:
        for a, k in (('before', 'antes'), ('after', 'depois')):
            if sp.get(q('w:' + a)) is not None:
                props[k] = pt(sp.get(q('w:' + a)))
        if sp.get(q('w:beforeAutospacing')) in ('1', 'true'):
            props['antes'] = 14
        if sp.get(q('w:afterAutospacing')) in ('1', 'true'):
            props['depois'] = 14
        if sp.get(q('w:line')) is not None:
            props['linha'] = int(sp.get(q('w:line')))
            props['regra'] = sp.get(q('w:lineRule')) or 'auto'
    cs = ppr.find(q('w:contextualSpacing'))
    if cs is not None:
        props['contextual'] = ligado(cs)
    bdr = ppr.find(q('w:pBdr'))
    if bdr is not None:
        props['bordas'] = {lado: borda_css(bdr.find(q('w:' + lado))) for lado in ('top', 'bottom', 'left', 'right', 'between')}
    shd = ppr.find(q('w:shd'))
    if shd is not None and (wval(shd, 'fill') or 'auto').upper() not in ('AUTO', 'FFFFFF'):
        props['fundo'] = wval(shd, 'fill')
    np_ = ppr.find(q('w:numPr'))
    if np_ is not None:
        props['num'] = (wval(np_.find(q('w:numId'))), int(wval(np_.find(q('w:ilvl'))) or 0))
    if ppr.find(q('w:pageBreakBefore')) is not None and ligado(ppr.find(q('w:pageBreakBefore'))):
        props['quebra_antes'] = True


def borda_css(el):
    if el is None:
        return None
    v = wval(el)
    if v in (None, 'nil', 'none'):
        return 'none'
    try:
        larg = max(0.25, int(el.get(q('w:sz')) or 4) / 8.0)
    except ValueError:
        larg = 0.5
    cor = el.get(q('w:color'))
    cor = '#' + cor if cor and cor != 'auto' else '#000'
    tipo = 'double' if v in ('double', 'triple') else 'dashed' if 'dash' in v else 'dotted' if 'dot' in v else 'solid'
    if tipo == 'double':
        larg = max(larg, 2.25)
    return f'{fmt(larg)}pt {tipo} {cor}'


# ----------------------------------------------------------------- conversor
class Conversor:
    def __init__(self, conteudo, pasta_imagens=None, url_imagens='recursos/importados'):
        self.z = zipfile.ZipFile(io.BytesIO(conteudo))
        self.nomes = set(self.z.namelist())
        self.pasta_imagens = pasta_imagens
        self.url_imagens = url_imagens
        self.tema = self._tema()
        self.est = Estilos(self._xml('word/styles.xml'), self.tema)
        self.numer = Numeracao(self._xml('word/numbering.xml'))
        self.doc = self._xml('word/document.xml')
        self.rels = self._rels('word/_rels/document.xml.rels')
        self.contagem_fontes = collections.Counter()
        self.contagem_tam = collections.Counter()
        self.contagem_lh = collections.Counter()
        # padrão do documento (estilo Normal)
        base_r = {}
        juntar_rpr(base_r, self.est.rpr_def, self.est)
        for s in self.est.cadeia(self.est.normal):
            juntar_rpr(base_r, s['rpr'], self.est)
        self.fonte_base = base_r.get('fonte') or self.tema.get('minor') or 'Calibri'
        self.tam_base = base_r.get('sz') or 10.0
        base_p = {}
        juntar_ppr(base_p, self.est.ppr_def)
        for s in self.est.cadeia(self.est.normal):
            juntar_ppr(base_p, s['ppr'])
        self.lh_base = self._lh(base_p) or 1.15

    # -- partes do arquivo
    def _xml(self, nome):
        if nome not in self.nomes:
            return None
        try:
            return etree.fromstring(self.z.read(nome))
        except Exception:
            return None

    def _rels(self, nome):
        out = {}
        x = self._xml(nome)
        if x is not None:
            for r in x:
                alvo = r.get('Target') or ''
                if r.get('TargetMode') == 'External':
                    continue
                alvo = alvo.lstrip('/')
                if not alvo.startswith('word/'):
                    alvo = 'word/' + alvo.replace('../', '')
                out[r.get('Id')] = alvo
        return out

    def _tema(self):
        x = self._xml('word/theme/theme1.xml')
        out = {}
        if x is not None:
            for k, tag in (('major', 'majorFont'), ('minor', 'minorFont')):
                el = x.find('.//a:%s/a:latin' % tag, NS)
                if el is not None and el.get('typeface'):
                    out[k] = el.get('typeface')
        return out

    # -- propriedades efetivas
    def props_par(self, p):
        ppr = p.find(q('w:pPr'))
        sid = wval(ppr.find(q('w:pStyle'))) if ppr is not None else None
        sid = sid or self.est.normal
        props = {}
        juntar_ppr(props, self.est.ppr_def)
        for s in self.est.cadeia(sid):
            juntar_ppr(props, s['ppr'])
        num_estilo = props.get('num')
        juntar_ppr(props, ppr)
        if 'num' not in props and num_estilo:
            props['num'] = num_estilo
        props['estilo'] = sid
        rp = {}
        juntar_rpr(rp, self.est.rpr_def, self.est)
        for s in self.est.cadeia(sid):
            juntar_rpr(rp, s['rpr'], self.est)
        return props, rp

    def props_run(self, r, rp_par):
        props = dict(rp_par)
        rpr = r.find(q('w:rPr'))
        sid = wval(rpr.find(q('w:rStyle'))) if rpr is not None else None
        if sid:
            for s in self.est.cadeia(sid):
                juntar_rpr(props, s['rpr'], self.est)
        juntar_rpr(props, rpr, self.est)
        return props

    def _lh(self, pp):
        if 'linha' not in pp:
            return None
        if pp.get('regra', 'auto') == 'auto':
            return round(pp['linha'] / 240.0 * 1.17, 2)
        return None

    # -- imagens
    def imagem(self, el, rels):
        blip = el.find('.//a:blip', NS)
        rid = blip.get(q('r:embed')) if blip is not None else None
        if rid is None:
            im = el.find('.//v:imagedata', NS)
            rid = im.get(q('r:id')) if im is not None else None
        alvo = rels.get(rid)
        if not alvo or alvo not in self.nomes:
            return ''
        dados = self.z.read(alvo)
        ext = os.path.splitext(alvo)[1].lower()
        if ext in ('.emf', '.wmf', '.svg'):
            return ''
        ext_el = el.find('.//wp:extent', NS)
        w = h = None
        if ext_el is not None:
            w = int(ext_el.get('cx')) / 12700.0; h = int(ext_el.get('cy')) / 12700.0
        nome = hashlib.md5(dados).hexdigest()[:16] + ext
        if self.pasta_imagens:
            os.makedirs(self.pasta_imagens, exist_ok=True)
            destino = os.path.join(self.pasta_imagens, nome)
            if not os.path.exists(destino):
                with open(destino, 'wb') as f:
                    f.write(dados)
        tam = f'width:{fmt(w)}pt;height:{fmt(h)}pt' if w and h else ''
        return f'<img src="{self.url_imagens}/{nome}" style="{tam};vertical-align:middle" alt="">'

    # -- trechos de texto
    def runs(self, p, rp_par, rels, ctx):
        """Devolve lista de (html, props) por trecho."""
        out = []

        def visitar(el):
            for c in el:
                tag = etree.QName(c).localname if isinstance(c.tag, str) else ''
                if tag == 'r':
                    self.run(c, rp_par, rels, out, ctx)
                elif tag in ('hyperlink', 'ins', 'smartTag', 'fldSimple', 'customXml', 'dir', 'bdo'):
                    visitar(c)
                elif tag == 'sdt':
                    cont = c.find(q('w:sdtContent'))
                    if cont is not None:
                        visitar(cont)
                elif tag == 'AlternateContent':
                    esc_ = c.find('{%s}Fallback' % MC)
                    if esc_ is None:
                        esc_ = c.find('{%s}Choice' % MC)
                    if esc_ is not None:
                        visitar(esc_)
        visitar(p)
        return out

    def run(self, r, rp_par, rels, out, ctx):
        props = self.props_run(r, rp_par)
        if props.get('oculto'):
            return
        if r.find(q('w:instrText')) is not None and r.find(q('w:t')) is None:
            return
        partes = []
        for c in r:
            tag = etree.QName(c).localname if isinstance(c.tag, str) else ''
            if tag == 't':
                partes.append(('t', c.text or ''))
            elif tag == 'tab':
                partes.append(('h', '<span class="tab">  </span>'))
            elif tag == 'br':
                if c.get(q('w:type')) == 'page':
                    partes.append(('quebra', ''))
                else:
                    partes.append(('h', '<br>'))
            elif tag == 'cr':
                partes.append(('h', '<br>'))
            elif tag == 'noBreakHyphen':
                partes.append(('t', '‑'))
            elif tag == 'softHyphen':
                pass
            elif tag == 'sym':
                ch = c.get(q('w:char')) or ''
                try:
                    partes.append(('t', BULLETS.get(chr(int(ch, 16)), '•' if int(ch, 16) >= 0xF000 else chr(int(ch, 16)))))
                except ValueError:
                    pass
            elif tag in ('drawing', 'pict', 'object'):
                ctx['imagens'] += 1
                if not ctx.get('sem_imagens'):
                    partes.append(('h', self.imagem(c, rels)))
            elif tag == 'AlternateContent':
                alvo = c.find('{%s}Choice' % MC)
                if alvo is not None and alvo.find('.//' + q('w:drawing')) is not None:
                    ctx['imagens'] += 1
                    if not ctx.get('sem_imagens'):
                        partes.append(('h', self.imagem(alvo, rels)))
        for tipo, conteudo in partes:
            if tipo == 'quebra':
                out.append(('\x00QUEBRA\x00', props))
                continue
            if tipo == 't':
                if not conteudo:
                    continue
                n = len(conteudo.strip())
                self.contagem_fontes[props.get('fonte') or self.fonte_base] += n
                self.contagem_tam[props.get('sz') or self.tam_base] += n
                t = esc(conteudo)
                if props.get('caps'):
                    t = t.upper()
            else:
                t = conteudo
            out.append((t, props))

    def html_trechos(self, trechos, base_tam):
        """Junta trechos vizinhos com a mesma formatação e aplica negrito/itálico/etc."""
        html, ant, buf = [], None, []

        def chave(pr):
            return tuple(pr.get(k) for k in ('b', 'i', 'u', 's', 'sz', 'cor', 'fonte', 'marca', 'fundo', 'va'))

        def fecha():
            if not buf:
                return
            pr = ant
            t = ''.join(buf)
            estilo = []
            if pr.get('cor') and pr['cor'].upper() not in ('000000',):
                estilo.append('color:#' + pr['cor'])
            if pr.get('sz') and abs(pr['sz'] - base_tam) >= 0.25:
                estilo.append(f'font-size:{fmt(pr["sz"])}pt')
            if pr.get('fonte') and pr['fonte'] != self.fonte_base:
                f = pr['fonte']
                pilha = ", Carlito, sans-serif" if 'calibri' in f.lower() else ", Caladea, serif" if 'cambria' in f.lower() else ", sans-serif"
                estilo.append(f"font-family:'{f}'{pilha}")
            if pr.get('marca'):
                cores = {'yellow': '#FFFF00', 'green': '#00FF00', 'cyan': '#00FFFF', 'lightGray': '#D3D3D3', 'darkGray': '#A9A9A9'}
                estilo.append('background:' + cores.get(pr['marca'], '#FFFF00'))
            elif pr.get('fundo'):
                estilo.append('background:#' + pr['fundo'])
            if estilo and t.strip():
                t = f'<span style="{";".join(estilo)}">{t}</span>'
            if pr.get('va') == 'superscript':
                t = f'<sup>{t}</sup>'
            elif pr.get('va') == 'subscript':
                t = f'<sub>{t}</sub>'
            if pr.get('s'):
                t = f'<s>{t}</s>'
            if pr.get('u'):
                t = f'<u>{t}</u>'
            if pr.get('i'):
                t = f'<i>{t}</i>'
            if pr.get('b') and t.strip():
                t = f'<b>{t}</b>'
            html.append(t)
            buf.clear()

        for t, pr in trechos:
            if ant is not None and chave(pr) != chave(ant):
                fecha()
            ant = pr
            buf.append(t)
        if ant is not None:
            fecha()
        return ''.join(html)

    # -- parágrafo
    def paragrafo(self, p, rels, ctx, em_celula=False):
        pp, rp = self.props_par(p)
        trechos = self.runs(p, rp, rels, ctx)
        rotulo = ''
        if pp.get('num') and pp['num'][0] not in (None, '0'):
            nid, ilvl = pp['num']
            lv = self.numer.nivel(nid, ilvl)
            if lv is not None:
                lp = {}
                juntar_ppr(lp, lv['ppr'])
                for k in ('esq', 'desl', 'prim'):
                    if k in lp and k not in self._ppr_direto(p):
                        pp[k] = lp[k]
                rotulo = self.numer.proximo(nid, ilvl) or ''
                if rotulo:
                    rprl = dict(rp)
                    juntar_rpr(rprl, lv['rpr'], self.est)
                    if lv['fmt'] == 'bullet':
                        rprl.pop('fonte', None)
                    trechos = [(esc(rotulo) + (' ' if lv['suff'] == 'space' else ''), {**rprl, 'rot': True})] + \
                              ([('<span class="tab"> </span>', rp)] if lv['suff'] == 'tab' else []) + trechos
        tam_par = rp.get('sz') or self.tam_base
        partes = []
        atual = []
        for t, pr in trechos:
            if t == '\x00QUEBRA\x00':
                partes.append(atual); atual = []
            else:
                atual.append((t, pr))
        partes.append(atual)
        blocos = []
        for i, pedaco in enumerate(partes):
            if i > 0:
                blocos.append('<div class="quebra-pagina"></div>')
            conteudo = self.html_trechos(pedaco, self.tam_base)
            vazio = not re.sub(r'<[^>]+>|\s|&nbsp;| | ', '', conteudo) and '<img' not in conteudo
            blocos.append(self._p_html(conteudo, pp, tam_par, vazio, em_celula))
        if pp.get('quebra_antes'):
            blocos.insert(0, '<div class="quebra-pagina"></div>')
        return blocos, pp

    def _ppr_direto(self, p):
        d = {}
        juntar_ppr(d, p.find(q('w:pPr')))
        return d

    def _p_html(self, conteudo, pp, tam_par, vazio, em_celula):
        st = []
        jc = pp.get('jc')
        al = {'center': 'center', 'right': 'right', 'end': 'right', 'both': 'justify', 'distribute': 'justify',
              'left': 'left', 'start': 'left'}.get(jc)
        if al:
            st.append('text-align:' + al)
        antes, depois = pp.get('antes') or 0, pp.get('depois') or 0
        st.append(f'margin:{fmt(antes)}pt {fmt(pp.get("dir") or 0)}pt {fmt(depois)}pt {fmt(pp.get("esq") or 0)}pt')
        if pp.get('desl'):
            st.append(f'text-indent:-{fmt(pp["desl"])}pt')
            if not pp.get('esq'):
                st[-2] = st[-2].rsplit(' ', 1)[0] + f' {fmt(pp["desl"])}pt'
        elif pp.get('prim'):
            st.append(f'text-indent:{fmt(pp["prim"])}pt')
        if 'linha' in pp:
            if pp.get('regra', 'auto') == 'auto':
                lh = round(pp['linha'] / 240.0 * 1.17, 2)
                self.contagem_lh[lh] += 1
                if abs(lh - self.lh_base) > 0.01:
                    st.append(f'line-height:{fmt(lh)}')
            elif pp.get('regra') == 'atLeast':
                v = pt(pp['linha']) or 0
                if v > tam_par * 1.25:   # "pelo menos X": só vale quando é maior que a linha normal
                    st.append(f'line-height:{fmt(v)}pt')
            else:
                st.append(f'line-height:{fmt(pt(pp["linha"]))}pt')
        b = pp.get('bordas') or {}
        for lado, css in (('top', 'border-top'), ('bottom', 'border-bottom'), ('left', 'border-left'), ('right', 'border-right')):
            if b.get(lado) and b[lado] != 'none':
                st.append(f'{css}:{b[lado]}')
        if any(b.get(l) and b[l] != 'none' for l in ('left', 'right')):
            st.append('padding-left:3pt;padding-right:3pt')
        if pp.get('fundo'):
            st.append('background:#' + pp['fundo'])
        if vazio:
            if abs(tam_par - self.tam_base) >= 0.25:
                st.append(f'font-size:{fmt(tam_par)}pt')
            return f'<p class="vazio" style="{";".join(st)}">&nbsp;</p>'
        return f'<p style="{";".join(st)}">{conteudo}</p>'

    # -- caixas (parágrafos seguidos com a mesma borda viram uma caixa só, como no Word)
    def juntar_caixas(self, itens):
        out, i = [], 0

        def chave_b(pp):
            b = (pp or {}).get('bordas') or {}
            if not any(v and v != 'none' for v in b.values()):
                return None
            return tuple(b.get(l) for l in ('top', 'bottom', 'left', 'right'))
        while i < len(itens):
            html_b, pp = itens[i]
            k = chave_b(pp)
            if k is None:
                out.append(html_b); i += 1; continue
            j = i
            while j + 1 < len(itens) and chave_b(itens[j + 1][1]) == k:
                j += 1
            grupo = itens[i:j + 1]
            if len(grupo) == 1:
                out.append(html_b); i += 1; continue
            for n, (hb, _pp) in enumerate(grupo):
                if n > 0:
                    hb = re.sub(r'border-top:[^;"]*;?', '', hb, count=1)
                if n < len(grupo) - 1:
                    hb = re.sub(r'border-bottom:[^;"]*;?', '', hb, count=1)
                # sem espaço "por fora" entre os parágrafos da caixa (senão a borda fica com buracos)
                hb = re.sub(r'margin:([\d.]+)pt ([\d.]+)pt ([\d.]+)pt ([\d.]+)pt',
                            lambda m: f'margin:{m.group(1) if n == 0 else 0}pt {m.group(2)}pt {m.group(3) if n == len(grupo) - 1 else 0}pt {m.group(4)}pt;'
                                      f'padding-top:{0 if n == 0 else m.group(1)}pt;padding-bottom:{0 if n == len(grupo) - 1 else m.group(3)}pt', hb, count=1)
                out.append(hb)
            i = j + 1
        return out

    # -- tabelas
    def tabela(self, tbl, rels, ctx):
        tblpr = tbl.find(q('w:tblPr'))
        sid = wval(tblpr.find(q('w:tblStyle'))) if tblpr is not None else None
        sid = sid or self.est.tabela_padrao
        bt = {}
        mar = {'left': 5.4, 'right': 5.4, 'top': 0, 'bottom': 0}
        for s in self.est.cadeia(sid) + [{'tblpr': tblpr}]:
            tp = s.get('tblpr')
            if tp is None:
                continue
            bd = tp.find(q('w:tblBorders'))
            if bd is not None:
                for lado in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV', 'start', 'end'):
                    el = bd.find(q('w:' + lado))
                    if el is not None:
                        bt[{'start': 'left', 'end': 'right'}.get(lado, lado)] = borda_css(el)
            cm = tp.find(q('w:tblCellMar'))
            if cm is not None:
                for lado in ('left', 'right', 'top', 'bottom', 'start', 'end'):
                    el = cm.find(q('w:' + lado))
                    if el is not None and el.get(q('w:w')) is not None:
                        mar[{'start': 'left', 'end': 'right'}.get(lado, lado)] = pt(el.get(q('w:w'))) or 0
        grid = [pt(g.get(q('w:w'))) or 0 for g in tbl.findall('w:tblGrid/w:gridCol', NS)]
        total = sum(grid) or 1
        linhas = tbl.findall(q('w:tr'))
        # monta a grade com mesclas verticais
        mat = []
        for tr in linhas:
            col, row = 0, []
            for tc in tr.findall(q('w:tc')):
                tcpr = tc.find(q('w:tcPr'))
                span = int(wval(tcpr.find(q('w:gridSpan'))) or 1) if tcpr is not None and tcpr.find(q('w:gridSpan')) is not None else 1
                vm = tcpr.find(q('w:vMerge')) if tcpr is not None else None
                vmerge = None if vm is None else (wval(vm) or 'continue')
                row.append({'tc': tc, 'col': col, 'span': span, 'vm': vmerge, 'rows': 1})
                col += span
            mat.append(row)
        for ri, row in enumerate(mat):
            for c in row:
                if c['vm'] == 'restart':
                    k = ri + 1
                    while k < len(mat):
                        abaixo = [x for x in mat[k] if x['col'] == c['col']]
                        if abaixo and abaixo[0]['vm'] == 'continue':
                            c['rows'] += 1; abaixo[0]['pular'] = True; k += 1
                        else:
                            break
        largura_tab = None
        if tblpr is not None and tblpr.find(q('w:tblW')) is not None:
            tw = tblpr.find(q('w:tblW'))
            if tw.get(q('w:type')) == 'pct':
                try:
                    largura_tab = int(tw.get(q('w:w'))) / 50.0
                except (TypeError, ValueError):
                    pass
        if len(mat) == 1 and len(mat[0]) == 1 and not ctx.get('em_tabela'):
            # tabela de uma célula só = "caixa" em volta do texto (muito comum em contratos):
            # vira parágrafos com borda, para poder continuar na página seguinte
            return self._caixa(mat[0][0]['tc'], bt, mar, rels, ctx)
        out = [f'<table class="wd" style="width:{fmt(largura_tab) if largura_tab else 100}%;margin:0;border-collapse:collapse">']
        if grid:
            out.append('<colgroup>' + ''.join(f'<col style="width:{fmt(g / total * 100)}%">' for g in grid) + '</colgroup>')
        nlin = len(mat)
        for ri, (tr, row) in enumerate(zip(linhas, mat)):
            trpr = tr.find(q('w:trPr'))
            alt = ''
            if trpr is not None and trpr.find(q('w:trHeight')) is not None:
                th = trpr.find(q('w:trHeight'))
                h = pt(th.get(q('w:val')))
                if h:
                    alt = f' style="height:{fmt(h)}pt"'
            out.append(f'<tr{alt}>')
            for c in row:
                if c.get('pular'):
                    continue
                tc = c['tc']
                tcpr = tc.find(q('w:tcPr'))
                st = []
                ultima_col = c['col'] + c['span'] >= len(grid) if grid else False
                ultima_lin = ri + c['rows'] >= nlin
                b = {
                    'top': bt.get('top') if ri == 0 else bt.get('insideH'),
                    'bottom': bt.get('bottom') if ultima_lin else bt.get('insideH'),
                    'left': bt.get('left') if c['col'] == 0 else bt.get('insideV'),
                    'right': bt.get('right') if ultima_col else bt.get('insideV'),
                }
                pad = dict(mar)
                if tcpr is not None:
                    tb = tcpr.find(q('w:tcBorders'))
                    if tb is not None:
                        for lado in ('top', 'left', 'bottom', 'right', 'start', 'end'):
                            el = tb.find(q('w:' + lado))
                            if el is not None:
                                b[{'start': 'left', 'end': 'right'}.get(lado, lado)] = borda_css(el)
                    shd = tcpr.find(q('w:shd'))
                    if shd is not None and (wval(shd, 'fill') or 'auto').upper() not in ('AUTO', 'FFFFFF'):
                        st.append('background:#' + wval(shd, 'fill'))
                    va = tcpr.find(q('w:vAlign'))
                    if va is not None:
                        st.append('vertical-align:' + {'center': 'middle', 'bottom': 'bottom'}.get(wval(va), 'top'))
                    cm = tcpr.find(q('w:tcMar'))
                    if cm is not None:
                        for lado in ('left', 'right', 'top', 'bottom', 'start', 'end'):
                            el = cm.find(q('w:' + lado))
                            if el is not None and el.get(q('w:w')) is not None:
                                pad[{'start': 'left', 'end': 'right'}.get(lado, lado)] = pt(el.get(q('w:w'))) or 0
                for lado in ('top', 'right', 'bottom', 'left'):
                    st.append(f'border-{lado}:{b.get(lado) or "none"}')
                st.append(f'padding:{fmt(pad["top"])}pt {fmt(pad["right"])}pt {fmt(pad["bottom"])}pt {fmt(pad["left"])}pt')
                attrs = ''
                if c['span'] > 1:
                    attrs += f' colspan="{c["span"]}"'
                if c['rows'] > 1:
                    attrs += f' rowspan="{c["rows"]}"'
                if grid:
                    w = sum(grid[c['col']:c['col'] + c['span']]) / total * 100
                    st.append(f'width:{fmt(w)}%')
                ctx['em_tabela'] = ctx.get('em_tabela', 0) + 1
                miolo = ''.join(self.blocos(tc, rels, ctx, em_celula=True))
                ctx['em_tabela'] -= 1
                out.append(f'<td{attrs} style="{";".join(st)}">{miolo}</td>')
            out.append('</tr>')
        out.append('</table>')
        return ''.join(out)

    def _caixa(self, tc, bt, mar, rels, ctx):
        tcpr = tc.find(q('w:tcPr'))
        b = {'top': bt.get('top'), 'bottom': bt.get('bottom'), 'left': bt.get('left'), 'right': bt.get('right')}
        fundo = None
        if tcpr is not None:
            tb = tcpr.find(q('w:tcBorders'))
            if tb is not None:
                for lado in ('top', 'left', 'bottom', 'right', 'start', 'end'):
                    el = tb.find(q('w:' + lado))
                    if el is not None:
                        b[{'start': 'left', 'end': 'right'}.get(lado, lado)] = borda_css(el)
            shd = tcpr.find(q('w:shd'))
            if shd is not None and (wval(shd, 'fill') or 'auto').upper() not in ('AUTO', 'FFFFFF'):
                fundo = wval(shd, 'fill')
        ctx['em_tabela'] = ctx.get('em_tabela', 0)
        blocos = self.blocos(tc, rels, ctx, em_celula=True)
        lados = {k: (v if v and v != 'none' else None) for k, v in b.items()}
        if not any(lados.values()):
            return '<!--caixa-->' + '\n'.join(blocos)
        out, n = [], len(blocos)
        for i, bl in enumerate(blocos):
            st = []
            if lados['left']:
                st.append('border-left:' + lados['left'])
            if lados['right']:
                st.append('border-right:' + lados['right'])
            if i == 0 and lados['top']:
                st.append('border-top:' + lados['top'])
            if i == n - 1 and lados['bottom']:
                st.append('border-bottom:' + lados['bottom'])
            if fundo:
                st.append('background:#' + fundo)
            if bl.startswith('<p'):
                m = re.search(r'margin:([-\d.]+)pt ([-\d.]+)pt ([-\d.]+)pt ([-\d.]+)pt', bl)
                mt, mr, mb, ml = (float(x) for x in m.groups()) if m else (0, 0, 0, 0)
                pt_ = (mar['top'] if i == 0 else 0) + mt
                pb_ = (mar['bottom'] if i == n - 1 else 0) + mb
                novo = f'margin:0;padding:{fmt(pt_)}pt {fmt(mar["right"] + mr)}pt {fmt(pb_)}pt {fmt(mar["left"] + ml)}pt;' + ';'.join(st)
                if m:
                    bl = bl.replace(m.group(0), novo, 1)
                else:
                    bl = bl.replace('<p', f'<p style="{novo}"', 1)
                # o recuo de 1ª linha/deslocamento continua valendo (é relativo ao padding)
                out.append(bl)
            else:   # tabela dentro da caixa: embrulha para manter as bordas dos lados
                out.append(f'<div style="padding:{fmt(mar["top"] if i == 0 else 0)}pt {fmt(mar["right"])}pt {fmt(mar["bottom"] if i == n - 1 else 0)}pt {fmt(mar["left"])}pt;{";".join(st)}">{bl}</div>')
        return '<!--caixa-->' + '\n'.join(out)

    # -- blocos (corpo, célula, cabeçalho)
    def blocos(self, raiz, rels, ctx, em_celula=False):
        itens = []

        def visitar(el):
            for c in el:
                tag = etree.QName(c).localname if isinstance(c.tag, str) else ''
                if tag == 'p':
                    bl, pp = self.paragrafo(c, rels, ctx, em_celula)
                    for b in bl:
                        itens.append((b, pp if b.startswith('<p') else None))
                elif tag == 'tbl':
                    itens.append((self.tabela(c, rels, ctx), None))
                elif tag == 'sdt':
                    cont = c.find(q('w:sdtContent'))
                    if cont is not None:
                        visitar(cont)
                elif tag in ('customXml',):
                    visitar(c)
        visitar(raiz)
        out = self.juntar_caixas(itens)
        return out

    def cabecalho(self):
        """Texto do cabeçalho principal (sem as imagens, que viram o papel timbrado)."""
        sect = self.doc.find('.//w:body/w:sectPr', NS) if self.doc is not None else None
        if sect is None:
            return '', None
        refs = {r.get(q('w:type')) or 'default': r.get(q('r:id')) for r in sect.findall(q('w:headerReference'))}
        rid = refs.get('default') or refs.get('first')
        alvo = self.rels.get(rid)
        dist = None
        pm = sect.find(q('w:pgMar'))
        if pm is not None:
            dist = pt(pm.get(q('w:header')))
        x = self._xml(alvo) if alvo else None
        if x is None:
            return '', dist
        rels = self._rels('word/_rels/' + os.path.basename(alvo) + '.rels')
        ctx = {'imagens': 0, 'sem_imagens': True}
        bl = self.blocos(x, rels, ctx)
        m_esq = pt(pm.get(q('w:left'))) if pm is not None else 70.9
        m_dir = pt(pm.get(q('w:right'))) if pm is not None else 70.9
        # recuos medidos a partir da borda do papel (o cabeçalho é desenhado de ponta a ponta)
        bl = [re.sub(r'margin:([-\d.]+)pt ([-\d.]+)pt ([-\d.]+)pt ([-\d.]+)pt',
                     lambda mm: f'margin:{mm.group(1)}pt {fmt(max(0, float(mm.group(2)) + (m_dir or 0)))}pt {mm.group(3)}pt {fmt(max(0, float(mm.group(4)) + (m_esq or 0)))}pt',
                     b, count=1) if b.startswith('<p') else b for b in bl]
        html = '\n'.join(b for b in bl)
        texto = re.sub(r'<[^>]+>|&nbsp;|\s| | ', '', html)
        if not texto:
            return '', dist
        # tira parágrafos vazios do começo/fim
        while bl and bl[0].startswith('<p class="vazio"'):
            bl.pop(0)
        while bl and bl[-1].startswith('<p class="vazio"'):
            bl.pop()
        return '\n'.join(bl), dist

    def converter(self):
        ctx = {'imagens': 0}
        body = self.doc.find(q('w:body'))
        bl = self.blocos(body, self.rels, ctx)
        while bl and bl[-1].startswith('<p class="vazio"'):
            bl.pop()
        cab, dist = self.cabecalho()
        fonte = self.contagem_fontes.most_common(1)[0][0] if self.contagem_fontes else self.fonte_base
        return '\n'.join(bl), {'fonte': fonte, 'tamanho': self.tam_base, 'espacamento': self.lh_base,
                               'cabecalho': cab, 'cab_dist': dist}


def converter(conteudo, pasta_imagens=None, url_imagens='recursos/importados'):
    c = Conversor(conteudo, pasta_imagens, url_imagens)
    return c.converter()
