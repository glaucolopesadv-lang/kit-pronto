"""Gera PDF a partir das páginas já montadas na prévia, usando o Chrome (ou Edge/Brave) do próprio
computador em modo invisível. Assim o PDF sai idêntico ao que aparece na tela."""
import glob, os, platform, shutil, subprocess, tempfile

CANDIDATOS = {
    'Darwin': ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
               '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
               '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
               '/Applications/Chromium.app/Contents/MacOS/Chromium',
               os.path.expanduser('~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')],
    'Windows': [r'C:\Program Files\Google\Chrome\Application\chrome.exe',
                r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
                os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe'),
                r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
                r'C:\Program Files\Microsoft\Edge\Application\msedge.exe'],
    'Linux': ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge'],
}


def achar_navegador():
    env = os.environ.get('BANCO_MODELOS_CHROME')
    if env and os.path.exists(env):
        return env
    for c in CANDIDATOS.get(platform.system(), []):
        if os.path.isabs(c):
            if os.path.exists(c):
                return c
        elif shutil.which(c):
            return shutil.which(c)
    for c in sorted(glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome')):
        return c
    return None


def gerar_pdf(html_completo):
    nav = achar_navegador()
    if not nav:
        return None
    tmp = tempfile.mkdtemp(prefix='bm-pdf-')
    try:
        entrada = os.path.join(tmp, 'doc.html')
        saida = os.path.join(tmp, 'doc.pdf')
        with open(entrada, 'w', encoding='utf-8') as f:
            f.write(html_completo)
        perfil = os.path.join(tmp, 'perfil')
        url = 'file:///' + entrada.replace('\\', '/').lstrip('/')
        base = [nav, '--disable-gpu', '--no-first-run', '--no-default-browser-check', f'--user-data-dir={perfil}',
                '--no-pdf-header-footer', '--print-to-pdf-no-header', '--run-all-compositor-stages-before-draw',
                '--virtual-time-budget=4000', f'--print-to-pdf={saida}', url]
        if platform.system() == 'Linux' and os.geteuid() == 0:
            base.insert(1, '--no-sandbox')
        for modo in ('--headless=new', '--headless'):
            cmd = base[:1] + [modo] + base[1:]
            try:
                subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=90,
                               creationflags=0x08000000 if os.name == 'nt' else 0)
            except Exception:
                continue
            if os.path.exists(saida) and os.path.getsize(saida) > 500:
                with open(saida, 'rb') as f:
                    return f.read()
        return None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
