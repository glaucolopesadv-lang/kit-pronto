"""Leitura de documentos pessoais (RG, CNH, CIN, comprovante de residência…) com o Gemini.

As imagens/PDFs vão para a API do Gemini com a chave cadastrada nas configurações;
o programa devolve os dados já no formato dos campos do formulário."""
import io, json, re, urllib.error
from . import importador as I

MIMES = {'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp',
         'heic': 'image/heic', 'heif': 'image/heif', 'pdf': 'application/pdf'}
ESTADOS_CIVIS = ['solteiro(a)', 'casado(a)', 'divorciado(a)', 'separado(a) judicialmente', 'viúvo(a)', 'em união estável']
UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split()

PROMPT = '''Você é assistente de um escritório de advocacia brasileiro. As imagens/PDFs anexados são documentos de UM cliente:
pode haver RG, CIN (nova identidade), CNH, CPF, certidão de nascimento/casamento, carteira de trabalho e comprovante de residência
(conta de luz, água, telefone, internet, banco etc.). Leia todos com atenção (OCR) e extraia os dados do CLIENTE.

Regras:
- Nome completo exatamente como no documento de identidade (não no comprovante, se divergir).
- CPF no formato 000.000.000-00. Confira os dígitos; se não tiver certeza, deixe vazio.
- RG: número + órgão emissor/UF, ex.: "001.234.567 SSP/RN". Na CIN o número do RG é o próprio CPF: use "CPF nº ..." só se não houver outro número.
- Datas no formato AAAA-MM-DD.
- Endereço vem do comprovante de residência: "endereco" = logradouro, número e complemento (ex.: "Rua Coronel Gurgel, 1250, Apto 2"); bairro, cidade, UF (sigla) e CEP (00000-000) separados.
- Se o comprovante estiver em nome de OUTRA pessoa, informe esse nome em "titular_comprovante".
- "genero": "Masculino" ou "Feminino" somente se o documento trouxer o campo sexo; senão deixe vazio.
- "estado_civil": só se algum documento (ex.: certidão de casamento) mostrar; use um destes: {ec}.
- "nacionalidade": "brasileiro(a)" quando o documento for brasileiro.
- Não invente nada. Campo ilegível ou ausente = "".
- Em "documentos" liste o que reconheceu (ex.: ["CNH", "Conta de energia Cosern"]). Em "observacoes", avisos curtos (documento vencido, ilegível, divergência de nome etc.).

Responda só JSON:
{{"nome":"","cpf":"","rg":"","nascimento":"","genero":"","nacionalidade":"","naturalidade":"","nome_mae":"","nome_pai":"","estado_civil":"",
"endereco":"","bairro":"","cidade":"","uf":"","cep":"","titular_comprovante":"","documentos":[],"observacoes":[]}}'''

MAPA = [  # chave do JSON -> (campo do formulário, rótulo)
    ('nome', 'cliente_nome', 'Nome completo'), ('cpf', 'cliente_cpf', 'CPF'), ('rg', 'cliente_rg', 'RG / Identidade'),
    ('nascimento', 'cliente_nascimento', 'Data de nascimento'), ('genero', 'cliente_genero', 'Gênero'),
    ('nacionalidade', 'cliente_nacionalidade', 'Nacionalidade'), ('naturalidade', 'cliente_naturalidade', 'Naturalidade'),
    ('nome_mae', 'cliente_mae', 'Nome da mãe'), ('nome_pai', 'cliente_pai', 'Nome do pai'),
    ('estado_civil', 'cliente_estado_civil', 'Estado civil'),
    ('endereco', 'cliente_endereco', 'Endereço (rua, nº)'), ('bairro', 'cliente_bairro', 'Bairro'),
    ('cidade', 'cliente_cidade', 'Cidade'), ('uf', 'cliente_uf', 'UF'), ('cep', 'cliente_cep', 'CEP'),
]


def _mime(nome, conteudo):
    ext = nome.rsplit('.', 1)[-1].lower() if '.' in nome else ''
    if ext in MIMES:
        return MIMES[ext]
    if conteudo[:4] == b'%PDF':
        return 'application/pdf'
    if conteudo[:3] == b'\xff\xd8\xff':
        return 'image/jpeg'
    if conteudo[:8] == b'\x89PNG\r\n\x1a\n':
        return 'image/png'
    return None


def _reduzir(mime, conteudo):
    """Fotos muito grandes (celular) são reduzidas para caber no limite da API."""
    if not mime.startswith('image/') or mime in ('image/heic', 'image/heif') or len(conteudo) < 3_500_000:
        return mime, conteudo
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(conteudo)); im = im.convert('RGB')
        im.thumbnail((2600, 2600))
        out = io.BytesIO(); im.save(out, 'JPEG', quality=88)
        return 'image/jpeg', out.getvalue()
    except Exception:
        return mime, conteudo


def _so_dig(s):
    return re.sub(r'\D', '', s or '')


def _limpar(r):
    v = {k: (str(r.get(k) or '').strip()) for k, _, _ in MAPA}
    d = _so_dig(v['cpf'])
    v['cpf'] = f'{d[:3]}.{d[3:6]}.{d[6:9]}-{d[9:]}' if len(d) == 11 else ''
    d = _so_dig(v['cep'])
    v['cep'] = f'{d[:5]}-{d[5:]}' if len(d) == 8 else ''
    v['uf'] = v['uf'].upper() if v['uf'].upper() in UFS else ''
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', v['nascimento']):
        m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', v['nascimento'])
        v['nascimento'] = f'{m[3]}-{m[2]}-{m[1]}' if m else ''
    g = v['genero'].lower()
    v['genero'] = 'Feminino' if g.startswith('f') else 'Masculino' if g.startswith('m') else ''
    base = lambda t: re.sub(r'^em ', '', I.norm(t).strip())[:5]
    ec = base(v['estado_civil'])
    v['estado_civil'] = next((e for e in ESTADOS_CIVIS if ec and base(e) == ec), '')
    if v['nacionalidade'] and I.norm(v['nacionalidade']).startswith('brasileir'):
        v['nacionalidade'] = 'brasileiro(a)'
    return v


def cpf_valido(c):
    d = _so_dig(c)
    if len(d) != 11 or d == d[0] * 11:
        return False
    for n in (9, 10):
        s = sum(int(d[i]) * (n + 1 - i) for i in range(n))
        if (s * 10 % 11) % 10 != int(d[n]):
            return False
    return True


class _SemIA(Exception):
    """O Gemini não pôde ser usado agora (sem internet, limite, chave) — cai para a leitura no computador."""


def _gemini(anexos, chave, cfg):
    prompt = PROMPT.format(ec=json.dumps(ESTADOS_CIVIS, ensure_ascii=False))
    try:
        r = I.gemini(prompt, chave, cfg.get('gemini_modelo') or 'gemini-2.5-flash', timeout=90, anexos=anexos)
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get('error', {}).get('message', '')
        except Exception:
            msg = ''
        if e.code in (400, 403) and 'API key' in msg:
            raise _SemIA('a chave do Gemini não foi aceita')
        if e.code == 429:
            raise _SemIA('o Gemini atingiu o limite de uso')
        if e.code >= 500:
            raise _SemIA('o Gemini está fora do ar')
        raise ValueError(f'O Gemini recusou a leitura ({e.code}). {msg}'.strip())
    except (urllib.error.URLError, TimeoutError, OSError):
        raise _SemIA('sem internet')
    except (json.JSONDecodeError, KeyError, IndexError):
        raise ValueError('O Gemini não conseguiu ler esses arquivos. Tente fotos mais nítidas, sem reflexo, com o documento inteiro aparecendo.')
    if isinstance(r, list):
        r = r[0] if r else {}
    return r


def _local(arquivos):
    from . import ocr_local as L
    textos, sem_leitor = [], False
    for nome, b in arquivos:
        try:
            linhas = L.texto_do_arquivo(nome, b, _mime(nome, b))
        except RuntimeError:
            sem_leitor = True; continue
        except Exception:
            linhas = []
        if linhas:
            textos.append((nome, linhas))
    if not textos:
        if sem_leitor:
            raise ValueError('Sem internet agora, e a leitura no próprio computador ainda não está instalada. '
                             'Feche e abra o Kit Pronto uma vez com internet para instalar (é automático).')
        raise ValueError('Não consegui ler texto nesses arquivos. Tente uma foto mais nítida, sem reflexo, com o documento inteiro.')
    r, docs = L.extrair(textos)
    r['documentos'] = docs
    r['_texto'] = [l for _, ls in textos for l in ls][:120]
    return r


def ler(arquivos, cfg):
    """arquivos: lista de (nome, bytes). Devolve {'campos': [...], 'documentos': [...], 'avisos': [...], 'modo': 'ia'|'local'}"""
    anexos = []
    for nome, b in arquivos:
        m = _mime(nome, b)
        if not m:
            raise ValueError(f'Formato não suportado: {nome}. Use foto (JPG, PNG, HEIC) ou PDF.')
        anexos.append(_reduzir(m, b))
    if sum(len(b) for _, b in anexos) > 18_000_000:
        raise ValueError('Arquivos grandes demais juntos (máx. ~18 MB). Envie menos páginas ou fotos menores.')
    chave = cfg.get('gemini_chave')
    motivo, modo = None, 'ia'
    r = None
    if chave and not cfg.get('ocr_so_local'):
        try:
            r = _gemini(anexos, chave, cfg)
        except _SemIA as e:
            motivo = str(e)
    else:
        motivo = 'sem chave do Gemini'
    if r is None:
        modo = 'local'
        r = _local(arquivos)
    v = _limpar(r)
    avisos = [str(x) for x in (r.get('observacoes') or []) if str(x).strip()]
    if modo == 'local':
        avisos.insert(0, f'Lido no próprio computador ({motivo}). Confira com atenção: a leitura sem IA pode errar letras e números.')
    if v['cpf'] and not cpf_valido(v['cpf']):
        avisos.insert(0, f'O CPF lido ({v["cpf"]}) não confere nos dígitos verificadores — confira no documento.')
    tit = str(r.get('titular_comprovante') or '').strip()
    if tit and v['nome'] and I.norm(tit) != I.norm(v['nome']):
        avisos.insert(0, f'O comprovante de residência está em nome de {tit}.')
    campos = [{'chave': ch, 'rotulo': rot, 'valor': v[k]} for k, ch, rot in MAPA if v[k]]
    texto = r.get('_texto') or []
    if modo == 'local' and not v['nome'] and texto:
        avisos.insert(0, 'Não achei o nome. Veja abaixo o texto que o computador leu e copie o nome de lá.')
    if not campos:
        raise ValueError('Não encontrei dados legíveis nesses arquivos. Tente uma foto mais nítida, sem reflexo, com o documento inteiro.')
    return {'campos': campos, 'documentos': [str(x) for x in (r.get('documentos') or [])], 'avisos': avisos, 'modo': modo,
            'texto': texto if modo == 'local' else []}
