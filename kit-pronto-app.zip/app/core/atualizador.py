"""Atualização automática do PROGRAMA (só a pasta app/) a partir do GitHub.

O repositório público tem:
    versao.json   {"versao": "2.3", "notas": ["...", "..."], "arquivo": "kit-pronto-app.zip"}
    kit-pronto-app.zip   (contém app/...)
Modelos, timbrados, clientes, documentos e configurações NÃO são tocados.
"""
import io, json, os, shutil, ssl, sys, tempfile, time, urllib.request, zipfile

REPO = 'glaucolopesadv-lang/kit-pronto'
BASE = os.environ.get('KP_UPD_BASE') or f'https://raw.githubusercontent.com/{REPO}/main/'
APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../Programa/app
PROGRAMA = os.path.dirname(APP_DIR)


def _ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _baixar(url, timeout=20):
    req = urllib.request.Request(url + ('&' if '?' in url else '?') + f't={int(time.time())}',
                                 headers={'User-Agent': 'KitPronto', 'Cache-Control': 'no-cache'})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read()
    except ssl.SSLError:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl._create_unverified_context()) as r:
            return r.read()


def _num(v):
    try:
        return tuple(int(x) for x in str(v).strip().split('.'))
    except Exception:
        return (0,)


def verificar(atual):
    """Devolve {'atual', 'nova', 'tem_nova', 'notas'} ou {'erro'} se não conseguir consultar."""
    try:
        info = json.loads(_baixar(BASE + 'versao.json', timeout=8).decode('utf-8'))
    except Exception as e:
        return {'atual': atual, 'erro': f'Sem conexão com o servidor de atualizações ({e.__class__.__name__}).'}
    nova = str(info.get('versao') or '')
    return {'atual': atual, 'nova': nova, 'tem_nova': _num(nova) > _num(atual),
            'notas': info.get('notas') or [], 'arquivo': info.get('arquivo') or 'kit-pronto-app.zip'}


def aplicar(atual):
    """Baixa e instala a versão nova por cima de app/ (guarda a anterior em app-anterior/)."""
    v = verificar(atual)
    if v.get('erro'):
        raise RuntimeError(v['erro'])
    if not v.get('tem_nova'):
        return {'ok': True, 'nada': True, 'versao': atual}
    dados = _baixar(BASE + v['arquivo'], timeout=120)
    z = zipfile.ZipFile(io.BytesIO(dados))
    nomes = z.namelist()
    if 'app/app.py' not in nomes:
        raise RuntimeError('Pacote de atualização inválido.')
    tmp = tempfile.mkdtemp(prefix='kp-upd-')
    try:
        for n in nomes:
            if n.endswith('/') or not n.startswith('app/') or '..' in n.split('/'):
                continue
            destino = os.path.join(tmp, *n.split('/'))
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            with open(destino, 'wb') as f:
                f.write(z.read(n))
        novo = os.path.join(tmp, 'app')
        compile(open(os.path.join(novo, 'app.py'), encoding='utf-8').read(), 'app.py', 'exec')  # sanidade
        # guarda a versão atual (para voltar, se precisar)
        anterior = os.path.join(PROGRAMA, 'app-anterior')
        shutil.rmtree(anterior, ignore_errors=True)
        shutil.copytree(APP_DIR, anterior, ignore=shutil.ignore_patterns('__pycache__'))
        # copia por cima (não renomeia a pasta: no Windows ela pode estar em uso)
        for raiz, _ds, fs in os.walk(novo):
            rel = os.path.relpath(raiz, novo)
            alvo = os.path.join(APP_DIR, rel) if rel != '.' else APP_DIR
            os.makedirs(alvo, exist_ok=True)
            for f in fs:
                shutil.copy2(os.path.join(raiz, f), os.path.join(alvo, f))
        for raiz, ds, _fs in os.walk(APP_DIR):
            for d in ds:
                if d == '__pycache__':
                    shutil.rmtree(os.path.join(raiz, d), ignore_errors=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return {'ok': True, 'versao': v['nova'], 'notas': v['notas']}


def reiniciar(porta):
    """Abre uma nova cópia do programa (na mesma porta) e encerra esta."""
    import subprocess
    env = dict(os.environ)
    env['BANCO_MODELOS_PORTA'] = str(porta)
    env['KP_REINICIO'] = '1'
    args = [sys.executable, '-X', 'utf8', os.path.join(APP_DIR, 'app.py')]
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0

    def _vai():
        time.sleep(1.2)
        subprocess.Popen(args, env=env, cwd=PROGRAMA, creationflags=flags, close_fds=True)
        os._exit(0)
    import threading
    threading.Thread(target=_vai, daemon=True).start()
