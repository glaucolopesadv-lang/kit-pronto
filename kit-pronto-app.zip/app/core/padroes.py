"""Kits padrão do escritório: ficam num repositório PRIVADO do GitHub e cada computador baixa sozinho.

O repositório privado tem:
    padroes.json        {"versao": "2026-11-09.1", "notas": [...], "arquivo": "padroes.kitpronto"}
    padroes.kitpronto   (pacote com os kits/modelos padrão, timbrados e imagens)
Cada computador precisa da chave de leitura (token do GitHub, só leitura deste repositório),
guardada em Sistema/config.json (nunca vai para pacotes nem para o GitHub).
"""
import base64, json, os, ssl, threading, time, urllib.error, urllib.request

from . import biblioteca as B
from . import pacote as PK

REPO = 'glaucolopesadv-lang/kit-pronto-modelos'
BASE_TESTE = os.environ.get('KP_PADROES_BASE')   # só para testes (servidor local com os mesmos arquivos)
FORMATO_CHAVE = 'kitpronto-chave'


def _ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _baixar(caminho, chave, timeout=30):
    if BASE_TESTE:
        url = BASE_TESTE.rstrip('/') + '/' + caminho
        req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + chave})
    else:
        url = f'https://api.github.com/repos/{REPO}/contents/{caminho}?t={int(time.time())}'
        req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + chave, 'User-Agent': 'KitPronto',
                                                   'Accept': 'application/vnd.github.raw+json', 'X-GitHub-Api-Version': '2022-11-28'})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise RuntimeError('A chave dos kits padrão não foi aceita (pode ter sido cancelada ou vencido). Peça uma chave nova.')
        if e.code == 404:
            raise RuntimeError('A chave não dá acesso aos kits padrão, ou eles ainda não foram publicados.')
        raise RuntimeError(f'Erro {e.code} ao buscar os kits padrão.')
    except ssl.SSLError:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl._create_unverified_context()) as r:
            return r.read()


def verificar(cfg=None):
    cfg = cfg or B.config()
    chave = cfg.get('padroes_chave') or ''
    if not chave:
        return {'sem_chave': True}
    try:
        info = json.loads(_baixar('padroes.json', chave, timeout=10).decode('utf-8'))
    except Exception as e:
        return {'erro': str(e)}
    nova = str(info.get('versao') or '')
    return {'atual': cfg.get('padroes_versao') or '', 'nova': nova, 'tem_nova': bool(nova) and nova != (cfg.get('padroes_versao') or ''),
            'notas': info.get('notas') or [], 'arquivo': info.get('arquivo') or 'padroes.kitpronto'}


_trava = threading.Lock()


def aplicar(forcar=False):
    """Baixa e instala os kits padrão (substitui os padrões antigos; os modelos da pessoa não são tocados)."""
    with _trava:
        return _aplicar(forcar)


def _aplicar(forcar):
    cfg = B.config()
    v = verificar(cfg)
    if v.get('sem_chave') or v.get('erro'):
        return v
    if cfg.get('editar_padroes') and not forcar:
        # computador de quem mantém os padrões: os modelos daqui SÃO a origem; não baixa por cima
        return {'nada': True, 'mantenedor': True, 'versao': v.get('atual')}
    if not v['tem_nova'] and not forcar:
        return {'nada': True, 'versao': v['atual']}
    dados = _baixar(v['arquivo'], cfg['padroes_chave'], timeout=120)
    r = PK.instalar(dados, 'substituir', padrao=True)
    novos = {s['id'] for s in r['salvos']}
    # o que era padrão e saiu da lista volta a ser um modelo comum (não é apagado)
    for m in B.listar_modelos():
        if m.get('padrao') and m['id'] not in novos:
            mm = B.obter_modelo(m['id'])
            if mm:
                html = mm.pop('html', '')
                mm.pop('padrao', None)
                B.salvar_modelo({k: x for k, x in mm.items() if not k.startswith('_')} | {'id': m['id']}, html)
    B.salvar_config({'padroes_versao': v['nova']})
    return {'ok': True, 'versao': v['nova'], 'notas': v['notas'], 'n': len(r['salvos'])}


def testar(chave):
    _baixar('padroes.json', chave, timeout=10)
    return True


def arquivo_chave(chave):
    """Arquivo para ativar os kits padrão em outro computador (importa-se como um modelo)."""
    return json.dumps({'formato': FORMATO_CHAVE, 'versao': 1, 'chave': base64.b64encode(chave.encode()).decode()}).encode()


def ler_arquivo_chave(conteudo):
    try:
        d = json.loads(conteudo.decode('utf-8'))
        assert d.get('formato') == FORMATO_CHAVE
        return base64.b64decode(d['chave']).decode()
    except Exception:
        raise ValueError('Este arquivo de ativação está danificado.')


def empacotar(ids, versao, notas=None):
    """(No computador de quem mantém) gera os dois arquivos para publicar no repositório privado."""
    _nome, dados = PK.exportar_varios(ids, 'Kits padrão do escritório')
    info = {'versao': versao, 'notas': notas or [], 'arquivo': 'padroes.kitpronto'}
    return dados, json.dumps(info, ensure_ascii=False, indent=1).encode('utf-8')

