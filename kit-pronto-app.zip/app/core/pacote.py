"""Arquivo .kitpronto: leva um modelo (ou kit) completo para outra pessoa que tem o Kit Pronto.

Dentro (é um zip):
  pacote.json                      -> o que vem: {'formato': 'kitpronto', 'versao': 1, 'principal': id, 'modelos': [...]}
  modelos/<id>.json                -> ficha do modelo + texto (html)
  timbrados/<id>/timbrado.json     -> papel timbrado usado (e fundo.png)
  recursos/...                     -> imagens usadas (logos, ícones, páginas de PDF)
Nada de clientes, documentos gerados ou configurações.
"""
import io, json, os, re, shutil, zipfile
from urllib.parse import unquote

from . import biblioteca as B

FORMATO = 'kitpronto'
RE_RECURSO = re.compile(r'recursos/([^"\'\)\s<>?#\\]+)')


def _recursos_de(texto):
    out = set()
    for m in RE_RECURSO.finditer(texto or ''):
        rel = unquote(m.group(1))
        if '..' in rel.split('/'):
            continue
        out.add(rel)
    return out


def exportar(mid):
    """Devolve (nome_do_arquivo, bytes)."""
    m = B.obter_modelo(mid)
    if not m:
        raise ValueError('Modelo não encontrado')
    return _empacotar([mid], m['id'], m['nome'])


def exportar_varios(ids, nome=''):
    """Vários modelos/kits num arquivo só (cada kit leva os documentos dele)."""
    ids = [i for i in ids if B.obter_modelo(i)]
    if not ids:
        raise ValueError('Escolha pelo menos um modelo.')
    if len(ids) == 1:
        return exportar(ids[0])
    import datetime
    nome = nome or ('Modelos do escritório — ' + datetime.date.today().strftime('%d-%m-%Y'))
    return _empacotar(ids, None, nome)


def _empacotar(ids, principal, nome_pacote):
    modelos = []
    for mid in ids:
        m = B.obter_modelo(mid)
        if not m or m['id'] in [x['id'] for x in modelos]:
            continue
        modelos.append(m)
        if m.get('tipo') == 'kit':
            for it in m.get('itens', []):
                sub = B.obter_modelo(it.get('modelo'))
                if sub and sub['id'] not in [x['id'] for x in modelos]:
                    modelos.append(sub)
    timbrados, recursos = set(), set()
    for x in modelos:
        if x.get('timbrado') and x['timbrado'] != 'nenhum':
            timbrados.add(x['timbrado'])
        for it in x.get('itens', []) or []:
            if it.get('timbrado') and it['timbrado'] != 'nenhum':
                timbrados.add(it['timbrado'])
        recursos |= _recursos_de(json.dumps(x, ensure_ascii=False))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        lista = []
        for x in modelos:
            meta = {k: v for k, v in x.items() if not k.startswith('_')}
            z.writestr(f'modelos/{x["id"]}.json', json.dumps(meta, ensure_ascii=False, indent=1))
            lista.append({'id': x['id'], 'nome': x['nome'], 'categoria': x['categoria'], 'tipo': x.get('tipo', 'modelo')})
        for tid in sorted(timbrados):
            pasta = os.path.join(B.P_TIMBRADOS, tid)
            if os.path.isdir(pasta):
                for f in os.listdir(pasta):
                    if f in ('timbrado.json', 'fundo.png'):
                        z.write(os.path.join(pasta, f), f'timbrados/{tid}/{f}')
        for rel in sorted(recursos):
            p = os.path.join(B.P_RECURSOS, *rel.split('/'))
            if os.path.isfile(p):
                z.write(p, 'recursos/' + rel)
        z.writestr('pacote.json', json.dumps({'formato': FORMATO, 'versao': 1, 'principal': principal,
                                              'nome': nome_pacote, 'modelos': lista,
                                              'timbrados': sorted(timbrados)}, ensure_ascii=False, indent=1))
    return B.nome_seguro(nome_pacote) + '.kitpronto', buf.getvalue()


def _abrir(dados):
    try:
        z = zipfile.ZipFile(io.BytesIO(dados))
        info = json.loads(z.read('pacote.json').decode('utf-8'))
    except Exception:
        raise ValueError('Este arquivo .kitpronto está danificado ou não é do Kit Pronto.')
    if info.get('formato') != FORMATO:
        raise ValueError('Este arquivo não é um modelo do Kit Pronto.')
    return z, info


def resumo(dados):
    """O que tem no arquivo e o que já existe aqui."""
    _z, info = _abrir(dados)
    meus = {m['id']: m for m in B.listar_modelos()}
    modelos = []
    for x in info.get('modelos', []):
        modelos.append({**x, 'existe': x['id'] in meus})
    return {'nome': info.get('nome'), 'principal': info.get('principal'), 'modelos': modelos,
            'conflito': any(x['existe'] for x in modelos)}


def instalar(dados, modo='substituir'):
    """modo: 'substituir' (atualiza o modelo com o mesmo nome) ou 'copia' (guarda ao lado, como cópia)."""
    z, info = _abrir(dados)
    nomes = z.namelist()
    # imagens: só grava as que ainda não existem (não mexe nas suas)
    for n in nomes:
        if n.startswith('recursos/') and not n.endswith('/') and '..' not in n.split('/'):
            destino = os.path.join(B.P_RECURSOS, *n.split('/')[1:])
            if not os.path.exists(destino):
                os.makedirs(os.path.dirname(destino), exist_ok=True)
                with open(destino, 'wb') as f:
                    f.write(z.read(n))
    # papel timbrado: se você já tem um com o mesmo nome, fica o seu
    ja_tinha = {}
    for n in nomes:
        partes = n.split('/')
        if len(partes) == 3 and partes[0] == 'timbrados' and partes[2] in ('timbrado.json', 'fundo.png') and '..' not in partes and partes[1]:
            tid = partes[1]
            if tid not in ja_tinha:
                ja_tinha[tid] = os.path.exists(os.path.join(B.P_TIMBRADOS, tid, 'timbrado.json'))
            if not ja_tinha[tid]:
                destino = os.path.join(B.P_TIMBRADOS, tid, partes[2])
                os.makedirs(os.path.dirname(destino), exist_ok=True)
                with open(destino, 'wb') as f:
                    f.write(z.read(n))
    meus = {m['id'] for m in B.listar_modelos()}
    mapa, salvos = {}, []
    lista = info.get('modelos', [])
    # primeiro os modelos, depois os kits (que apontam para eles)
    for x in sorted(lista, key=lambda x: x.get('tipo') == 'kit'):
        try:
            meta = json.loads(z.read(f'modelos/{x["id"]}.json').decode('utf-8'))
        except KeyError:
            continue
        html = meta.pop('html', '')
        for k in ('criado', 'atualizado', 'seed_atualizado', 'versao_seed'):
            meta.pop(k, None)
        if meta.get('tipo') == 'kit':
            for it in meta.get('itens', []):
                it['modelo'] = mapa.get(it.get('modelo'), it.get('modelo'))
        if meta['id'] in meus and modo == 'copia':
            antigo = meta.pop('id')
            meta['nome'] = meta.get('nome', 'Modelo') + ' (recebido)'
            novo = B.salvar_modelo(meta, html)
            mapa[antigo] = novo['id']
        else:
            novo = B.salvar_modelo(meta, html)
            mapa[x['id']] = novo['id']
        salvos.append({'id': novo['id'], 'nome': novo['nome'], 'categoria': novo['categoria']})
    principal = mapa.get(info.get('principal'), info.get('principal'))
    return {'salvos': salvos, 'principal': principal}


def de_json(conteudo, html=''):
    """Arquivo .json da pasta Modelos (copiado num pendrive, por exemplo) -> pacote .kitpronto em memória.
    O texto do modelo fica no .html de mesmo nome."""
    try:
        meta = json.loads(conteudo.decode('utf-8-sig') if isinstance(conteudo, bytes) else conteudo)
    except Exception:
        raise ValueError('Este arquivo .json não é um modelo do Kit Pronto.')
    if not isinstance(meta, dict) or not meta.get('nome') or not meta.get('id') or 'campos' not in meta:
        raise ValueError('Este arquivo .json não é um modelo do Kit Pronto.')
    tipo = meta.get('tipo', 'modelo')
    if tipo != 'kit' and meta.get('formato') != 'paginas' and not (html or '').strip():
        raise ValueError(f'Falta o texto do modelo: escolha também o arquivo "{meta["nome"]}.html", '
                         'que fica junto deste .json na mesma pasta. (Mais fácil: no outro computador use '
                         '📤 Enviar vários de uma vez e mande o arquivo .kitpronto.)')
    meta = {k: v for k, v in meta.items() if not k.startswith('_')}
    meta['html'] = html or ''
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr(f'modelos/{meta["id"]}.json', json.dumps(meta, ensure_ascii=False))
        z.writestr('pacote.json', json.dumps({'formato': FORMATO, 'versao': 1, 'principal': meta['id'], 'nome': meta['nome'],
                                              'modelos': [{'id': meta['id'], 'nome': meta['nome'], 'categoria': meta.get('categoria') or 'Modelos',
                                                           'tipo': tipo}], 'timbrados': []}, ensure_ascii=False))
    return buf.getvalue()

