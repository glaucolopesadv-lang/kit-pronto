"""Kit Pronto — servidor local (Flask). Abre numa janela própria (pywebview) ou no navegador."""
import base64, datetime, io, json, os, platform, re, subprocess, sys, threading, time, webbrowser

from flask import Flask, jsonify, request, send_file, send_from_directory, abort

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
if sys.stdout is None or sys.stderr is None:   # Windows sem janela de console (pythonw): guarda o registro num arquivo
    _log_dir = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'KitPronto')
    os.makedirs(_log_dir, exist_ok=True)
    sys.stdout = sys.stderr = open(os.path.join(_log_dir, 'kitpronto.log'), 'a', encoding='utf-8', buffering=1)
from core import atualizador as UPD
from core import pacote as PK
from core import biblioteca as B, importador as I, docx_export as DX, pdf_export as PX, timbrados as T, pdf_paginas as PP, ocr as OCR, celular as CEL  # noqa

VERSAO = '2.18'
AQUI = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(AQUI, 'static')
app = Flask(__name__, static_folder=None)
app.config['MAX_CONTENT_LENGTH'] = 80 * 1024 * 1024


def ok(**k):
    k.setdefault('ok', True)
    return jsonify(k)


def erro(msg, cod=400):
    r = jsonify({'ok': False, 'erro': msg}); r.status_code = cod; return r


@app.errorhandler(Exception)
def _err(e):
    import traceback
    traceback.print_exc()
    code = getattr(e, 'code', 500)
    if not isinstance(code, int):
        code = 500
    return erro(str(e) or type(e).__name__, code)


# ------------------------------------------------------------------ páginas e arquivos
@app.route('/')
def index():
    r = send_from_directory(STATIC, 'index.html'); r.headers['Cache-Control'] = 'no-store'; return r


@app.route('/static/<path:p>')
def estaticos(p):
    r = send_from_directory(STATIC, p); r.headers['Cache-Control'] = 'no-store'; return r


@app.route('/recursos/<path:p>')
def recursos(p):
    return send_from_directory(B.P_RECURSOS, p)


@app.route('/timbrado/<tid>/fundo.png')
def fundo(tid):
    f = B.caminho_fundo(tid)
    if not f:
        abort(404)
    r = send_file(f, mimetype='image/png'); r.headers['Cache-Control'] = 'no-cache'; return r


# ------------------------------------------------------------------ biblioteca
def _gerados_mes():
    """Quantos documentos foram gerados neste mês (em todas as pastas de clientes)."""
    if not os.path.isdir(B.P_GERADOS):
        return 0
    hoje = datetime.date.today(); n = 0
    for raiz, _, arqs in os.walk(B.P_GERADOS):
        for f in arqs:
            if f.startswith('.'):
                continue
            try:
                d = datetime.date.fromtimestamp(os.path.getmtime(os.path.join(raiz, f)))
            except OSError:
                continue
            if (d.year, d.month) == (hoje.year, hoje.month):
                n += 1
    return n


@app.route('/api/biblioteca')
def api_biblioteca():
    modelos = B.listar_modelos()
    tnomes = {t['id']: t['nome'] for t in B.listar_timbrados()}
    for m in modelos:
        m['n_campos'] = len(m.get('campos', []))
        m['timbrado_nome'] = 'Sem timbrado' if m.get('timbrado') == 'nenhum' else tnomes.get(m.get('timbrado'), '')
        if m.get('tipo') == 'kit':
            m['n_itens'] = len(m.get('itens', []))
    return ok(modelos=modelos, categorias=B.categorias(), timbrados=B.listar_timbrados(),
              config={k: v for k, v in B.config().items() if k != 'gemini_chave'} | {'tem_chave_ia': bool(B.config().get('gemini_chave'))},
              pasta=B.DADOS, gerados_mes=_gerados_mes(), versao=VERSAO,
              janela=bool(os.environ.get('BANCO_MODELOS_JANELA')))


@app.route('/api/modelo/<mid>')
def api_modelo(mid):
    m = B.modelo_completo(mid)
    return ok(modelo=m) if m else erro('Modelo não encontrado', 404)


@app.route('/api/modelo', methods=['POST'])
def api_salvar_modelo():
    d = request.get_json(force=True)
    html = d.pop('html', None)
    m = B.salvar_modelo(d, html)
    return ok(modelo=m)


@app.route('/api/modelo/<mid>/duplicar', methods=['POST'])
def api_duplicar(mid):
    return ok(modelo=B.duplicar_modelo(mid))


@app.route('/api/modelo/<mid>', methods=['DELETE'])
def api_excluir(mid):
    return ok(excluido=B.excluir_modelo(mid))


@app.route('/api/categoria', methods=['POST'])
def api_categoria():
    d = request.get_json(force=True)
    if d.get('de'):
        return ok(nome=B.renomear_categoria(d['de'], d['para']))
    return ok(nome=B.criar_categoria(d['nome']))


# ------------------------------------------------------------------ importação
_importados = {}


def _analisar_arquivo(nome, conteudo, modo=None, html=''):
    token = base64.urlsafe_b64encode(os.urandom(9)).decode()
    if nome.lower().endswith('.json'):
        # modelo copiado da pasta Modelos (.json + .html de mesmo nome): vira um pacote e instala igual ao .kitpronto
        conteudo = PK.de_json(conteudo, html)
        nome = os.path.splitext(nome)[0] + '.kitpronto'
    if nome.lower().endswith('.kitpronto'):
        # modelo enviado por outra pessoa que usa o Kit Pronto: vem pronto, é só instalar
        r = PK.resumo(conteudo)
        _importados[token] = (nome, conteudo)
        r.update(modo='pacote', token=token, arquivo=nome)
        return r
    if nome.lower().endswith('.pdf') and modo != 'texto':
        # PDF: mantém a página original e põe os campos por cima
        r = PP.analisar(nome, conteudo)
        _importados[token] = (nome, conteudo, r.pop('imagens'))
        r.update(token=token, arquivo=nome)
        return r
    r = I.analisar(nome, conteudo)
    _importados[token] = (nome, conteudo)
    r['token'] = token
    r['arquivo'] = nome
    return r


@app.route('/api/modelo/<mid>/enviar', methods=['POST'])
def api_modelo_enviar(mid):
    try:
        nome, dados = PK.exportar(mid)
    except ValueError as e:
        return erro(str(e))
    pasta = _pasta_downloads()
    base, ext = os.path.splitext(nome)
    p = os.path.join(pasta, nome); n = 2
    while os.path.exists(p):
        p = os.path.join(pasta, f'{base} ({n}){ext}'); n += 1
    with open(p, 'wb') as f:
        f.write(dados)
    return ok(caminho=p, nome=os.path.basename(p))


@app.route('/api/modelos/enviar', methods=['POST'])
def api_modelos_enviar():
    d = request.get_json(force=True)
    try:
        nome, dados = PK.exportar_varios(d.get('ids') or [], d.get('nome') or '')
    except ValueError as e:
        return erro(str(e))
    pasta = _pasta_downloads()
    base, ext = os.path.splitext(nome)
    p = os.path.join(pasta, nome); n = 2
    while os.path.exists(p):
        p = os.path.join(pasta, f'{base} ({n}){ext}'); n += 1
    with open(p, 'wb') as f:
        f.write(dados)
    return ok(caminho=p, nome=os.path.basename(p))


@app.route('/api/pacote/instalar', methods=['POST'])
def api_pacote_instalar():
    d = request.get_json(force=True)
    item = _importados.get(d.get('token'))
    if not item:
        return erro('A importação expirou. Escolha o arquivo de novo.')
    try:
        r = PK.instalar(item[1], d.get('modo') or 'substituir')
    except ValueError as e:
        return erro(str(e))
    return ok(**r)


@app.route('/api/importar', methods=['POST'])
def api_importar():
    f = request.files.get('arquivo')
    if not f:
        return erro('Nenhum arquivo enviado')
    h = request.files.get('html')
    html = h.read().decode('utf-8', 'replace') if h else ''
    try:
        return ok(sugestao=_analisar_arquivo(f.filename, f.read(), request.form.get('modo'), html))
    except ValueError as e:
        return erro(str(e))


@app.route('/api/importar/caminho', methods=['POST'])
def api_importar_caminho():
    """Arquivo escolhido na janela do computador (permite escolher vários de uma vez)."""
    cam = (request.get_json(force=True) or {}).get('caminho') or ''
    if not os.path.isfile(cam):
        return erro('Arquivo não encontrado')
    with open(cam, 'rb') as fh:
        conteudo = fh.read()
    html = ''
    if cam.lower().endswith('.json'):
        irmao = os.path.splitext(cam)[0] + '.html'
        if os.path.isfile(irmao):
            with open(irmao, encoding='utf-8', errors='replace') as fh:
                html = fh.read()
    try:
        return ok(sugestao=_analisar_arquivo(os.path.basename(cam), conteudo, None, html))
    except ValueError as e:
        return erro(str(e))


class _ApiJanela:
    """Funções chamadas pela página quando o programa está na janela própria (pywebview)."""
    def escolher_arquivos(self):
        import webview
        tipos = ('Modelos (*.kitpronto;*.docx;*.doc;*.pdf;*.rtf;*.odt;*.pages;*.txt;*.json)', 'Todos os arquivos (*.*)')
        fd = getattr(webview, 'FileDialog', None)
        tipo = fd.OPEN if fd is not None else webview.OPEN_DIALOG
        try:
            r = webview.windows[0].create_file_dialog(tipo, allow_multiple=True, file_types=tipos)
        except Exception:
            r = webview.windows[0].create_file_dialog(tipo, allow_multiple=True)
        return list(r or [])


# ------------------------------------------------------------------ Google Drive (pasta do Drive para computador)
EXT_IMPORTAVEIS = ('.kitpronto', '.json', '.pdf', '.docx', '.doc', '.dotx', '.rtf', '.odt', '.pages', '.txt', '.html', '.htm', '.md')


def _raizes_drive():
    import glob
    home = os.path.expanduser('~')
    raizes = []
    for base in sorted(glob.glob(os.path.join(home, 'Library', 'CloudStorage', 'GoogleDrive-*'))):
        conta = os.path.basename(base).replace('GoogleDrive-', '')
        subs = [s for s in ('Meu Drive', 'My Drive', 'Drives compartilhados', 'Shared drives', 'Outros computadores')
                if os.path.isdir(os.path.join(base, s))]
        if subs:
            for s in subs:
                raizes.append({'nome': f'{s} ({conta})', 'caminho': os.path.join(base, s)})
        else:
            raizes.append({'nome': conta, 'caminho': base})
    for leg in (os.path.join(home, 'Google Drive'), os.path.join(home, 'Meu Drive'), '/Volumes/GoogleDrive/Meu Drive',
                '/Volumes/GoogleDrive/My Drive', 'G:\\Meu Drive', 'G:\\My Drive'):
        if os.path.isdir(leg):
            raizes.append({'nome': os.path.basename(leg), 'caminho': leg})
    return raizes


def _dentro_do_drive(caminho):
    real = os.path.realpath(caminho)
    return any(real == os.path.realpath(r['caminho']) or real.startswith(os.path.realpath(r['caminho']) + os.sep)
               for r in _raizes_drive())


@app.route('/api/drive/raizes')
def api_drive_raizes():
    return ok(raizes=_raizes_drive())


@app.route('/api/drive/listar')
def api_drive_listar():
    cam = request.args.get('caminho') or ''
    if not cam or not _dentro_do_drive(cam) or not os.path.isdir(cam):
        return erro('Pasta do Google Drive não encontrada')
    itens = []
    try:
        nomes = os.listdir(cam)
    except PermissionError:
        return erro('O Mac não deixou o programa ler esta pasta. Em Ajustes do Sistema › Privacidade e Segurança › '
                    'Arquivos e Pastas, permita o acesso ao Google Drive.', 403)
    for n in sorted(nomes, key=lambda x: x.lower()):
        if n.startswith('.') or n.startswith('~$') or n in ('Icon\r',):
            continue
        p = os.path.join(cam, n)
        if os.path.isdir(p):
            itens.append({'nome': n, 'caminho': p, 'pasta': True})
        else:
            ext = os.path.splitext(n)[1].lower()
            google = ext in ('.gdoc', '.gsheet', '.gslides')
            if ext in EXT_IMPORTAVEIS or google:
                try:
                    st = os.stat(p); tam = st.st_size; mod = datetime.datetime.fromtimestamp(st.st_mtime).strftime('%d/%m/%Y')
                except OSError:
                    tam, mod = 0, ''
                itens.append({'nome': n, 'caminho': p, 'pasta': False, 'tamanho': tam, 'modificado': mod, 'google': google})
    return ok(caminho=cam, itens=itens)


@app.route('/api/drive/importar', methods=['POST'])
def api_drive_importar():
    cam = (request.get_json(force=True) or {}).get('caminho') or ''
    if not _dentro_do_drive(cam) or not os.path.isfile(cam):
        return erro('Arquivo do Google Drive não encontrado')
    if cam.lower().endswith(('.gdoc', '.gsheet', '.gslides')):
        return erro('Este é um arquivo nativo do Google Docs. Abra no Drive e use Arquivo › Fazer download › PDF ou Word, '
                    'e importe o arquivo baixado.')
    with open(cam, 'rb') as f:
        conteudo = f.read()
    return ok(sugestao=_analisar_arquivo(os.path.basename(cam), conteudo))


@app.route('/api/importar/<token>/p/<int:n>.png')
def api_importar_pagina(token, n):
    item = _importados.get(token)
    if not item or len(item) < 3 or n >= len(item[2]):
        abort(404)
    return send_file(io.BytesIO(item[2][n]), mimetype='image/png')


@app.route('/api/importar/salvar-paginas', methods=['POST'])
def api_importar_salvar_paginas():
    d = request.get_json(force=True)
    item = _importados.get(d.get('token'))
    if not item or len(item) < 3:
        return erro('A importação expirou. Importe o arquivo de novo.')
    nome_arq, conteudo, imagens = item
    tamanhos = d.get('tamanhos') or []
    original = B.guardar_original(nome_arq, conteudo)
    salvos = []
    for doc in d.get('documentos') or []:
        globais = doc.get('paginas') or []
        mapa = {g: i for i, g in enumerate(globais)}
        caixas = []
        for c in doc.get('caixas') or []:
            if c.get('pagina') in mapa:
                c = dict(c); c['pagina'] = mapa[c['pagina']]; caixas.append(c)
        meta = {k: doc.get(k) for k in ('nome', 'categoria', 'area', 'descricao', 'campos', 'genero', 'valores_maiusculos')}
        palavras = d.get('palavras') or []
        meta.update(tipo='modelo', formato='paginas', timbrado='nenhum', caixas=caixas, paginas=[],
                    palavras=[palavras[g] if g < len(palavras) else [] for g in globais],
                    origem=nome_arq, original_guardado=original, tags=['pdf original'], versao_cobertura=1)
        m = B.salvar_modelo(meta, '')
        meta = {k: v for k, v in m.items() if not k.startswith('_') and k != 'html'}
        meta['paginas'] = B.salvar_paginas_modelo(m['id'], [(imagens[g], tuple(tamanhos[g]) if g < len(tamanhos) else (595.3, 841.9)) for g in globais])
        m = B.salvar_modelo(meta, '')
        salvos.append(m)
    kit = d.get('kit') or {}
    resultado = salvos[0] if salvos else None
    if kit.get('criar') and len(salvos) > 1:
        resultado = B.salvar_modelo({'nome': kit.get('nome') or 'Kit', 'categoria': kit.get('categoria') or 'Kits de Atendimento',
                                     'tipo': 'kit', 'area': salvos[0].get('area', ''), 'timbrado': 'nenhum', 'campos': [],
                                     'itens': [{'modelo': m['id']} for m in salvos], 'origem': nome_arq,
                                     'descricao': 'Kit importado de PDF: ' + ', '.join(m['nome'] for m in salvos) + '.'}, None)
    _importados.pop(d.get('token'), None)
    return ok(modelo=resultado, salvos=[m['id'] for m in salvos])


@app.route('/api/importar/salvar', methods=['POST'])
def api_importar_salvar():
    d = request.get_json(force=True)
    token = d.pop('token', None)
    timb = d.pop('timbrado_novo', None)
    html = d.pop('html', '')
    for k in ('avisos', 'categorias', 'timbrado_detectado', 'usou_ia', 'arquivo'):
        d.pop(k, None)
    if token and token in _importados:
        nome, conteudo = _importados.pop(token)
        d['origem'] = nome
        d['original_guardado'] = B.guardar_original(nome, conteudo)
        if timb and timb.get('criar'):
            img, margens = T.importar('x.docx', conteudo, sem_texto_cabecalho=bool(d.get('cabecalho')))
            t = B.criar_timbrado(timb.get('nome') or ('Timbrado de ' + d.get('nome', '')), T.png_bytes(img),
                                 timb.get('margens') or margens, origem=nome)
            d['timbrado'] = t['id']
    m = B.salvar_modelo(d, html)
    return ok(modelo=m)


# ------------------------------------------------------------------ timbrados
@app.route('/api/timbrados', methods=['POST'])
def api_timbrado_novo():
    f = request.files.get('arquivo')
    if not f:
        return erro('Nenhum arquivo enviado')
    conteudo = f.read()
    img, margens = T.importar(f.filename, conteudo)
    nome = request.form.get('nome') or I.titulo_bonito(I.limpar_nome_arquivo(f.filename))
    t = B.criar_timbrado(nome, T.png_bytes(img), margens, origem=f.filename)
    B.guardar_original(f.filename, conteudo)
    return ok(timbrado=t)


@app.route('/api/timbrado/<tid>', methods=['POST'])
def api_timbrado_salvar(tid):
    return ok(timbrado=B.salvar_timbrado(tid, request.get_json(force=True)))


@app.route('/api/timbrado/<tid>', methods=['DELETE'])
def api_timbrado_excluir(tid):
    return ok(excluido=B.excluir_timbrado(tid))


# ------------------------------------------------------------------ clientes e config
@app.route('/api/clientes')
def api_clientes():
    return ok(clientes=B.listar_clientes())


@app.route('/api/clientes', methods=['POST'])
def api_cliente_salvar():
    d = request.get_json(force=True)
    if not (d.get('nome') or '').strip():
        return erro('Informe o nome do cliente')
    return ok(cliente=B.salvar_cliente(d['nome'].strip(), d.get('dados') or {}, d.get('id'), d.get('doc')))


@app.route('/api/clientes/<cid>/doc', methods=['DELETE'])
def api_cliente_doc_excluir(cid):
    B.excluir_doc_cliente(cid, request.args.get('modelo') or ''); return ok()


@app.route('/api/clientes/<cid>', methods=['DELETE'])
def api_cliente_excluir(cid):
    B.excluir_cliente(cid); return ok()


@app.route('/api/versao')
def api_versao():
    if request.args.get('checar') == '1':
        return ok(**UPD.verificar(VERSAO))
    notas = []
    try:
        with open(os.path.join(UPD.PROGRAMA, 'app', 'NOVIDADES.json'), encoding='utf-8') as f:
            notas = json.load(f).get('notas') or []
    except Exception:
        pass
    return ok(atual=VERSAO, reiniciou=os.environ.get('KP_REINICIO') == '1', notas=notas)


@app.route('/api/atualizar', methods=['POST'])
def api_atualizar():
    try:
        r = UPD.aplicar(VERSAO)
    except Exception as e:
        return jsonify(ok=False, erro=str(e)), 500
    if r.get('nada'):
        return ok(nada=True, versao=VERSAO)
    UPD.reiniciar(PORTA_ATUAL[0])
    return ok(versao=r['versao'], notas=r.get('notas') or [])


@app.route('/api/config', methods=['GET', 'POST'])
def api_config():
    if request.method == 'POST':
        d = request.get_json(force=True)
        if d.get('gemini_chave') == '********':
            d.pop('gemini_chave')
        B.salvar_config(d)
    c = B.config()
    c['gemini_chave'] = '********' if c.get('gemini_chave') else ''
    return ok(config=c, pasta=B.DADOS, chrome=bool(PX.achar_navegador()))


@app.route('/api/ler-documentos', methods=['POST'])
def api_ler_documentos():
    arqs = [(f.filename or 'arquivo', f.read()) for f in request.files.getlist('arquivos')]
    arqs = [a for a in arqs if a[1]]
    if not arqs:
        return erro('Nenhum arquivo enviado')
    try:
        return ok(**OCR.ler(arqs, B.config()))
    except ValueError as e:
        return erro(str(e))
    except Exception as e:
        return erro(f'Não consegui ler os documentos: {e}')


@app.route('/api/celular/novo', methods=['POST'])
def api_celular_novo():
    try:
        tok, url = CEL.nova_sessao()
    except Exception as e:
        return erro(str(e))
    return ok(token=tok, url=url)


@app.route('/api/celular/<tok>/estado')
def api_celular_estado(tok):
    e = CEL.estado(tok)
    return ok(**e) if e else erro('O código expirou. Gere um novo.', 404)


@app.route('/api/celular/<tok>/ler', methods=['POST'])
def api_celular_ler(tok):
    arqs = CEL.retirar(tok)
    if not arqs:
        return erro('Nenhuma foto chegou do celular.')
    try:
        return ok(**OCR.ler(arqs, B.config()))
    except ValueError as e:
        return erro(str(e))
    except Exception as e:
        return erro(f'Não consegui ler os documentos: {e}')


@app.route('/api/testar-ia', methods=['POST'])
def api_testar_ia():
    c = B.config()
    if not c.get('gemini_chave'):
        return erro('Nenhuma chave cadastrada')
    try:
        r = I.gemini('Responda só {"ok": true} em JSON.', c['gemini_chave'], c.get('gemini_modelo'), timeout=30)
        return ok(resposta=r)
    except Exception as e:
        return erro(f'Falhou: {e}')


# ------------------------------------------------------------------ exportação
def _pasta_downloads():
    d = os.path.join(os.path.expanduser('~'), 'Downloads')
    return d if os.path.isdir(d) else B.P_GERADOS


def _salvar_saida(nome, dados, cliente=None, subpasta=None, subpasta_copia=None):
    nome = B.nome_seguro(nome)
    copia = B.guardar_gerado(nome, dados, cliente, subpasta_copia or subpasta)
    base, ext = os.path.splitext(nome)
    pasta = _pasta_downloads()
    if subpasta:
        pasta = os.path.join(pasta, B.nome_seguro(subpasta)[:90].strip(' .'))
        os.makedirs(pasta, exist_ok=True)
    destino = os.path.join(pasta, nome); n = 2
    while os.path.exists(destino):
        destino = os.path.join(pasta, f'{base} ({n}){ext}'); n += 1
    with open(destino, 'wb') as f:
        f.write(dados)
    return destino, copia


@app.route('/api/exportar/docx', methods=['POST'])
def api_docx():
    d = request.get_json(force=True)
    itens = d.get('itens') or []
    for it in itens:
        t = B.obter_timbrado(it.get('timbrado')) if it.get('timbrado') not in (None, '', 'nenhum') else None
        if not it.get('margens'):
            it['margens'] = t['margens'] if t else {'sup': 2.5, 'inf': 2.5, 'esq': 2.5, 'dir': 2.5}
    dados = DX.gerar_docx(itens)
    nome = (d.get('nome') or 'Documento') + '.docx'
    if d.get('baixar_direto'):
        return send_file(io.BytesIO(dados), as_attachment=True, download_name=nome,
                         mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    destino, copia = _salvar_saida(nome, dados, d.get('cliente'))
    return ok(caminho=destino, copia=copia, nome=os.path.basename(destino),
              copia_pasta=os.path.relpath(os.path.dirname(copia), B.P_GERADOS) if copia else '')


def _html_impressao(paginas_html):
    css = open(os.path.join(STATIC, 'documento.css'), encoding='utf-8').read()
    pasta_fontes = 'file:///' + os.path.join(STATIC, 'fonts').replace(os.sep, '/').lstrip('/') + '/'
    css = css.replace('url("fonts/', 'url("' + pasta_fontes)

    def troca(m):
        src = m.group(2)
        cam = DX.resolver_imagem(src)
        if isinstance(cam, str):
            return f'{m.group(1)}file:///{cam.replace(os.sep, "/").lstrip("/")}"'
        return m.group(0)
    paginas_html = re.sub(r'(src=")([^"]+)"', troca, paginas_html)
    return ('<!doctype html><html><head><meta charset="utf-8"><style>' + css +
            '*{box-sizing:border-box}'   # igual à tela: senão as larguras mudam e o texto do PDF ocupa mais linhas que a prévia
            'html,body{margin:0;padding:0;background:#fff}.pagina{page-break-after:always}'
            '.pagina:last-child{page-break-after:auto}</style></head><body>' + paginas_html + '</body></html>')


@app.route('/api/exportar/pdf', methods=['POST'])
def api_pdf():
    d = request.get_json(force=True)
    pdf = PX.gerar_pdf(_html_impressao(d.get('paginas') or ''))
    if not pdf:
        return erro('Não encontrei o Google Chrome (ou Edge) para gerar o PDF. '
                    'Use o botão Imprimir e escolha "Salvar como PDF".', 409)
    nome = (d.get('nome') or 'Documento') + '.pdf'
    destino, copia = _salvar_saida(nome, pdf, d.get('cliente'))
    if d.get('imprimir'):
        _abrir(destino, imprimir=True)
    return ok(caminho=destino, copia=copia, nome=os.path.basename(destino),
              copia_pasta=os.path.relpath(os.path.dirname(copia), B.P_GERADOS) if copia else '')


@app.route('/api/exportar/pdf-separados', methods=['POST'])
def api_pdf_separados():
    """Um PDF por documento do kit, numa pasta própria (Downloads/<kit - cliente>/)."""
    d = request.get_json(force=True)
    docs = d.get('docs') or []
    if not docs:
        return erro('Nenhum documento marcado')
    pasta_nome = d.get('pasta') or 'Documentos'
    salvos = []
    for i, doc in enumerate(docs, 1):
        pdf = PX.gerar_pdf(_html_impressao(doc.get('paginas') or ''))
        if not pdf:
            return erro('Não encontrei o Google Chrome (ou Edge) para gerar o PDF.', 409)
        nome = f'{i:02d} - ' + (doc.get('nome') or 'Documento') + '.pdf'
        destino, _ = _salvar_saida(nome, pdf, d.get('cliente'), pasta_nome, d.get('pasta_copia'))
        salvos.append(os.path.basename(destino))
    pasta = os.path.dirname(destino)
    return ok(pasta=pasta, arquivos=salvos, caminho=pasta)


@app.route('/api/cep/<cep>')
def api_cep(cep):
    """Busca o endereço pelo CEP (ViaCEP)."""
    dig = re.sub(r'\D', '', cep)
    if len(dig) != 8:
        return erro('CEP inválido')
    try:
        import urllib.request
        req = urllib.request.Request(f'https://viacep.com.br/ws/{dig}/json/', headers={'User-Agent': 'KitPronto'})
        with urllib.request.urlopen(req, timeout=8, context=I._ssl_ctx()) as r:
            j = json.loads(r.read().decode())
    except Exception:
        return erro('Não consegui consultar o CEP agora (sem internet?).', 503)
    if j.get('erro'):
        return erro('CEP não encontrado', 404)
    return ok(logradouro=j.get('logradouro', ''), complemento=j.get('complemento', ''), bairro=j.get('bairro', ''),
              cidade=j.get('localidade', ''), uf=j.get('uf', ''))


def _abrir(caminho, revelar=False, imprimir=False):
    so = platform.system()
    if so == 'Darwin':
        if revelar:
            subprocess.Popen(['open', '-R', caminho])
        elif imprimir:
            # Pré-Visualização abre o PDF já com a janela de impressão (impressora, cópias, páginas).
            # Na 1ª vez o macOS pergunta se o Kit Pronto pode controlar o Pré-Visualização: é só Permitir.
            def cmdp():
                esc_ = caminho.replace('\\', '\\\\').replace('"', '\\"')
                r = subprocess.run(['osascript',
                                    '-e', 'tell application "Preview"',
                                    '-e', 'activate',
                                    '-e', f'set d to open POSIX file "{esc_}"',
                                    '-e', 'delay 0.6',
                                    '-e', 'print d with print dialog',
                                    '-e', 'end tell'],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=60)
                if r.returncode != 0:   # sem permissão de automação: ao menos abre o PDF
                    subprocess.Popen(['open', '-a', 'Preview', caminho])
            threading.Thread(target=cmdp, daemon=True).start()
        else:
            subprocess.Popen(['open', caminho])
    elif so == 'Windows':
        if revelar:
            subprocess.Popen(['explorer', '/select,', caminho])
        else:
            try:
                os.startfile(caminho, 'print' if imprimir else 'open')  # noqa
            except OSError:   # leitor de PDF sem a opção "imprimir" (ex.: Edge): abre para o Ctrl+P
                os.startfile(caminho)  # noqa
    else:
        subprocess.Popen(['xdg-open', os.path.dirname(caminho) if revelar else caminho])


@app.route('/api/abrir', methods=['POST'])
def api_abrir():
    d = request.get_json(force=True)
    alvo = d.get('caminho') or ''
    pastas = {'biblioteca': B.DADOS, 'modelos': B.P_MODELOS, 'timbrados': B.P_TIMBRADOS, 'gerados': B.P_GERADOS,
              'originais': B.P_ORIGINAIS, 'lixeira': B.P_LIXEIRA}
    if d.get('pasta') in pastas:
        alvo = pastas[d['pasta']]
    elif d.get('categoria'):
        alvo = os.path.join(B.P_MODELOS, d['categoria'])
    real = os.path.realpath(alvo)
    permitidos = [os.path.realpath(B.DADOS), os.path.realpath(_pasta_downloads())]
    if not any(real == p or real.startswith(p + os.sep) for p in permitidos) or not os.path.exists(real):
        return erro('Caminho inválido')
    _abrir(real, revelar=bool(d.get('revelar')))
    return ok()


# ------------------------------------------------------------------ início
PORTA_ATUAL = [0]


def porta_livre(pref=5077):
    import socket
    for p in range(pref, pref + 30):
        with socket.socket() as s:
            try:
                s.bind(('127.0.0.1', p)); return p
            except OSError:
                continue
    return pref


def _icone_mac():
    """No Mac: mostra o logo do programa no Dock e o nome no menu (em vez do foguete do Python)."""
    if platform.system() != 'Darwin':
        return
    try:
        from Foundation import NSBundle
        info = NSBundle.mainBundle().localizedInfoDictionary() or NSBundle.mainBundle().infoDictionary()
        if info is not None:
            info['CFBundleName'] = 'Kit Pronto'
    except Exception:
        pass
    try:
        from AppKit import NSApplication, NSImage
        img = NSImage.alloc().initWithContentsOfFile_(os.path.join(STATIC, 'logo-1024.png'))
        if img is not None:
            NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception:
        pass


def _biblioteca_inicial():
    """Pacote do Windows: na primeira vez, copia os modelos, kits e timbrados que vieram junto com o programa."""
    ini = os.path.join(B.RAIZ_PROGRAMA, 'biblioteca-inicial')
    if os.path.isdir(ini) and not os.path.isdir(B.P_MODELOS):
        import shutil
        shutil.copytree(ini, B.DADOS, dirs_exist_ok=True)


def _anotar_instalacao():
    """Windows: guarda onde o programa está, para o "Atualizar.bat" achar a pasta sozinho."""
    if os.name != 'nt':
        return
    try:
        d = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'KitPronto')
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, 'instalado-em.txt'), 'w', encoding='utf-8') as f:
            f.write(os.path.dirname(B.RAIZ_PROGRAMA))
        with open(os.path.join(d, 'versao.txt'), 'w', encoding='utf-8') as f:
            f.write(VERSAO)
    except Exception:
        pass


def _desbloquear_windows():
    """Arquivos extraídos de um ZIP baixado vêm marcados como 'da internet' (Zone.Identifier) e o
    Windows/.NET se recusa a carregar as DLLs da janela própria — aí o programa cai no navegador.
    Tira essa marca dos arquivos do programa (uma vez por versão)."""
    if platform.system() != 'Windows':
        return
    try:
        base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # ...\sistema
        marca = os.path.join(os.environ.get('LOCALAPPDATA') or base, 'KitPronto', 'desbloqueado.txt')
        chave = base + '|' + VERSAO
        if os.path.exists(marca) and open(marca, encoding='utf-8').read() == chave:
            return
        for raiz, _ds, fs in os.walk(base):
            for f in fs:
                try:
                    os.remove(os.path.join(raiz, f) + ':Zone.Identifier')
                except OSError:
                    pass
        os.makedirs(os.path.dirname(marca), exist_ok=True)
        with open(marca, 'w', encoding='utf-8') as fh:
            fh.write(chave)
    except Exception as e:
        print('  (não consegui desbloquear os arquivos:', e, ')')


def _atalho_windows():
    """Cria/atualiza o atalho 'Kit Pronto' no menu Iniciar e na Área de Trabalho, apontando direto
    para o programa (sem .bat) — é esse atalho que se fixa na barra de tarefas. Uma vez por versão."""
    if platform.system() != 'Windows':
        return
    try:
        base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # ...\sistema
        pyw = os.path.join(base, 'python', 'pythonw.exe')
        if not os.path.isfile(pyw):
            pyw = sys.executable.replace('python.exe', 'pythonw.exe')
        appdir = os.path.dirname(os.path.abspath(__file__))
        marca = os.path.join(os.environ.get('LOCALAPPDATA') or base, 'KitPronto', 'atalho.txt')
        chave = pyw + '|' + VERSAO
        if os.path.exists(marca) and open(marca, encoding='utf-8').read() == chave:
            return
        q = lambda s: "'" + s.replace("'", "''") + "'"
        args_ = '-X utf8 "' + os.path.join(appdir, 'app.py') + '"'
        ps = ("$ws=New-Object -ComObject WScript.Shell;"
              "foreach($p in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){"
              "if(-not $p){continue};try{"
              "$l=$ws.CreateShortcut((Join-Path $p 'Kit Pronto.lnk'));"
              f"$l.TargetPath={q(pyw)};"
              f"$l.Arguments={q(args_)};"
              f"$l.WorkingDirectory={q(appdir)};"
              f"$l.IconLocation={q(os.path.join(appdir, 'static', 'logo.ico') + ',0')};"
              "$l.Description='Kit Pronto';$l.Save()}catch{}}")
        subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps],
                       timeout=30, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        os.makedirs(os.path.dirname(marca), exist_ok=True)
        with open(marca, 'w', encoding='utf-8') as fh:
            fh.write(chave)
    except Exception as e:
        print('  (não consegui criar o atalho:', e, ')')


def _abrir_como_janela(url):
    """Plano B no Windows: abre o Edge/Chrome em 'modo aplicativo' (sem barra de endereço e abas),
    para parecer a janela do programa mesmo quando a janela própria não carrega."""
    if platform.system() != 'Windows':
        return False
    try:
        nav = PX.achar_navegador()
        if not nav:
            return False
        perfil = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'KitPronto', 'janela')
        os.makedirs(perfil, exist_ok=True)
        subprocess.Popen([nav, f'--app={url}', f'--user-data-dir={perfil}', '--window-size=1500,940',
                          '--no-first-run', '--no-default-browser-check'],
                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return True
    except Exception as e:
        print('  (não abriu em modo aplicativo:', e, ')')
        return False


def main():
    _desbloquear_windows()
    threading.Thread(target=_atalho_windows, daemon=True).start()
    _anotar_instalacao()
    _biblioteca_inicial()
    B.iniciar()
    porta = int(os.environ.get('BANCO_MODELOS_PORTA') or porta_livre())
    if os.environ.get('KP_REINICIO') == '1':   # reiniciando após atualizar: espera a porta liberar
        import socket
        for _ in range(40):
            with socket.socket() as s_:
                try:
                    s_.bind(('127.0.0.1', porta)); break
                except OSError:
                    time.sleep(0.25)
    PORTA_ATUAL[0] = porta
    url = f'http://127.0.0.1:{porta}/'
    srv = threading.Thread(target=lambda: app.run(host='127.0.0.1', port=porta, threaded=True, use_reloader=False),
                           daemon=True)
    srv.start()
    time.sleep(0.8)
    print(f'\n  Kit Pronto rodando em {url}\n  Biblioteca: {B.DADOS}\n')
    usar_janela = os.environ.get('BANCO_MODELOS_NAVEGADOR') != '1'
    if os.environ.get('KP_REINICIO') == '1' and os.environ.get('KP_ERA_NAVEGADOR') == '1':
        # já existe uma aba/janela do navegador aberta: ela se recarrega sozinha
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            return
    if usar_janela:
        try:
            import webview  # pywebview
            os.environ['BANCO_MODELOS_JANELA'] = '1'
            webview.create_window('Kit Pronto', url, width=1500, height=940, min_size=(1100, 700), js_api=_ApiJanela())
            _icone_mac()
            webview.start()
            return
        except Exception as e:
            print('  (janela própria indisponível, abrindo no navegador:', e, ')')
    os.environ['KP_ERA_NAVEGADOR'] = '1'
    os.environ.pop('BANCO_MODELOS_JANELA', None)
    if not _abrir_como_janela(url):
        webbrowser.open(url)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
