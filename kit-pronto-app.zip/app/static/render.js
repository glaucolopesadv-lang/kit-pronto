/* =====================================================================
   Motor do documento: formatação dos campos, valor por extenso,
   gênero (o/a), montagem das páginas A4 com o timbrado.
   ===================================================================== */
(function (G) {
  'use strict';
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const SEMANA = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];

  // ------------------------------------------------------------ extenso
  const UN = ['zero', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze',
    'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
  const DZ = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
  const CT = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
  function ate999(n, fem) {
    if (n === 100) return 'cem';
    const c = Math.floor(n / 100), r = n % 100, p = [];
    let ct = CT[c];
    if (fem && c >= 2) ct = ct.replace(/os$/, 'as');
    if (c) p.push(ct);
    if (r) {
      const un = (x) => fem && (x === 1 || x === 2) ? (x === 1 ? 'uma' : 'duas') : UN[x];
      if (r < 20) p.push(un(r));
      else { const d = Math.floor(r / 10), u = r % 10; p.push(u ? DZ[d] + ' e ' + un(u) : DZ[d]); }
    }
    return p.join(' e ');
  }
  function extensoInteiro(n, fem) {
    n = Math.floor(Math.abs(n));
    if (n === 0) return 'zero';
    const esc = [['', ''], ['mil', 'mil'], ['milhão', 'milhões'], ['bilhão', 'bilhões'], ['trilhão', 'trilhões']];
    const g = [];
    while (n > 0) { g.push(n % 1000); n = Math.floor(n / 1000); }
    const partes = [];
    for (let i = g.length - 1; i >= 0; i--) {
      if (!g[i]) continue;
      let t;
      if (i === 1 && g[i] === 1) t = 'mil';
      else { t = ate999(g[i], fem && i < 2); if (i > 0) t += ' ' + (g[i] === 1 ? esc[i][0] : esc[i][1]); }
      partes.push({ t, v: g[i] });
    }
    return partes.map((p, k) => {
      if (k === 0) return p.t;
      const ultimo = k === partes.length - 1;
      return (ultimo && (p.v < 100 || p.v % 100 === 0) ? ' e ' : ' ') + p.t;
    }).join('');
  }
  function extensoReais(v) {
    if (v === null || isNaN(v)) return '';
    const neg = v < 0; v = Math.abs(v);
    let inteiro = Math.floor(v + 1e-9);
    let cent = Math.round((v - inteiro) * 100);
    if (cent === 100) { inteiro += 1; cent = 0; }
    const out = [];
    if (inteiro > 0) {
      let t = extensoInteiro(inteiro);
      const redondo = inteiro >= 1000000 && inteiro % 1000000 === 0;
      t += redondo ? ' de reais' : (inteiro === 1 ? ' real' : ' reais');
      out.push(t);
    }
    if (cent > 0) out.push(extensoInteiro(cent) + (cent === 1 ? ' centavo' : ' centavos'));
    if (!out.length) return 'zero real';
    return (neg ? 'menos ' : '') + out.join(' e ');
  }

  // ------------------------------------------------------------ números e datas
  function numBR(txt) {
    if (txt === null || txt === undefined) return null;
    let s = String(txt).replace(/[R$\s]/g, '');
    if (!s) return null;
    if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
    else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
    const n = parseFloat(s);
    return isNaN(n) ? null : n;
  }
  function moeda(n) {
    return n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function hojeISO() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function lerData(v) {
    if (!v) return null;
    if (v === 'hoje') v = hojeISO();
    let m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(v);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    return null;
  }
  const dd = (n) => String(n).padStart(2, '0');

  // ------------------------------------------------------------ formatação de um campo
  const VAZIO = {
    cpf: '___.___.___-__', cnpj: '__.___.___/____-__', cep: '_____-___', uf: '____', telefone: '(___) _____-_____',
    moeda: 'R$ ____________', numero: '_____', caixa: '  ', data: '____ de _______________ de ______',
    'data|curta': '____/____/______', 'data|dia': '____', 'data|mes': '_______________', 'data|ano': '______',
    'data|semana': '____________, ____ de _______________ de ______', email: '______________________________',
  };
  function vazioPara(tipo, filtro) {
    return VAZIO[tipo + '|' + filtro] || VAZIO[tipo] || '______________________________';
  }
  // kit "em branco" para preencher à mão: linhas mais compridas, do tamanho do dado
  const VAZIO_B = {
    cpf: '_____._____._____-____', cnpj: '___.______.______/______-____', cep: '_______-_____', uf: '_____',
    telefone: '(_____) _______-_______', moeda: 'R$ ________________', 'moeda|extenso': '________________________________________', 'moeda|valor': '________________', numero: '________', caixa: '  ',
    data: '_____ de __________________ de ________', 'data|curta': '_____/_____/________', 'data|dia': '_____',
    'data|mes': '__________________', 'data|ano': '________', 'data|semana': '_____ de __________________ de ________',
    'data|extenso': '_____ de __________________ de ________', email: '___________________________________',
  };
  const L = (n) => '_'.repeat(n);
  // rótulo pequeno antes da linha quando o próprio texto não diz o que escrever ali ("____, ____," → "nacionalidade ____")
  const ROT_B = [[/_nome$/, 'nome', /nome|outorgante:|testemunha|representad/], [/nacionalidade$/, 'nacionalidade', /nacionalidade/],
    [/estado_civil$/, 'estado civil', /civil/], [/profissao$/, 'profissão', /profiss/], [/_bairro$/, 'bairro', /bairro/],
    [/_cidade$/, 'cidade', /cidade|munic/], [/_endereco$/, 'endereço', /endere|domiciliad|residente/],
    [/_rg$/, 'RG', /\brg\b|identidade/], [/_cpf$/, 'CPF', /cpf/], [/_cep$/, 'CEP', /cep/], [/_relacao$/, 'parentesco', /qualidade|relac/]];
  function rotuloBranco(chave, antes) {
    return '';   // decisão do Glauco: nada de palavrinha antes da linha no papel impresso — só a linha
    const r = ROT_B.find(([re]) => re.test(chave));
    if (!r) return '';
    const txt = antes.replace(/<[^>]*>/g, ' ').replace(/\{\{[^}]*\}\}/g, ' ').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const perto = txt.slice(-38);
    return r[2].test(perto) ? '' : r[1];
  }
  function vazioBranco(campo, filtro) {
    const tipo = (campo && campo.tipo) || 'texto', k = (campo && campo.chave) || '';
    if (VAZIO_B[tipo + '|' + filtro]) return VAZIO_B[tipo + '|' + filtro];
    if (VAZIO_B[tipo]) return VAZIO_B[tipo];
    if (/nome$|endereco/.test(k)) return L(50);
    if (/nacionalidade/.test(k)) return L(18);
    if (/(^|_)rg$/.test(k)) return L(22);
    if (/bairro|cidade|profissao|estado_civil|relacao|referencia|naturalidade/.test(k)) return L(28);
    if (tipo === 'texto_longo') return L(60) + '\n' + L(60);
    return L(30);
  }

  // ---- campos de cálculo (como as fórmulas da planilha): "qtd_almoco * valor_almoco", "sub_a + sub_b"
  function calcular(campo, valores, mapa, opts, prof) {
    if ((prof || 0) > 8) return null;
    let algum = false, faltou = false;
    const expr = String(campo.formula || '').replace(/[A-Za-z_][A-Za-z0-9_]*/g, (k) => {
      const c = mapa[k];
      if (!c && !(k in valores)) return '0';
      let n = null;
      if (c && c.tipo === 'calculo') n = calcular(c, valores, mapa, opts, (prof || 0) + 1);
      else {
        const v = valores[k] !== undefined ? valores[k] : (opts && opts.branco ? undefined : c && c.padrao);
        if (v !== undefined && v !== null && String(v).trim() !== '') n = numBR(String(v));
      }
      if (n !== null) algum = true; else faltou = true;
      return '(' + (n === null ? 0 : n) + ')';
    });
    if (!/^[\d\s+\-*/().]*$/.test(expr)) return null;
    if (opts && opts.branco && (faltou || !algum)) return null;      // em branco: sem quantidade, o subtotal fica para escrever
    try { const r = Function('"use strict";return (' + (expr || '0') + ')')(); return isFinite(r) ? Math.round(r * 100) / 100 : null; } catch (e) { return null; }
  }

  function formatar(campo, valor, filtro) {
    const tipo = (campo && campo.tipo) || 'texto';
    filtro = (filtro || '').trim();
    if (tipo === 'caixa') return valor ? 'X' : '  ';
    if (valor === undefined || valor === null || String(valor).trim() === '') return null;
    let s = String(valor);
    if (tipo === 'moeda') {
      const n = numBR(s);
      if (n === null) return s;
      if (filtro === 'numero') return 'R$ ' + moeda(n);
      if (filtro === 'valor') return moeda(n);
      if (filtro === 'extenso') return extensoReais(n);
      return 'R$ ' + moeda(n) + ' (' + extensoReais(n) + ')';
    }
    if (tipo === 'data') {
      const d = lerData(s);
      if (!d) return s;
      const longa = d.getDate() + ' de ' + MESES[d.getMonth()] + ' de ' + d.getFullYear();
      switch (filtro) {
        case 'curta': return dd(d.getDate()) + '/' + dd(d.getMonth() + 1) + '/' + d.getFullYear();
        case 'semana': return SEMANA[d.getDay()] + ', ' + longa;
        case 'dia': return String(d.getDate());
        case 'mes': return MESES[d.getMonth()];
        case 'ano': return String(d.getFullYear());
        case 'extenso': return extensoInteiro(d.getDate()) + ' de ' + MESES[d.getMonth()] + ' de ' + extensoInteiro(d.getFullYear());
        default: return longa;
      }
    }
    if (tipo === 'numero') {
      const n = numBR(s);
      if (n !== null) {
        if (filtro === 'extenso') return extensoInteiro(n);
        if (filtro === 'extenso_f') return extensoInteiro(n, true);
        if (filtro === 'dois') return dd(Math.floor(n));
        if (filtro === 'com_extenso') return dd(Math.floor(n)) + ' (' + extensoInteiro(n) + ')';
      }
    }
    if (filtro === 'maiusculo') s = s.toLocaleUpperCase('pt-BR');
    else if (filtro === 'minusculo') s = s.toLocaleLowerCase('pt-BR');
    else if (filtro === 'titulo') s = s.toLocaleLowerCase('pt-BR').replace(/(^|\s)(\S)/g, (a, b, c) => b + c.toLocaleUpperCase('pt-BR'))
      .replace(/ (De|Da|Do|Das|Dos|E) /g, (a) => a.toLowerCase());
    return s;
  }

  // ------------------------------------------------------------ maiúsculas no padrão do português
  const PARTICULAS = new Set(['de', 'da', 'do', 'das', 'dos', 'e', 'em', 'na', 'no', 'nas', 'nos', 'a', 'o', 'as', 'os', 'à', 'ao', 'aos', 'às', 'com', 'para', 'por', 'sob', 'sobre', 'entre', 'y', 'del', 'van', 'von', 'di', 'du', 'des']);
  const SIGLAS_FIXAS = new Set(['RN', 'CE', 'PB', 'PE', 'SP', 'RJ', 'BR', 'CPF', 'RG', 'INSS', 'SSP', 'ME', 'LTDA', 'EPP', 'II', 'III', 'IV', 'VI', 'VII', 'VIII', 'IX', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XX', 'S/N', 'SN', 'CEP', 'BL', 'AP']);
  function tituloPt(t) {
    return String(t).split(/(\s+)/).map((p, i) => {
      if (/^\s+$/.test(p) || !p) return p;
      if (/\d/.test(p)) return p.toLocaleUpperCase('pt-BR');            // BR-304, 4222, 12B
      const limpo = p.replace(/[^\p{L}/]/gu, '').toLocaleUpperCase('pt-BR');
      if (SIGLAS_FIXAS.has(limpo) && i > 0) return p.toLocaleUpperCase('pt-BR');
      const min = p.toLocaleLowerCase('pt-BR');
      if (i > 0 && PARTICULAS.has(min.replace(/[^\p{L}]/gu, ''))) return min;
      return min.replace(/(^|[-'’(])(\p{L})/gu, (m, a, b) => a + b.toLocaleUpperCase('pt-BR'));
    }).join('');
  }
  // senhas e logins (Meu INSS, outros sistemas): saem exatamente como foram digitados, sem mudar maiúsculas/minúsculas
  const RE_EXATO = /(^|_)(senha|meu_inss|outros_sistemas|login)(_|$)/;
  function aplicarFormato(campo, s, opts) {
    if (campo.formato === 'exato' || RE_EXATO.test(campo.chave || '')) return s;
    if (opts && opts.maiusculas && campo.tipo !== 'email') return s.toLocaleUpperCase('pt-BR');
    if (!campo.formato || campo.tipo === 'email') return s;
    if (campo.formato === 'nome') return tituloPt(s);
    if (campo.formato === 'minusculo') return s.toLocaleLowerCase('pt-BR');
    if (campo.formato === 'maiusculo') return s.toLocaleUpperCase('pt-BR');
    return s;
  }

  const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // ------------------------------------------------------------ gênero: inscrito(a) -> inscrito / inscrita
  function aplicarGenero(html, genero) {
    const g = (genero || '').toLowerCase();
    if (!g) return html;
    const fem = g.startsWith('f');
    return html.split(/(<[^>]+>)/).map((parte) => {
      if (parte.startsWith('<')) return parte;
      return parte
        .replace(/(^|[^A-Za-zÀ-ú])([Aa])o\(([aA])\)/g, (m, pre, a) => pre + (fem ? (a === 'A' ? 'À' : 'à') : a + 'o'))
        .replace(/(^|[^A-Za-zÀ-ú])([A-Za-zÀ-ú]*)O\(a\)/g, (m, pre, r) => pre + r + (fem ? 'A' : 'O'))
        .replace(/(^|[^A-Za-zÀ-ú])([A-Za-zÀ-ú]*)O\(A\)/g, (m, pre, r) => pre + r + (fem ? 'A' : 'O'))
        .replace(/(^|[^A-Za-zÀ-ú])([A-Za-zÀ-ú]*)o\(a\)/g, (m, pre, r) => pre + r + (fem ? 'a' : 'o'))
        .replace(/(^|[^A-Za-zÀ-ú])([Aa])o\((à|À)\)/g, (m, pre, a, x) => pre + (fem ? (a === 'A' ? 'À' : 'à') : a + 'o'))
        .replace(/(^|[^A-Za-zÀ-ú])([A-Za-zÀ-ú]*)e\(a\)/g, (m, pre, r) => pre + r + (fem ? 'a' : 'e'))   // aquele(a) -> aquela
        .replace(/([A-Za-zÀ-ú]+)\(a\)/g, (m, r) => r + (fem ? 'a' : ''))
        .replace(/([A-Za-zÀ-ú]+)\(A\)/g, (m, r) => r + (fem ? 'A' : ''))
        .replace(/([A-Za-zÀ-ú]+)\(s\)/g, (m, r) => r);
    }).join('');
  }

  // ------------------------------------------------------------ render do modelo
  const RE_TOKEN = /\{\{\s*([^{}]+?)\s*\}\}/g;

  function render(template, campos, valores, opts) {
    opts = opts || {};
    const mapa = {};
    (campos || []).forEach((c) => { mapa[c.chave] = c; });
    const final = opts.modo === 'final';
    const tpl = String(template || '');
    let html = tpl.replace(RE_TOKEN, (m, expr, pos) => {
      if (expr === 'pagina') return '{{pagina}}';
      const [chave, filtro] = expr.split('|').map((s) => s.trim());
      const campo = mapa[chave] || { chave, tipo: 'texto', rotulo: chave };
      const bruto = valores[chave] !== undefined ? valores[chave] : (campo.tipo === 'data' && campo.padrao === 'hoje' && !opts.branco ? 'hoje' : undefined);
      let v;
      if (campo.tipo === 'calculo') {
        const n = calcular(campo, valores, mapa, opts);
        v = n === null ? null : (campo.formato === 'numero' ? String(n).replace('.', ',')
          : filtro === 'extenso' ? extensoReais(n) : filtro === 'valor' ? moeda(n) : 'R$ ' + moeda(n));
      } else v = formatar(campo, bruto, filtro);
      if (v !== null && campo.tipo !== 'caixa' && (!filtro || opts.maiusculas)) v = aplicarFormato(campo, v, opts);
      if (v === null && opts.branco) {
        const rot = rotuloBranco(chave, tpl.slice(Math.max(0, pos - 70), pos));
        const vb = vazioBranco(campo, filtro);
        // linha longa (nome, endereço) pode continuar na linha de baixo: assim o texto justificado não fica com buracos
        const longa = /^_{30,}$/.test(vb) ? ' br-longa' : '';
        const linha = `<span class="cp br${longa}" data-k="${esc(chave)}">${esc(vb).replace(/\n/g, '<br>')}</span>`;
        if (rot && longa) return `<span class="br-rot" style="font-size:6.5pt;color:#808080;white-space:nowrap">${esc(rot)}</span> ${linha}`;
        return rot ? `<span style="white-space:nowrap"><span class="br-rot" style="font-size:6.5pt;color:#808080">${esc(rot)} </span>${linha}</span>` : linha;
      }
      if (v === null) {
        if (final && opts.vazioNada) return '';
        if (final) return `<span class="cp" data-k="${esc(chave)}">${esc(vazioPara(campo.tipo, filtro))}</span>`;
        return `<span class="cp vz" data-k="${esc(chave)}">${esc(campo.rotulo || chave)}</span>`;
      }
      return `<span class="cp" data-k="${esc(chave)}">${esc(v).replace(/\n/g, '<br>')}</span>`;
    });
    // trechos com concordância própria (ex.: representante legal): <span data-genero="rep_genero">
    if (/data-genero=/.test(html)) {
      const t = document.createElement('template');
      t.innerHTML = html;
      t.content.querySelectorAll('[data-genero]').forEach((el) => {
        el.innerHTML = aplicarGenero(el.innerHTML, valores[el.getAttribute('data-genero')] || (opts.branco ? '' : 'Feminino'));
      });
      html = t.innerHTML;
    }
    if (opts.genero) html = aplicarGenero(html, valores[opts.genero]);
    // blocos condicionais: data-se="campo" (mostra se preenchido) / data-senao="campo"
    if (/data-se(nao)?=/.test(html)) {
      const t = document.createElement('template');
      t.innerHTML = html;
      t.content.querySelectorAll('[data-se],[data-senao]').forEach((el) => {
        const k = el.getAttribute('data-se') || el.getAttribute('data-senao');
        let tem = !!(valores[k] && String(valores[k]).trim());
        if (!tem && opts.branco) tem = !(opts.semRep && /^rep_/.test(k));   // em branco: mostra o rótulo com a linha para escrever
        if ((el.hasAttribute('data-se') && !tem) || (el.hasAttribute('data-senao') && tem)) el.remove();
      });
      html = t.innerHTML;
    }
    // data-branco="so": aparece só no papel em branco (ex.: o fecho da qualificação que vira linhas)
    if (!opts.branco && /data-branco="so"/.test(html)) {
      const t = document.createElement('template');
      t.innerHTML = html;
      t.content.querySelectorAll('[data-branco="so"]').forEach((el) => el.remove());
      html = t.innerHTML;
    }
    return html;
  }

  // ------------------------------------------------------------ fontes
  function pilhaFonte(f) {
    f = (f || 'Calibri').trim();
    const n = f.toLowerCase();
    if (n.includes('avenir')) return `"${f}", "Avenir Next", Avenir, "Nunito Sans", "Segoe UI", sans-serif`;
    if (n.includes('calibri') || n.includes('carlito')) return `Calibri, Carlito, "Segoe UI", "Helvetica Neue", Arial, sans-serif`;
    if (n.includes('helvetica') || n.includes('arial')) return `"${f}", Helvetica, Arial, sans-serif`;
    if (n.includes('times') || n.includes('georgia') || n.includes('garamond') || n.includes('book antiqua'))
      return `"${f}", "Times New Roman", Times, serif`;
    return `"${f}", "Helvetica Neue", Arial, sans-serif`;
  }

  // ------------------------------------------------------------ paginação
  const MM = 96 / 25.4;

  function criarPagina(item, numero) {
    const pg = document.createElement('div');
    pg.className = 'pagina' + (item.paisagem ? ' paisagem' : '');
    const m = item.margens || { sup: 2.5, inf: 2.5, esq: 2.5, dir: 2.5 };
    if (item.timbrado && item.timbrado !== 'nenhum') {
      const img = document.createElement('img');
      img.className = 'fundo'; img.alt = '';
      img.src = 'timbrado/' + item.timbrado + '/fundo.png' + (item.versaoFundo ? '?v=' + item.versaoFundo : '');
      pg.appendChild(img);
    }
    const estilo = `--fonte:${pilhaFonte(item.fonte)};--tam:${item.tamanho || 12}pt;--esp:${item.espacamento || 1.4};`;
    let rodapeH = 0;
    if (item.rodape) {
      const r = document.createElement('div');
      r.className = 'rodape-pag doc';
      r.setAttribute('style', estilo + `left:${m.esq * 10}mm;right:${m.dir * 10}mm;bottom:${m.inf * 10}mm;`);
      r.innerHTML = item.rodape.replace(/\{\{pagina\}\}/g, String(numero));
      pg.appendChild(r);
      pg._rodape = r;
    }
    if (item.cabecalho) {   // cabeçalho do Word: repete no alto de todas as páginas (dentro da margem de cima)
      const h = document.createElement('div');
      h.className = 'cabecalho-pag doc';
      const topo = item.cab_dist ? item.cab_dist / 72 * 25.4 : 12.5;
      h.setAttribute('style', estilo + `left:0;right:0;top:${topo}mm;`);   // recuos já vêm medidos da borda do papel
      h.innerHTML = item.cabecalho.replace(/\{\{pagina\}\}/g, String(numero));
      pg.appendChild(h);
      pg._cabecalho = h;
    }
    const c = document.createElement('div');
    c.className = 'conteudo doc';
    c.setAttribute('style', estilo + `top:${m.sup * 10}mm;left:${m.esq * 10}mm;right:${m.dir * 10}mm;`);
    pg.appendChild(c);
    pg._conteudo = c;
    pg._alturaUtil = ((item.paisagem ? 210 : 297) - (m.sup + m.inf) * 10) * MM;
    return pg;
  }

  function ajustarAltura(pg) {
    let h = pg._alturaUtil;
    if (pg._rodape) h -= pg._rodape.offsetHeight + 4 * MM;
    pg._conteudo.style.height = Math.max(h, 40) + 'px';
    pg._limite = Math.max(h, 40);
  }

  function cabe(pg) { return pg._conteudo.scrollHeight <= pg._limite + 0.5; }

  function nosDeBloco(html) {
    const t = document.createElement('template');
    t.innerHTML = html;
    const out = [];
    let solto = null;
    Array.from(t.content.childNodes).forEach((n) => {
      const bloco = n.nodeType === 1 && /^(P|DIV|TABLE|H[1-6]|UL|OL|HR|BLOCKQUOTE|SECTION)$/.test(n.tagName);
      if (bloco) { solto = null; out.push(n); return; }
      if (n.nodeType === 3 && !n.textContent.trim()) return;
      if (!solto) { solto = document.createElement('p'); out.push(solto); }
      solto.appendChild(n);
    });
    return out;
  }

  // divide um parágrafo em [cabeça, resto] por palavras
  function dividirTexto(el, k) {
    const a = el.cloneNode(true), b = el.cloneNode(true);
    let cont = 0;
    const percorrer = (raiz, manter) => {
      const walker = document.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      const nos = []; while (walker.nextNode()) nos.push(walker.currentNode);
      cont = 0;
      nos.forEach((n) => {
        const partes = n.textContent.split(/(\s+)/);
        let acum = '';
        partes.forEach((p) => {
          const ehPalavra = p && !/^\s+$/.test(p);
          const dentro = cont < k;
          if (manter === 'cabeca' ? dentro : !dentro) acum += p;
          if (ehPalavra) cont++;
        });
        n.textContent = acum;
      });
    };
    percorrer(a, 'cabeca');
    percorrer(b, 'resto');
    b.style.textIndent = '0';
    b.style.marginTop = '0';
    a.style.marginBottom = '0';
    return [a, b];
  }
  function contarPalavras(el) { return (el.textContent.match(/\S+/g) || []).length; }

  function paginarItem(item, destino) {
    const paginas = [];
    let pg;
    const nova = () => {
      pg = criarPagina(item, paginas.length + 1);
      destino.appendChild(pg);
      ajustarAltura(pg);
      if (item.folga) { pg._limite -= item.folga; pg._conteudo.style.height = pg._limite + 'px'; }   // margem de segurança (a impressão sai um pouco mais alta que a tela)
      paginas.push(pg);
    };
    nova();
    const fila = nosDeBloco(item.html);
    let guarda = 0;
    while (fila.length && guarda++ < 5000) {
      const no = fila.shift();
      if (no.nodeType === 1 && (no.classList.contains('quebra-pagina') || no.tagName === 'HR')) {
        if (pg._conteudo.childNodes.length) nova();
        continue;
      }
      pg._conteudo.appendChild(no);
      if (cabe(pg)) continue;
      pg._conteudo.removeChild(no);
      const vazia = !pg._conteudo.childNodes.length;
      // tabela: divide por linhas
      if (no.tagName === 'TABLE') {
        const linhas = Array.from(no.querySelectorAll(':scope > tbody > tr, :scope > tr'));
        if (linhas.length > 1) {
          const parte = no.cloneNode(false);
          const corpo = document.createElement('tbody');
          parte.appendChild(corpo);
          parte.style.marginBottom = '0';
          pg._conteudo.appendChild(parte);
          let movidas = 0;
          for (const tr of linhas) {
            corpo.appendChild(tr);
            if (!cabe(pg)) { corpo.removeChild(tr); break; }
            movidas++;
          }
          if (movidas === 0) {
            pg._conteudo.removeChild(parte);
            // devolve as linhas para a tabela original (senão a 1ª linha se perde ao ir para a próxima página)
            const tb = no.tBodies[0] || no;
            linhas.forEach((tr) => tb.appendChild(tr));
          } else {
            const resto = no.cloneNode(false);
            const rcorpo = document.createElement('tbody');
            linhas.slice(movidas).forEach((tr) => rcorpo.appendChild(tr));
            resto.appendChild(rcorpo);
            nova();
            fila.unshift(resto);
            continue;
          }
        }
      }
      // parágrafo longo: divide por palavras
      if (/^(P|LI|H\d)$/.test(no.tagName) || (no.tagName === 'DIV' && !no.querySelector('table,p,div'))) {
        const total = contarPalavras(no);
        const espacoLivre = pg._limite - pg._conteudo.scrollHeight;
        if (total > 8 && espacoLivre > 30) {
          let lo = 1, hi = total - 1, melhor = 0;
          while (lo <= hi) {
            const mid = (lo + hi) >> 1;
            const [cab] = dividirTexto(no, mid);
            pg._conteudo.appendChild(cab);
            const ok = cabe(pg);
            pg._conteudo.removeChild(cab);
            if (ok) { melhor = mid; lo = mid + 1; } else hi = mid - 1;
          }
          if (melhor >= 4) {
            const [cab, resto] = dividirTexto(no, melhor);
            pg._conteudo.appendChild(cab);
            nova();
            fila.unshift(resto);
            continue;
          }
        }
      }
      if (vazia) { pg._conteudo.appendChild(no); continue; }   // maior que a página: deixa
      nova();
      fila.unshift(no);
    }
    // a folga só vale para decidir a quebra de página: depois a área de texto volta ao tamanho inteiro
    if (item.folga) paginas.forEach((p) => { p._conteudo.style.height = (p._limite + item.folga) + 'px'; });
    // última página: as assinaturas já estão no corpo, então a rubrica do rodapé (class="rubrica") some
    const ult = paginas[paginas.length - 1];
    if (ult && ult._rodape) ult._rodape.querySelectorAll('.rubrica').forEach((e) => { e.style.visibility = 'hidden'; });
    return paginas;
  }

  // ---- modelo "PDF original": a página é a imagem do PDF e os campos ficam por cima
  const PT = 25.4 / 72;   // pt -> mm
  function paginasOriginais(item, destino) {
    const out = [];
    (item.paginas || []).forEach((pg) => {
      const el = document.createElement('div');
      el.className = 'pagina pagina-original';
      el.style.width = (pg.w * PT) + 'mm'; el.style.height = (pg.h * PT) + 'mm';
      const img = document.createElement('img'); img.className = 'fundo'; img.alt = ''; img.src = pg.img;
      el.appendChild(img);
      (pg.caixas || []).forEach((cx) => {
        const d = document.createElement('div');
        d.className = 'cx' + (cx.lh ? ' multi' : '') + (cx.cobrir ? ' cobrir' : '') + (cx.alinhar === 'centro' ? ' centro' : '');
        if (cx.fonte) d.style.fontFamily = cx.fonte;
        if (cx.cor) d.style.color = cx.cor;
        if (cx.cobrir) d.style.background = cx.fundo || '#fff';
        d.style.left = (cx.x * PT) + 'mm'; d.style.top = (cx.y * PT) + 'mm';
        d.style.width = (cx.w * PT) + 'mm'; d.style.height = (cx.h * PT) + 'mm';
        d.style.fontSize = (cx.tam || 9) + 'pt';
        if (cx.lh) d.style.lineHeight = cx.lh + 'pt';
        d.style.textAlign = { centro: 'center', direita: 'right', justificado: 'justify' }[cx.alinhar] || 'left';
        if (cx.alinhar === 'centro') d.style.justifyContent = 'center';
        if (cx.negrito) d.style.fontWeight = 'bold';
        d.innerHTML = '<span class="cx-txt">' + (cx.html || '') + '</span>';
        if (cx.recuo) d.firstChild.style.textIndent = (cx.recuo * PT) + 'mm';   // texto que começa no meio da 1ª linha
        el.appendChild(d);
      });
      destino.appendChild(el);
      // ajusta a letra ao espaço: texto grande diminui; texto de várias linhas cresce até preencher o quadro
      el.querySelectorAll('.cx').forEach((d, idx) => {
        const cx = (pg.caixas || [])[idx];
        let t = parseFloat(d.style.fontSize), lim = 0;
        const sobra = () => d.scrollHeight > d.clientHeight + 1 || d.scrollWidth > d.clientWidth + 1;
        const temTexto = d.textContent.replace(/[\s,._]/g, '').length > 0;
        if (cx && cx.lh && temTexto && !d.querySelector('.cp.vz')) {
          const base = t, max = Math.min(base * 1.22, 10.5);
          const fixar = (v) => { d.style.fontSize = v + 'pt'; d.style.lineHeight = (v * 1.42).toFixed(2) + 'pt'; };
          fixar(base);
          if (!sobra()) {
            let v = base;
            while (v + 0.25 <= max && lim++ < 60) { fixar(v + 0.25); if (sobra()) { fixar(v); break; } v += 0.25; }
          } else { d.style.lineHeight = cx.lh + 'pt'; }
          t = parseFloat(d.style.fontSize);
        }
        while (sobra() && t > 6 && lim++ < 90) { t -= 0.5; d.style.fontSize = t + 'pt'; }
        if (cx) { cx.tamFinal = parseFloat(d.style.fontSize); cx.lhFinal = parseFloat(d.style.lineHeight) || null; }
      });
      out.push(el);
    });
    return out;
  }

  async function paginar(destino, itens) {
    destino.innerHTML = '';
    try { if (document.fonts && document.fonts.ready) await document.fonts.ready; } catch (e) { /* ok */ }
    const todas = [];
    itens.forEach((it, i) => {
      if (!it.paginas && it.lhBranco) {   // em branco: linhas mais altas só se não aumentar o número de páginas
        const orig = it.html;
        const ALT = { '1.75': 'height:17pt;font-size:12pt', '1.55': 'height:16pt;font-size:11.5pt', '1.4': 'height:15pt;font-size:11pt' };
        const com = (lh) => (lh ? orig.replace(/line-height: 1\.75/g, 'line-height: ' + lh).replace(/height:17pt;font-size:12pt/g, ALT[lh])
          : orig.replace(/line-height: 1\.75;?/g, '').replace(/height:17pt;font-size:12pt/g, 'height:14pt;font-size:10.5pt'));
        const contar = (h) => { const tmp = document.createElement('div'); destino.appendChild(tmp); const n = paginarItem({ ...it, html: h }, tmp).length; tmp.remove(); return n; };
        // candidatas, da mais folgada para a mais compacta; fica a primeira que dá o menor número de páginas
        const cands = ['1.75', '1.55', '1.4'].map(com);
        const t = document.createElement('template'); t.innerHTML = com(null);
        const tabs = Array.from(t.content.querySelectorAll('table.br-qualif'));
        cands.push(t.innerHTML);
        for (let k = 0; k < 6; k++) {   // tira linhas livres da qualificação, no mínimo 2
          let tirou = false;
          tabs.forEach((tb) => { const rs = tb.querySelectorAll('tr'); if (rs.length > 2) { rs[rs.length - 1].remove(); tirou = true; } });
          if (!tirou) break;
          cands.push(t.innerHTML);
        }
        const ns = cands.map(contar), minimo = Math.min(...ns);
        const melhor = cands[ns.indexOf(minimo)];
        it.html = melhor || com(null);
        it.lhBranco = false;
      }
      const pgs = it.paginas ? paginasOriginais(it, destino) : paginarItem(it, destino);
      pgs.forEach((p) => { p.dataset.item = i; todas.push(p); });
    });
    return todas;
  }

  G.DOC = { calcular, tituloPt, render, formatar, extensoReais, extensoInteiro, numBR, moeda, hojeISO, lerData, aplicarGenero, paginar, pilhaFonte, MESES, SEMANA, esc };
})(window);
