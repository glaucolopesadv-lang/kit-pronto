/* =====================================================================
   Kit Pronto — interface
   ===================================================================== */
(function () {
  'use strict';
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => Array.from((el || document).querySelectorAll(s));
  const esc = DOC.esc;
  const WIN = /Windows/i.test(navigator.userAgent);
  const S = { branco: null, ajustes: {}, ajustesDe: null, bib: null, filtro: { pasta: '', area: '', busca: '', aba: 'todos' }, atual: null, valores: {}, zoom: 1, ed: null, fila: [] };
  const UFS = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];
  const TIPOS = [['texto', 'Texto curto'], ['texto_longo', 'Texto longo'], ['cpf', 'CPF'], ['cnpj', 'CNPJ'], ['data', 'Data'], ['moeda', 'Valor em R$ (com extenso)'],
    ['numero', 'Número'], ['calculo', 'Cálculo (fórmula)'], ['telefone', 'Telefone'], ['cep', 'CEP'], ['email', 'E-mail'], ['uf', 'UF'], ['opcoes', 'Lista de opções'], ['caixa', 'Caixa de marcar (X)']];
  const ICONES = { 'recibo': '🧾', 'contrato': '📝', 'procura': '⚖️', 'declara': '📄', 'ficha': '🗂️', 'cadastro': '🗂️', 'kit': '🧰', 'inss': '🏛️', 'termo': '🏛️',
    'peti': '📑', 'requer': '📨', 'notifica': '📮', 'substabelec': '🔁', 'acordo': '🤝', 'carta': '✉️' };
  const COR_ICO = ['#EEF1F7', '#FBF3DE', '#E7F2EC', '#F6E9E9', '#EEEAF7', '#E7F1F4'];

  // ------------------------------------------------------------ utilidades
  const norm = (t) => (t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const slug = (t) => norm(t).replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'campo';
  function lsGet(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ok */ } }
  async function api(url, opts) {
    opts = opts || {};
    if (opts.json !== undefined) { opts.method = opts.method || 'POST'; opts.headers = { 'Content-Type': 'application/json' }; opts.body = JSON.stringify(opts.json); }
    const r = await fetch(url, opts);
    let d; try { d = await r.json(); } catch (e) { d = { ok: false, erro: 'Resposta inválida do programa' }; }
    if (!r.ok || d.ok === false) { const e = new Error(d.erro || ('Erro ' + r.status)); e.status = r.status; throw e; }
    return d;
  }
  function toast(msg, opts) {
    opts = opts || {};
    const t = document.createElement('div');
    t.className = 'toast' + (opts.erro ? ' erro' : '');
    t.innerHTML = `<div>${msg}</div>`;
    if (opts.acoes) {
      const a = document.createElement('div'); a.className = 't-acoes';
      opts.acoes.forEach(([rot, fn, sec]) => { const b = document.createElement('button'); b.textContent = rot; if (sec) b.className = 'sec'; b.onclick = () => { fn(); t.remove(); }; a.appendChild(b); });
      t.appendChild(a);
    }
    $('#toasts').appendChild(t);
    setTimeout(() => t.remove(), opts.tempo || (opts.acoes ? 12000 : 4200));
  }
  function modal(html, larga) {
    $('#modalCaixa').className = 'modal-caixa' + (larga ? ' larga' : '');
    $('#modalCaixa').innerHTML = html;
    $('#modal').hidden = false;
    const f = $('#modalCaixa input:not([type=hidden]), #modalCaixa select'); if (f) setTimeout(() => f.focus(), 30);
  }
  function fecharModal() { $('#modal').hidden = true; $('#modalCaixa').innerHTML = ''; }
  $('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal') fecharModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#modal').hidden) fecharModal(); });
  function cabModal(t) { return `<div class="m-cab"><h3>${t}</h3><button class="x" onclick="App.fecharModal()">×</button></div>`; }
  function perguntar(titulo, rotulo, valor) {
    return new Promise((res) => {
      modal(cabModal(titulo) + `<div class="m-corpo"><div class="campo"><label>${rotulo}</label><input id="mPerg" value="${esc(valor || '')}"></div></div>
        <div class="m-pe"><button class="bt bt-cinza" id="mNao">Cancelar</button><button class="bt bt-ouro" id="mSim">OK</button></div>`);
      const fim = (v) => { fecharModal(); res(v); };
      $('#mSim').onclick = () => fim($('#mPerg').value.trim());
      $('#mNao').onclick = () => fim(null);
      $('#mPerg').onkeydown = (e) => { if (e.key === 'Enter') fim($('#mPerg').value.trim()); };
      setTimeout(() => $('#mPerg').select(), 40);
    });
  }
  function confirmar(titulo, texto, botao) {
    return new Promise((res) => {
      modal(cabModal(titulo) + `<div class="m-corpo"><p>${texto}</p></div>
        <div class="m-pe"><button class="bt bt-cinza" id="mNao">Cancelar</button><button class="bt bt-perigo" id="mSim">${botao || 'Confirmar'}</button></div>`);
      $('#mSim').onclick = () => { fecharModal(); res(true); };
      $('#mNao').onclick = () => { fecharModal(); res(false); };
    });
  }
  function mostrarTela(id) { $$('.tela').forEach((t) => t.classList.toggle('ativa', t.id === id)); }
  function iconeDe(m) {
    const t = norm((m.tipo === 'kit' ? 'kit ' : '') + m.categoria + ' ' + m.nome);
    for (const k in ICONES) if (t.includes(k)) return ICONES[k];
    return '📄';
  }
  function corDe(txt) { let h = 0; for (const c of txt || '') h = (h * 31 + c.charCodeAt(0)) >>> 0; return COR_ICO[h % COR_ICO.length]; }
  const fmtN = (n) => Number(n || 0).toLocaleString('pt-BR');

  // ------------------------------------------------------------ biblioteca
  async function carregar() {
    S.bib = await api('api/biblioteca');
    const nm = S.bib.modelos.filter((m) => m.tipo !== 'kit').length, nk = S.bib.modelos.length - nm;
    $('#topoNum').innerHTML = `${fmtN(nm)} ${nm === 1 ? 'modelo' : 'modelos'} · ${fmtN(nk)} ${nk === 1 ? 'kit' : 'kits'}<br>${fmtN(S.bib.timbrados.length)} timbrados · ${fmtN(S.bib.categorias.length)} pastas`;
    desenharInicio();
  }

  function desenharInicio() {
    const b = S.bib;
    const modelos = b.modelos;
    const nk = modelos.filter((m) => m.tipo === 'kit').length;
    const campos = new Set(); modelos.forEach((m) => (m.campos || []).forEach((c) => campos.add(c.chave)));
    $('#kpis').innerHTML = [
      ['k1', 'MODELOS', modelos.length - nk, 'prontos para preencher'],
      ['k2', 'KITS', nk, 'vários documentos de uma vez'],
      ['k3', 'PASTAS', b.categorias.length, 'organizadas automaticamente'],
      ['k4', 'PAPÉIS TIMBRADOS', b.timbrados.length, 'escolha na hora de gerar'],
      ['k5', 'GERADOS NO MÊS', b.gerados_mes, 'cópias em Documentos gerados'],
    ].map(([c, t, n, p]) => `<div class="kpi ${c}" onclick="App.kpi('${c}')" title="Abrir"><h4>${t}<span class="ir">›</span></h4><div class="n">${fmtN(n)}</div><p>${p}</p></div>`).join('');
    // pastas
    const f = S.filtro;
    $('#listaPastas').innerHTML = `<li class="${f.pasta ? '' : 'ativa'}" onclick="App.filtroPasta('')"><span class="ico">📚</span>Todas<span class="qtd">${modelos.length}</span></li>` +
      b.categorias.map((c) => `<li class="${f.pasta === c.nome ? 'ativa' : ''}" onclick="App.filtroPasta(${esc(JSON.stringify(c.nome))})">
        <span class="ico">${iconeDe({ categoria: c.nome, nome: '' })}</span>${esc(c.nome)}<span class="qtd">${c.qtd}</span></li>`).join('');
    const areas = [...new Set(modelos.map((m) => m.area).filter(Boolean))].sort();
    $('#listaAreas').innerHTML = `<button class="chip ${f.area ? '' : 'ativa'}" onclick="App.filtroArea('')">Todas</button>` +
      areas.map((a) => `<button class="chip ${f.area === a ? 'ativa' : ''}" onclick="App.filtroArea(${esc(JSON.stringify(a))})">${esc(a)}</button>`).join('');
    desenharGrade();
  }

  function filtrados() {
    const f = S.filtro, q = norm(f.busca);
    let lst = S.bib.modelos.filter((m) => (!f.pasta || m.categoria === f.pasta) && (!f.area || m.area === f.area));
    if (q) {
      const termos = q.split(/\s+/).filter(Boolean);
      lst = lst.filter((m) => {
        const alvo = norm([m.nome, m.categoria, m.area, m.descricao, (m.tags || []).join(' '), (m.campos || []).map((c) => c.rotulo).join(' ')].join(' '));
        return termos.every((t) => alvo.includes(t));
      });
    }
    if (f.aba === 'kits') lst = lst.filter((m) => m.tipo === 'kit');
    if (f.aba === 'recentes') {
      const rec = lsGet('bm_recentes', []);
      lst = rec.map((id) => lst.find((m) => m.id === id)).filter(Boolean);
    }
    return lst;
  }

  function desenharGrade() {
    const lst = filtrados(), f = S.filtro;
    const partes = [];
    if (f.pasta) partes.push('pasta <b>' + esc(f.pasta) + '</b>');
    if (f.area) partes.push('área <b>' + esc(f.area) + '</b>');
    if (f.busca) partes.push('busca "<b>' + esc(f.busca) + '</b>"');
    $('#filtroTxt').innerHTML = partes.length ? `${lst.length} resultado(s) · ${partes.join(' · ')} · <button class="lnk" onclick="App.limparFiltros()">limpar filtros</button>`
      : 'Mostrando todos os modelos. Clique numa pasta para filtrar.';
    if (!lst.length) {
      $('#gradeModelos').innerHTML = `<div class="vazio-lista">${f.aba === 'recentes' ? 'Nenhum modelo usado ainda.' : 'Nenhum modelo encontrado.'}<br><br>
        <button class="bt bt-ouro" onclick="App.abrirImportar()">＋ Importar modelo</button></div>`;
      return;
    }
    const grupos = {};
    if (f.aba === 'recentes') grupos['Usados recentemente'] = lst;
    else lst.forEach((m) => { (grupos[m.categoria] = grupos[m.categoria] || []).push(m); });
    $('#gradeModelos').innerHTML = Object.keys(grupos).sort((a, b) => a.localeCompare(b, 'pt')).map((cat) => {
      const ms = grupos[cat];
      const acoes = f.aba === 'recentes' ? '' : `<div class="acoes"><button class="lnk" onclick="App.renomearPasta(${esc(JSON.stringify(cat))})">RENOMEAR PASTA ›</button></div>`;
      return `<div class="grupo"><div class="grupo-cab"><h3 onclick="App.filtroPasta(${esc(JSON.stringify(cat))})" title="Mostrar só esta pasta">${esc(cat)}</h3><span class="sub">${ms.length} ${ms.length === 1 ? 'modelo' : 'modelos'}</span>${acoes}</div>
        <div class="cards">${ms.map(cardModelo).join('')}</div></div>`;
    }).join('');
  }

  function cardModelo(m) {
    const ehKit = m.tipo === 'kit';
    const info = ehKit ? `${m.n_itens || 0} documentos` : `${m.n_campos || 0} campos`;
    return `<div class="card" data-id="${esc(m.id)}" onclick="App.clicarCard(event,'${esc(m.id)}')">
      <div class="card-top"><div class="card-ico" style="background:${corDe(m.categoria)}">${iconeDe(m)}</div>
        <div style="min-width:0"><h5 onclick="App.abrirModelo('${esc(m.id)}')">${esc(m.nome)}</h5>
        <div class="desc">${esc(m.descricao || '')}</div></div></div>
      <div class="tags">${ehKit ? '<span class="tag kit">KIT</span>' : ''}${m.area ? `<span class="tag area">${esc(m.area)}</span>` : ''}
        <span class="tag">${info}</span>${m.timbrado_nome ? `<span class="tag">🖼️ ${esc(m.timbrado_nome.replace('Marcos Inácio Advogados', 'MI'))}</span>` : ''}</div>
      <div class="card-pe"><button class="bt bt-azul" onclick="App.abrirModelo('${esc(m.id)}')">Preencher</button>
        <button class="menu-bt" title="Mais opções" onclick="App.menuModelo(event,'${esc(m.id)}')">⋯</button></div></div>`;
  }

  function menuModelo(ev, id) {
    ev.stopPropagation();
    fecharMenus();
    const m = S.bib.modelos.find((x) => x.id === id);
    const menu = document.createElement('div');
    menu.className = 'menu';
    menu.innerHTML = `<button data-a="editar">✏️ Editar modelo</button><button data-a="renomear">🏷️ Renomear</button>
      <button data-a="mover">📂 Mover para outra pasta</button><button data-a="duplicar">⧉ Duplicar</button>
      ${m.tipo === 'kit' ? '' : '<button data-a="kit">🧰 Criar kit com este modelo</button>'}
      <button data-a="excluir" class="perigo">🗑️ Excluir</button>`;
    const card = ev.target.closest('.card');
    card.appendChild(menu);
    menu.style.right = '10px'; menu.style.bottom = '48px';
    menu.onclick = async (e) => {
      const a = e.target.closest('button') && e.target.closest('button').dataset.a;
      fecharMenus();
      if (a === 'editar') abrirEditor(id);
      if (a === 'renomear') {
        const n = await perguntar('Renomear modelo', 'Novo nome', m.nome);
        if (n && n !== m.nome) { await api('api/modelo', { json: { ...semExtras(m), nome: n } }); toast('Modelo renomeado.'); carregar(); }
      }
      if (a === 'mover') moverModelo(m);
      if (a === 'duplicar') { await api(`api/modelo/${id}/duplicar`, { method: 'POST' }); toast('Cópia criada.'); carregar(); }
      if (a === 'kit') novoKit(m);
      if (a === 'excluir') {
        if (await confirmar('Excluir modelo', `Excluir <b>${esc(m.nome)}</b>? Ele vai para a pasta Lixeira e pode ser recuperado.`, 'Excluir')) {
          await api(`api/modelo/${id}`, { method: 'DELETE' }); toast('Modelo enviado para a Lixeira.'); carregar();
        }
      }
    };
  }
  function clicarCard(ev, id) {
    if (ev.target.closest('.menu-bt') || ev.target.closest('.menu') || ev.target.closest('button')) return;
    abrirModelo(id);
  }
  function kpi(c) {
    const aba = (nome) => { const b = $(`#abasInicio .aba[data-aba="${nome}"]`); trocarAba(b); };
    if (c === 'k1') { limparFiltros(); aba('todos'); }
    else if (c === 'k2') { limparFiltros(); aba('kits'); }
    else if (c === 'k3') abrirPasta('modelos');
    else if (c === 'k4') abrirTimbrados();
    else if (c === 'k5') abrirPasta('gerados');
  }
  function fecharMenus() { $$('.menu').forEach((m) => m.remove()); }
  document.addEventListener('click', (e) => { if (!e.target.closest('.menu')) fecharMenus(); });
  function semExtras(m) {
    const o = {}; for (const k in m) if (!k.startsWith('_') && !['html', 'n_campos', 'n_itens', 'timbrado_nome'].includes(k)) o[k] = m[k];
    return o;
  }
  function opcoesPastas(sel) {
    return S.bib.categorias.map((c) => `<option ${c.nome === sel ? 'selected' : ''}>${esc(c.nome)}</option>`).join('') + '<option value="__nova">＋ Nova pasta…</option>';
  }
  function moverModelo(m) {
    modal(cabModal('Mover para outra pasta') + `<div class="m-corpo"><div class="campo"><label>Pasta</label>
      <select id="mPasta" onchange="document.getElementById('mNovaW').hidden=this.value!=='__nova'">${opcoesPastas(m.categoria)}</select></div>
      <div class="campo" id="mNovaW" hidden><label>Nome da nova pasta</label><input id="mNova"></div></div>
      <div class="m-pe"><button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button><button class="bt bt-ouro" id="mOk">Mover</button></div>`);
    $('#mOk').onclick = async () => {
      let p = $('#mPasta').value; if (p === '__nova') p = $('#mNova').value.trim();
      if (!p) return;
      await api('api/modelo', { json: { ...semExtras(m), categoria: p } });
      fecharModal(); toast(`Movido para <b>${esc(p)}</b>.`); carregar();
    };
  }
  async function novoKit(base) {
    const nome = await perguntar('Novo kit', 'Nome do kit', 'Kit — ' + base.nome);
    if (!nome) return;
    const r = await api('api/modelo', { json: { nome, categoria: 'Kits de Atendimento', tipo: 'kit', area: base.area, timbrado: base.timbrado,
      itens: [{ modelo: base.id }], campos: [], descricao: '' } });
    await carregar();
    abrirEditor(r.modelo.id);
  }

  // ------------------------------------------------------------ PREENCHER
  async function abrirModelo(id) {
    const d = await api('api/modelo/' + encodeURIComponent(id));
    const m = d.modelo;
    S.atual = m;
    if (S.ajustesDe !== m.id) { S.ajustes = {}; S.ajustesDe = m.id; }
    if (S.branco) { S.branco = null; desenharBarraBranco(); }
    if (!S.kitSel || S.kitSel.id !== m.id) S.kitSel = { id: m.id, on: m.itens.map(() => true) };
    ['clienteBox', 'kitBox'].forEach((id) => { const el = $('#' + id); el.classList.remove('aberto'); const s = $('.seta', el); if (s) s.textContent = '▸'; });
    const rec = lsGet('bm_recentes', []).filter((x) => x !== id); rec.unshift(id); lsSet('bm_recentes', rec.slice(0, 30));
    S.timbradoEscolhido = m.timbrado || S.bib.config.timbrado_padrao || 'nenhum';
    // valores padrão
    (m.campos || []).forEach((c) => {
      if (S.valores[c.chave] === undefined || S.valores[c.chave] === '') {
        if (c.tipo === 'data' && c.padrao === 'hoje') S.valores[c.chave] = DOC.hojeISO();
        else if (c.chave === 'local' && S.bib.config.local_padrao) S.valores[c.chave] = S.bib.config.local_padrao;
        else if (c.padrao !== undefined && c.padrao !== '') S.valores[c.chave] = c.tipo === 'caixa' ? !!c.padrao : c.padrao;
      }
    });
    $('#docNome').textContent = m.nome;
    $('#docMeta').textContent = `${m.categoria}${m.area ? ' · ' + m.area : ''}${m.tipo === 'kit' ? ' · kit com ' + m.itens.length + ' documentos' : ''}`;
    $('#pfTitulo').textContent = 'FORMULÁRIO';
    $('#selTimbrado').innerHTML = `<option value="nenhum">Sem timbrado</option>` +
      S.bib.timbrados.map((t) => `<option value="${esc(t.id)}" ${t.id === S.timbradoEscolhido ? 'selected' : ''}>${esc(t.nome)}</option>`).join('');
    $('#selTimbrado').value = S.timbradoEscolhido;
    $('#selTimbWrap').hidden = m.itens.every((it) => it.formato === 'paginas');
    desenharKitBox();
    montarForm();
    carregarDatalistClientes();
    mostrarTela('v-preencher');
    aplicarZoom();
    await renderPrevia();
    caberNaLargura();
    $('#previaRolagem').scrollTop = 0;
    // ao abrir o programa, avisa se ficaram dados do último cliente (evita sair documento com o nome errado)
    const ultimo = (S.valores.cliente_nome || S.valores.prestador_nome || '').trim();
    if (!S.avisouRestaurado && ultimo) {
      S.avisouRestaurado = true;
      toast(`O formulário ainda está com os dados de <b>${esc(ultimo)}</b>, do último atendimento.`,
        { tempo: 15000, acoes: [['Continuar com este cliente', () => {}, true], ['Novo cliente', () => { S.valores = {}; lsSet('bm_valores', {}); $('#clienteBusca').value = ''; abrirModelo(S.atual.id); }]] });
    }
    S.avisouRestaurado = true;
  }

  function itensAtivos() {
    const m = S.atual;
    if (m.tipo !== 'kit') return m.itens;
    return m.itens.filter((it, i) => S.kitSel.on[i]);
  }
  function camposAtivos() {
    const m = S.atual;
    if (m.tipo !== 'kit') return m.campos || [];
    const usar = new Set(); itensAtivos().forEach((it) => (it.campos_chaves || []).forEach((k) => usar.add(k)));
    return (m.campos || []).filter((c) => usar.has(c.chave));
  }
  function desenharKitBox() {
    const m = S.atual, box = $('#kitBox');
    const bs = $('#btSeparados'); if (bs) bs.hidden = !(m.tipo === 'kit' && S.kitSel.on.filter(Boolean).length > 1);
    if (m.tipo !== 'kit') { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    box.classList.add('recolhivel');
    const n = S.kitSel.on.filter(Boolean).length;
    box.innerHTML = `<div class="rec-cab" onclick="App.alternarRec('kitBox')"><span>🧰 <b>Documentos do kit</b> <span class="rec-info">${n} de ${m.itens.length} marcados</span></span><span class="seta">${box.classList.contains('aberto') ? '▾' : '▸'}</span></div>
      <div class="corpo-r bloco"><div class="kit-docs">${m.itens.map((it, i) =>
      `<label class="kit-doc ${S.kitSel.on[i] ? '' : 'off'}"><input type="checkbox" ${S.kitSel.on[i] ? 'checked' : ''} onchange="App.kitMarcar(${i}, this.checked)">
       <span class="n">${i + 1}</span><span>${esc(it.nome)}</span></label>`).join('')}</div>
      <div class="kit-atalhos"><button class="lnk" onclick="App.kitTodos(true)">marcar todos</button><button class="lnk" onclick="App.kitTodos(false)">desmarcar todos</button></div></div>`;
  }
  function alternarRec(id) {
    const el = $('#' + id); el.classList.toggle('aberto');
    const s = $('.rec-cab .seta', el); if (s) s.textContent = el.classList.contains('aberto') ? '▾' : '▸';
    if (id === 'clienteBox' && el.classList.contains('aberto')) setTimeout(() => $('#clienteBusca').focus(), 30);
  }
  function kitMarcar(i, v) {
    S.kitSel.on[i] = v;
    if (!S.kitSel.on.some(Boolean)) { S.kitSel.on[i] = true; toast('Deixe pelo menos um documento marcado.'); }
    desenharKitBox(); montarForm(); renderPrevia();
  }
  function kitTodos(v) { S.kitSel.on = S.atual.itens.map((_, i) => v || i === 0); desenharKitBox(); montarForm(); renderPrevia(); }

  function itensParaRender(modo) {
    const m = S.atual;
    const tmap = {}; S.bib.timbrados.forEach((t) => { tmap[t.id] = t; });
    const B = S.branco;
    const valores = B ? valoresBranco() : S.valores;
    return itensAtivos().map((it) => {
      const aj = B ? {} : (S.ajustes[chaveItem(it)] || {});
      if (it.formato === 'paginas' && B) {   // PDF original: sai a página original, com as linhas para preencher à mão
        return { paginas: (it.paginas || []).map((pg) => ({ img: pg.img, w: pg.w, h: pg.h, caixas: [] })) };
      }
      if (it.formato === 'paginas') {
        const op = { modo, genero: it.genero, maiusculas: it.valores_maiusculos, vazioNada: true };
        const fonte = ((it.caixas || []).find((c) => c.fonte) || {}).fonte || '"Times New Roman", Times, serif';
        return { paginas: (it.paginas || []).map((pg, i) => ({ img: pg.img, w: pg.w, h: pg.h,
          caixas: (it.caixas || []).filter((c) => c.pagina === i).map((c) => ({ ...c,
            html: DOC.render(c.texto, m.campos, S.valores, { ...op, vazioNada: tokensDe(c.texto).length <= 1 }) }))
            .concat((aj.extras || []).filter((e) => e.pagina === i).map((e) => caixaExtra(e, fonte))) })) };
      }
      let timb = S.timbradoEscolhido;
      if (it.timbrado === 'nenhum') timb = 'nenhum';
      if (m.tipo !== 'kit' && S.timbradoEscolhido) timb = S.timbradoEscolhido;
      const t = tmap[timb];
      const margens = t ? t.margens : (it.margens || { sup: 2, inf: 2, esq: 2.5, dir: 2.5 });
      const opR = { modo, genero: it.genero, maiusculas: it.valores_maiusculos, branco: !!B, semRep: B && !B.comRep };
      let html = aj.html != null ? aj.html : DOC.render(B ? modeloEmBranco(it, valores) : it.html, m.campos, valores, opR);
      if (B) html = linhasAltas(html);
      return {
        html, lhBranco: !!B && /line-height: 1\.75|height:17pt/.test(html), folga: B ? 16 : 0,
        rodape: it.rodape ? DOC.render(B ? rodapeEmBranco(it.rodape) : it.rodape, m.campos, valores, opR) : '',
        timbrado: t ? timb : 'nenhum', margens, fonte: it.fonte, tamanho: it.tamanho, paisagem: !!it.paisagem,
        espacamento: it.espacamento,
      };
    });
  }

  let tRender = null;
  function agendarRender() { clearTimeout(tRender); tRender = setTimeout(renderPrevia, 140); }
  async function renderPrevia() {
    if (!S.atual) return;
    const med = $('#medidor');
    await DOC.paginar(med, itensParaRender('previa'));
    const alvo = $('#previa');
    const rol = $('#previaRolagem'), topo = rol.scrollTop;
    alvo.innerHTML = '';
    while (med.firstChild) alvo.appendChild(med.firstChild);
    rol.scrollTop = topo;
    marcarAtivo(S.focoCampo);
    atualizarProgresso();
    desenharClienteAtual();
    desenharAvisoAjuste();
  }

  function atualizarProgresso() {
    const cs = camposAtivos().filter((c) => c.tipo !== 'caixa');
    const ok = cs.filter((c) => S.valores[c.chave] !== undefined && String(S.valores[c.chave]).trim() !== '').length;
    $('#progresso').textContent = `${ok} de ${cs.length} campos preenchidos`;
  }

  function montarForm() {
    const m = S.atual;
    const grupos = [];
    const idx = {};
    camposAtivos().forEach((c) => {
      const g = c.grupo || 'Geral';
      if (!(g in idx)) { idx[g] = grupos.length; grupos.push({ nome: g, campos: [] }); }
      grupos[idx[g]].campos.push(c);
    });
    const fechados = lsGet('bm_grupos_fechados', {});
    $('#formulario').innerHTML = grupos.map((g) => {
      const fech = fechados[g.nome];
      let corpo = '';
      const caixas = g.campos.every((c) => c.tipo === 'caixa');
      if (caixas) corpo = `<div class="caixas">${g.campos.map(htmlCampo).join('')}</div>`;
      else {
        // campos com a mesma "linha" (ex.: quantidade | valor | subtotal de um item) ficam lado a lado
        const partes = []; let i = 0;
        while (i < g.campos.length) {
          const c = g.campos[i];
          if (!c.linha) { partes.push(htmlCampo(c)); i++; continue; }
          const grupoL = [];
          while (i < g.campos.length && g.campos[i].linha === c.linha) grupoL.push(g.campos[i++]);
          partes.push(`<div class="linha-campos"><div class="lc-tit">${esc(c.linha_titulo || c.linha)}</div>
            <div class="lc-cols" style="grid-template-columns:repeat(${grupoL.length},1fr)">${grupoL.map((x) => htmlCampo(x, true)).join('')}</div></div>`);
        }
        corpo = partes.join('');
      }
      return `<div class="grupo-form ${fech ? 'fechado' : ''}" data-g="${esc(g.nome)}"><div class="gf-cab" onclick="App.alternarGrupo(this)">
        <label class="rot-sec">${esc(g.nome.toUpperCase())}</label><span><span class="cont">${g.campos.length}</span> <span class="seta">${fech ? '▸' : '▾'}</span></span></div>
        <div class="gf-corpo">${corpo}</div></div>`;
    }).join('') || '<p class="dica">Este modelo não tem campos. Use "Editar modelo" para criar.</p>';
    $$('#formulario [data-k]').forEach(ligarInput);
    $$('#formulario .campo-moeda').forEach((el) => mostrarExtenso(el.dataset.k));
    atualizarCalculos();
  }
  function atualizarCalculos() {
    const mapa = {}; (S.atual.campos || []).forEach((c) => { mapa[c.chave] = c; });
    $$('#formulario .campo-calc').forEach((el) => {
      const c = mapa[el.id.slice(5)]; if (!c) return;
      const n = DOC.calcular(c, S.valores, mapa, {});
      el.textContent = n === null ? '—' : (c.formato === 'numero' ? String(n).replace('.', ',') : 'R$ ' + DOC.moeda(n));
    });
  }

  function htmlCampo(c, curto) {
    const k = esc(c.chave), v = S.valores[c.chave];
    const val = v === undefined || v === null ? '' : esc(v);
    const id = 'f_' + k;
    const ajuda = c.ajuda ? `<div class="ajuda">${esc(c.ajuda)}</div>` : '';
    let inp;
    switch (c.tipo) {
      case 'caixa': {
        const sub = /^\s*↳/.test(c.rotulo || '');
        return `<label class="caixa ${sub ? 'sub' : ''}"><input type="checkbox" id="${id}" data-k="${k}" ${v ? 'checked' : ''}><span>${esc((c.rotulo || c.chave).replace(/^\s*↳\s*/, ''))}</span></label>`;
      }
      case 'texto_longo': inp = `<textarea id="${id}" data-k="${k}" rows="3">${val}</textarea>`; break;
      case 'data': inp = `<input id="${id}" data-k="${k}" value="${esc(dataBR(v === 'hoje' ? DOC.hojeISO() : v))}" placeholder="dd/mm/aaaa" inputmode="numeric" maxlength="10" autocomplete="off" class="campo-data">`; break;
      case 'opcoes': inp = `<select id="${id}" data-k="${k}"><option value=""></option>${(c.opcoes || []).map((o) => `<option ${o === v ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`; break;
      case 'uf': inp = `<select id="${id}" data-k="${k}"><option value=""></option>${UFS.map((u) => `<option ${u === v ? 'selected' : ''}>${u}</option>`).join('')}</select>`; break;
      case 'moeda': inp = `<input id="${id}" data-k="${k}" value="${val}" inputmode="decimal" placeholder="0,00" class="campo-moeda">`; break;
      case 'numero': inp = `<input id="${id}" data-k="${k}" value="${val}" inputmode="numeric">`; break;
      case 'calculo': inp = `<div class="campo-calc" id="calc_${k}" title="Calculado sozinho: ${esc(c.formula || '')}">—</div>`; break;
      case 'email': inp = `<input type="email" id="${id}" data-k="${k}" value="${val}">`; break;
      default: inp = `<input id="${id}" data-k="${k}" value="${val}" autocomplete="off" ${c.tipo === 'cpf' ? 'placeholder="000.000.000-00" inputmode="numeric"' :
        c.tipo === 'cnpj' ? 'placeholder="00.000.000/0000-00" inputmode="numeric"' : c.tipo === 'cep' ? 'placeholder="00000-000" inputmode="numeric"' :
        c.tipo === 'telefone' ? 'placeholder="(84) 9 9999-9999" inputmode="tel"' : ''}>`;
    }
    const ext = c.tipo === 'moeda' && !curto ? `<div class="extenso" id="ext_${k}"></div>` : '';
    return `<div class="campo${curto ? ' curto' : ''}" data-campo="${k}"><label for="${id}" ${curto && c.ajuda ? `title="${esc(c.ajuda)}"` : ''}>${esc(curto ? (c.rotulo_curto || c.rotulo || c.chave) : (c.rotulo || c.chave))}</label>${inp}${ext}${curto ? '' : ajuda}</div>`;
  }

  const MASCARAS = {
    cpf: (d) => d.slice(0, 11).replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2'),
    cnpj: (d) => d.slice(0, 14).replace(/^(\d{2})(\d)/, '$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3').replace(/\.(\d{3})(\d)/, '.$1/$2').replace(/(\d{4})(\d)/, '$1-$2'),
    cep: (d) => d.slice(0, 8).replace(/(\d{5})(\d)/, '$1-$2'),
    telefone: (d) => {
      d = d.slice(0, 11);
      if (d.length <= 2) return d.length ? '(' + d : '';
      if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
      if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
      return `(${d.slice(0, 2)}) ${d.slice(2, 3)} ${d.slice(3, 7)}-${d.slice(7)}`;
    },
  };
  // datas: o campo mostra dd/mm/aaaa e guarda AAAA-MM-DD
  function dataBR(v) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || ''); return m ? `${m[3]}/${m[2]}/${m[1]}` : (v || '');
  }
  function dataISO(txt, fim) {
    let d = (txt || '').replace(/\D/g, '');
    if (fim && d.length === 6) { const yy = +d.slice(4); const agora = new Date().getFullYear() % 100; d = d.slice(0, 4) + (yy > agora ? '19' : '20') + d.slice(4); }
    if (d.length !== 8) return null;
    const dia = +d.slice(0, 2), mes = +d.slice(2, 4), ano = +d.slice(4);
    const dt = new Date(ano, mes - 1, dia);
    if (dt.getFullYear() !== ano || dt.getMonth() !== mes - 1 || dt.getDate() !== dia || ano < 1890) return false;
    return `${ano}-${String(mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
  }
  function campoDef(k) { return (S.atual.campos || []).find((c) => c.chave === k) || {}; }
  function ligarInput(el) {
    const k = el.dataset.k, c = campoDef(k);
    if (c.tipo === 'data') return ligarData(el, k);
    const ev = el.type === 'checkbox' || el.tagName === 'SELECT' || el.type === 'date' ? 'change' : 'input';
    el.addEventListener(ev, () => {
      let v = el.type === 'checkbox' ? el.checked : el.value;
      if (MASCARAS[c.tipo] && typeof v === 'string') {
        const novo = MASCARAS[c.tipo](v.replace(/\D/g, ''));
        if (novo !== v) { el.value = novo; v = novo; }
      }
      S.valores[k] = v;
      // mesmo campo repetido em outro lugar do formulário
      $$(`#formulario [data-k="${CSS.escape(k)}"]`).forEach((o) => { if (o !== el) { if (o.type === 'checkbox') o.checked = !!v; else o.value = v; } });
      if (c.tipo === 'moeda') mostrarExtenso(k);
      atualizarCalculos();
      if (c.tipo === 'cep' && typeof v === 'string' && v.replace(/\D/g, '').length === 8) buscarCep(k, v.replace(/\D/g, ''));
      if (k === chaveNomeCliente() || /_cpf$/.test(k)) desenharClienteAtual();
      salvarRascunho();
      agendarRender();
    });
    if (c.tipo === 'moeda') el.addEventListener('blur', () => {
      const n = DOC.numBR(el.value); if (n !== null) { el.value = DOC.moeda(n); S.valores[k] = el.value; mostrarExtenso(k); atualizarCalculos(); agendarRender(); }
    });
    if (c.tipo === 'data') el.addEventListener('input', () => { S.valores[k] = el.value; agendarRender(); });
    el.addEventListener('focus', () => { S.focoCampo = k; marcarAtivo(k, true); el.closest('.campo') && el.closest('.campo').classList.add('foco'); });
    el.addEventListener('blur', () => { el.closest('.campo') && el.closest('.campo').classList.remove('foco'); });
  }
  async function buscarCep(k, dig) {
    if (S.cepBuscado === k + dig) return; S.cepBuscado = k + dig;
    let r; try { r = await api('api/cep/' + dig); } catch (e) { toast(esc(e.message), { erro: e.status !== 404, tempo: 5000 }); return; }
    const pre = k.replace(/cep$/, '');
    const def = (ch) => (campoDef(ch).padrao || '');
    const vazio = (ch) => { const v = S.valores[ch]; return v === undefined || String(v).trim() === '' || String(v).trim() === def(ch); };
    const mudou = [];
    const por = (ch, val) => { if (val && vazio(ch) && S.valores[ch] !== val) { S.valores[ch] = val; mudou.push(ch); } };
    por(pre + 'endereco', r.logradouro); por(pre + 'bairro', r.bairro); por(pre + 'cidade', r.cidade); por(pre + 'uf', r.uf);
    mudou.forEach((ch) => $$(`#formulario [data-k="${CSS.escape(ch)}"]`).forEach((o) => { o.value = S.valores[ch]; }));
    salvarRascunho(); agendarRender();
    const end = [r.logradouro, r.bairro, r.cidade && r.cidade + '/' + r.uf].filter(Boolean).join(', ');
    toast(`<b>CEP ${esc(dig.slice(0, 5) + '-' + dig.slice(5))}</b>: ${esc(end)}${mudou.includes(pre + 'endereco') ? '<br>Agora complete o <b>número</b> da casa no endereço.' : ''}`, { tempo: 6000 });
    if (mudou.includes(pre + 'endereco')) {
      const el = $(`#formulario [data-k="${CSS.escape(pre + 'endereco')}"]`);
      if (el) { const g = el.closest('.grupo-form'); if (g && g.classList.contains('fechado')) alternarGrupo($('.gf-cab', g));
        el.focus(); el.value = el.value.replace(/,?\s*$/, ', '); S.valores[pre + 'endereco'] = el.value; el.setSelectionRange(el.value.length, el.value.length); }
    }
  }
  function ligarData(el, k) {
    const mascara = (d) => d.slice(0, 8).replace(/^(\d{2})(\d)/, '$1/$2').replace(/^(\d{2})\/(\d{2})(\d)/, '$1/$2/$3');
    const aplicar = (fim) => {
      const ini = el.value;
      const dig = ini.replace(/\D/g, '');
      const novo = mascara(dig);
      if (novo !== ini) el.value = novo;
      const iso = dataISO(novo, fim);
      el.classList.toggle('invalido', iso === false || (fim && dig.length > 0 && !iso));
      const val = iso || '';
      if (iso && fim) el.value = dataBR(iso);
      if (S.valores[k] !== val) {
        S.valores[k] = val;
        $$(`#formulario [data-k="${CSS.escape(k)}"]`).forEach((o) => { if (o !== el) o.value = dataBR(val); });
        salvarRascunho(); agendarRender();
      }
    };
    el.addEventListener('input', () => aplicar(false));
    el.addEventListener('blur', () => { aplicar(true); el.closest('.campo') && el.closest('.campo').classList.remove('foco'); });
    el.addEventListener('keydown', (e) => {   // "h" = hoje
      if (e.key.toLowerCase() === 'h' && !e.metaKey && !e.ctrlKey) { e.preventDefault(); el.value = dataBR(DOC.hojeISO()); aplicar(true); }
    });
    el.addEventListener('focus', () => { S.focoCampo = k; marcarAtivo(k, true); el.closest('.campo') && el.closest('.campo').classList.add('foco'); });
  }
  function mostrarExtenso(k) {
    const box = $('#ext_' + CSS.escape(k)); if (!box) return;
    const n = DOC.numBR(S.valores[k]);
    box.textContent = n === null ? '' : 'R$ ' + DOC.moeda(n) + ' — ' + DOC.extensoReais(n);
  }
  function marcarAtivo(k, rolar) {
    $$('#previa .cp.ativo').forEach((s) => s.classList.remove('ativo'));
    if (!k) return;
    const spans = $$(`#previa .cp[data-k="${CSS.escape(k)}"]`);
    spans.forEach((s) => s.classList.add('ativo'));
    if (rolar && spans[0]) {
      const rol = $('#previaRolagem');
      const r = spans[0].getBoundingClientRect(), rr = rol.getBoundingClientRect();
      if (r.top < rr.top + 40 || r.bottom > rr.bottom - 40) rol.scrollTop += r.top - rr.top - rr.height / 3;
    }
  }
  $('#previa').addEventListener('click', (e) => {
    const s = e.target.closest('.cp'); if (!s) return;
    const k = s.dataset.k;
    const el = $(`#formulario [data-k="${CSS.escape(k)}"]`);
    if (el) {
      const g = el.closest('.grupo-form'); if (g && g.classList.contains('fechado')) alternarGrupo($('.gf-cab', g));
      el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.focus();
    }
  });
  function alternarGrupo(cab) {
    const g = cab.closest('.grupo-form'); g.classList.toggle('fechado');
    $('.seta', g).textContent = g.classList.contains('fechado') ? '▸' : '▾';
    const f = lsGet('bm_grupos_fechados', {}); f[g.dataset.g] = g.classList.contains('fechado'); lsSet('bm_grupos_fechados', f);
  }
  function salvarRascunho() { lsSet('bm_valores', S.valores); }
  async function limparForm() {
    if (!await confirmar('Limpar formulário', 'Apagar todos os dados digitados? As datas voltam para hoje.', 'Limpar')) return;
    S.ajustes = {};
    S.valores = {}; lsSet('bm_valores', {});
    $('#clienteBusca').value = '';
    abrirModelo(S.atual.id);
  }
  function trocarTimbrado(v) { S.timbradoEscolhido = v; renderPrevia(); }
  function aplicarZoom() {
    $('#previa').style.zoom = S.zoom;
    $('#zoomTxt').textContent = Math.round(S.zoom * 100) + '%';
  }
  function caberNaLargura() {   // janela estreita: reduz o zoom para a página caber inteira
    const box = $('#previaRolagem'); if (!box || !box.clientWidth) return;
    const larg = 794;   // A4 em pixels
    const cabe = Math.floor(((box.clientWidth - 30) / larg) * 100) / 100;
    if (S.zoom > cabe) { S.zoom = Math.max(0.4, cabe); aplicarZoom(); }
  }
  function zoom(d) { S.zoom = Math.min(2, Math.max(0.4, +(S.zoom + d).toFixed(2))); lsSet('bm_zoom', S.zoom); aplicarZoom(); }

  // ------------------------------------------------------------ exportar
  function chaveNomeCliente() {
    const chaves = ((S.atual && S.atual.campos) || []).map((c) => c.chave);
    return chaves.find((k) => k === 'cliente_nome') || chaves.find((k) => /_nome$/.test(k) && !/testemunha|rep_|assinante/.test(k));
  }
  function nomeCliente() {
    const k = chaveNomeCliente(); const v = k && S.valores[k];
    return v && String(v).trim() ? DOC.tituloPt(String(v).trim()) : '';
  }
  function desenharClienteAtual() {
    const box = $('#cliAtual'); if (!box || !S.atual) return;
    const quem = nomeCliente();
    const k = chaveNomeCliente(); const pre = k ? k.replace(/nome$/, '') : 'cliente_';
    const cpf = S.valores[pre + 'cpf'] || '';
    box.classList.toggle('vazio', !quem);
    box.innerHTML = `<span class="ca-ico">👤</span><div class="ca-txt"><small>ATENDENDO</small>
      <b>${quem ? esc(quem) : 'Cliente ainda não informado'}</b>${cpf ? `<span>CPF ${esc(cpf)}</span>` : ''}</div>
      <div class="ca-acoes">${quem
        ? '<button class="bt bt-cinza bt-mini" onclick="App.salvarCliente()" title="Guarda os dados deste cliente para usar de novo depois">💾 Salvar</button><button class="bt bt-cinza bt-mini" onclick="App.novoCliente()" title="Apaga os dados do formulário para atender outra pessoa">Novo cliente</button>'
        : '<button class="bt bt-cinza bt-mini" onclick="App.abrirClientes()" title="Preencher com um cliente que já foi salvo">👥 Cliente salvo</button>'}</div>`;
  }
  async function novoCliente() {
    const quem = nomeCliente();
    if (quem && !await confirmar('Novo cliente', `Apagar os dados de <b>${esc(quem)}</b> do formulário para atender outra pessoa? (Se quiser guardar, use 💾 Salvar cliente antes.)`, 'Novo cliente')) return;
    S.ajustes = {};
    S.valores = {}; lsSet('bm_valores', {}); $('#clienteBusca').value = ''; $('#clienteInfo').textContent = 'buscar ou salvar dados';
    await abrirModelo(S.atual.id);
    toast('Formulário limpo para o próximo cliente.');
  }
  function nomeArquivo() {
    const quem = nomeCliente();
    const ativos = itensAtivos();
    const base = S.atual.tipo === 'kit' && ativos.length < S.atual.itens.length
      ? (ativos.length === 1 ? ativos[0].nome : S.atual.nome + ' (' + ativos.length + ' docs)') : S.atual.nome;
    if (S.branco) return base + ' - em branco' + (S.branco.manterDados && quem ? ' - ' + quem : '');
    return base + (quem ? ' - ' + quem : '');
  }
  async function paginasFinais() {
    const med = $('#medidor');
    await DOC.paginar(med, itensParaRender('final'));
    const html = med.innerHTML; med.innerHTML = '';
    return html;
  }
  function avisarVazios() {
    if (S.branco) return 0;
    const faltam = camposAtivos().filter((c) => c.tipo !== 'caixa' && (S.valores[c.chave] === undefined || String(S.valores[c.chave]).trim() === ''));
    return faltam.length;
  }
  function toastArquivo(r, tipo) {
    if (S.bib && r.copia) S.bib.gerados_mes = (S.bib.gerados_mes || 0) + 1;
    toast(`<b>${tipo} salvo</b> em Downloads:<br>${esc(r.nome)}${r.copia ? `<br><small style="opacity:.75">Cópia guardada em Documentos Gerados › ${esc(r.copia_pasta || '')}.</small>` : ''}`, {
      acoes: [['Abrir', () => api('api/abrir', { json: { caminho: r.caminho } })], ['Mostrar na pasta', () => api('api/abrir', { json: { caminho: r.caminho, revelar: true } }), true]],
    });
  }
  async function exportar(tipo) {
    const faltam = avisarVazios();
    const nome = nomeArquivo();
    try {
      if (tipo === 'docx') {
        const itens = itensParaRender('final');
        if (itens.some((it) => it.paginas || it.lhBranco)) {      // mede o tamanho da letra que coube em cada campo
          await DOC.paginar($('#medidor'), itens); $('#medidor').innerHTML = '';
          itens.forEach((it) => (it.paginas || []).forEach((pg) => pg.caixas.forEach((c) => {
            if (c.tamFinal) c.tam = c.tamFinal; if (c.lh && c.lhFinal) c.lh = c.lhFinal; })));
        }
        const r = await api('api/exportar/docx', { json: { nome, itens, cliente: nomeCliente() } });
        toastArquivo(r, 'Word');
        registrarDoc();
      } else {
        toast('<span class="carregando"></span> Gerando PDF…', { tempo: 2500 });
        const r = await api('api/exportar/pdf', { json: { nome, paginas: await paginasFinais(), cliente: nomeCliente() } });
        toastArquivo(r, 'PDF');
        registrarDoc();
      }
      if (faltam) toast(`Atenção: ${faltam} campo(s) ficaram em branco e saíram com linha para preencher à mão.`, { tempo: 6000 });
    } catch (e) {
      if (e.status === 409) { toast(esc(e.message), { erro: true, tempo: 8000 }); imprimirNavegador(); }
      else toast('Não consegui gerar: ' + esc(e.message), { erro: true });
    }
  }
  async function exportarSeparados() {
    const ativos = itensAtivos();
    if (ativos.length < 2) return exportar('pdf');
    const faltam = avisarVazios();
    try {
      toast(`<span class="carregando"></span> Gerando ${ativos.length} PDFs separados…`, { tempo: 4000 });
      const itens = itensParaRender('final'), med = $('#medidor'), docs = [];
      for (let i = 0; i < itens.length; i++) {
        await DOC.paginar(med, [itens[i]]);
        docs.push({ nome: ativos[i].nome, paginas: med.innerHTML }); med.innerHTML = '';
      }
      const quem = nomeCliente();
      const pasta = S.atual.nome + (quem ? ' - ' + quem : '');
      const hoje = new Date(); const dt = String(hoje.getDate()).padStart(2, '0') + '-' + String(hoje.getMonth() + 1).padStart(2, '0') + '-' + hoje.getFullYear();
      const r = await api('api/exportar/pdf-separados', { json: { pasta, pasta_copia: quem ? S.atual.nome + ' (' + dt + ')' : '', cliente: quem, docs } });
      if (S.bib) S.bib.gerados_mes = (S.bib.gerados_mes || 0) + docs.length;
      toast(`<b>${docs.length} PDFs salvos</b> em Downloads › ${esc(pasta)}:<br><small>${r.arquivos.map(esc).join('<br>')}</small>`, {
        tempo: 12000, acoes: [['Abrir pasta', () => api('api/abrir', { json: { caminho: r.pasta } })]] });
      if (faltam) toast(`Atenção: ${faltam} campo(s) ficaram em branco e saíram com linha para preencher à mão.`, { tempo: 6000 });
    } catch (e) { toast('Não consegui gerar: ' + esc(e.message), { erro: true }); }
  }
  async function imprimir() {
    if (WIN) { registrarDoc(); return imprimirNavegador(); }   // Windows: abre a janela de impressão (impressora, cópias, páginas)
    if (S.bib.janela) {
      try {
        toast('<span class="carregando"></span> Preparando impressão…', { tempo: 2500 });
        await api('api/exportar/pdf', { json: { nome: nomeArquivo(), paginas: await paginasFinais(), imprimir: true, cliente: nomeCliente() } });
        registrarDoc();
        toast(WIN ? 'O documento abriu para imprimir (se a janela de impressão não aparecer, use Ctrl+P).' : 'O documento abriu no Pré-Visualização com a janela de impressão.');
        return;
      } catch (e) { /* cai para o navegador */ }
    }
    imprimirNavegador();
  }
  async function imprimirNavegador() {
    const html = await paginasFinais();
    const alvo = $('#previa'), antes = alvo.innerHTML, z = alvo.style.zoom;
    alvo.innerHTML = html; alvo.style.zoom = 1;
    $('#previaRolagem').classList.remove('modo-previa');
    const volta = () => { alvo.innerHTML = antes; alvo.style.zoom = z; $('#previaRolagem').classList.add('modo-previa'); window.removeEventListener('afterprint', volta); };
    window.addEventListener('afterprint', volta);
    setTimeout(() => { window.print(); setTimeout(() => { if (alvo.innerHTML === html) volta(); }, WIN ? 120000 : 1500); }, 250);
  }

  // ------------------------------------------------------------ clientes
  async function carregarDatalistClientes() {
    try {
      const d = await api('api/clientes'); S.clientes = d.clientes;
      $('#dlClientes').innerHTML = d.clientes.map((c) => `<option value="${esc(c.nome)}">`).join('');
    } catch (e) { /* ok */ }
  }
  function carregarCliente(nome) {
    const c = (S.clientes || []).find((x) => x.nome === nome);
    if (!c) return;
    Object.assign(S.valores, c.dados);
    $('#clienteInfo').textContent = c.nome;
    montarForm(); renderPrevia();
    toast(`Dados de <b>${esc(c.nome)}</b> carregados.`);
  }
  function fotoDoc() {   // o documento aberto, com tudo o que foi digitado, para abrir de novo depois
    if (!S.atual) return null;
    const valores = {}; for (const k in S.valores) if (k !== 'data_documento') valores[k] = S.valores[k];
    return { modelo: S.atual.id, nome: S.atual.nome, valores, ajustes: S.ajustes || {},
      kit_on: S.atual.tipo === 'kit' && S.kitSel ? S.kitSel.on : null };
  }
  async function registrarDoc() {   // ao gerar Word/PDF/imprimir: se o cliente já está salvo, guarda o documento nele
    try {
      const quem = nomeCliente(); if (!quem || !S.atual || S.branco) return;
      if (!S.clientes) await carregarDatalistClientes();
      const c = (S.clientes || []).find((x) => x.nome.trim().toLowerCase() === quem.trim().toLowerCase());
      if (!c) return;
      await api('api/clientes', { json: { id: c.id, nome: c.nome, dados: {}, doc: fotoDoc() } });
      carregarDatalistClientes();
    } catch (e) { /* ok */ }
  }
  async function salvarCliente() {
    const nome = (S.valores.cliente_nome || S.valores.prestador_nome || $('#clienteBusca').value || '').trim();
    const n = await perguntar('Salvar cliente', 'Nome do cliente', nome);
    if (!n) return;
    const dados = {};
    for (const k in S.valores) if (!/^(data_documento|local|valor|inss_|ficha_|marcar_|tipo_pagamento)/.test(k)) dados[k] = S.valores[k];
    await api('api/clientes', { json: { nome: n, dados, doc: fotoDoc() } });
    $('#clienteBusca').value = n; $('#clienteInfo').textContent = n;
    carregarDatalistClientes();
    toast(`Cliente <b>${esc(n)}</b> salvo${S.atual ? `, com o documento <b>${esc(S.atual.nome)}</b>` : ''}. Em 👥 Clientes, toque no nome para abrir de novo.`);
  }

  // ------------------------------------------------------------ ler documentos (OCR com o Gemini)
  async function lerDocumentos(lista) {
    const arqs = Array.from(lista || []);
    if (!arqs.length) return;
    if (!S.atual) return toast('Abra um modelo antes de ler os documentos.', { erro: true });
    modal(cabModal('Lendo documentos') + `<div class="m-corpo ocr-lendo"><div class="giro"></div>
      <b>Lendo ${arqs.length} arquivo${arqs.length > 1 ? 's' : ''}…</b><p class="dica">${arqs.map((f) => esc(f.name)).join(' · ')}</p></div>`);
    const fd = new FormData(); arqs.forEach((f) => fd.append('arquivos', f, f.name));
    let r;
    try { r = await api('api/ler-documentos', { method: 'POST', body: fd }); }
    catch (e) { fecharModal(); return toast(esc(e.message), { erro: true, tempo: 9000 }); }
    mostrarOcr(r);
  }
  function mostrarOcr(r) {
    if (!r.campos.length) { fecharModal(); return toast('Não encontrei dados legíveis nesses arquivos. Tente uma foto mais nítida, sem reflexo.', { erro: true, tempo: 8000 }); }
    const ativos = new Set(camposAtivos().map((c) => c.chave));
    r.campos.forEach((c) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(c.valor); if (m) c.valor = `${m[3]}/${m[2]}/${m[1]}`; });
    S.ocr = r.campos;
    const linhas = r.campos.map((c, i) => {
      const atual = S.valores[c.chave];
      const ja = atual && String(atual).trim() && dataBR(String(atual).trim()) !== c.valor;
      const nota = !ativos.has(c.chave) ? 'não aparece neste modelo (fica salvo no cliente)' : ja ? 'substitui: ' + esc(String(atual)) : '';
      return `<tr class="${ja ? 'atual' : ''}"><td><input type="checkbox" id="ocrOn${i}" checked></td>
        <td class="rot">${esc(c.rotulo)}${nota ? `<small>${nota}</small>` : ''}</td>
        <td><input type="text" id="ocrV${i}" value="${esc(c.valor)}"></td></tr>`;
    }).join('');
    modal(cabModal('Dados lidos dos documentos') + `<div class="m-corpo">
      ${r.documentos.length ? `<div class="ocr-docs">${r.documentos.map((d) => `<span>${esc(d)}</span>`).join('')}</div>` : ''}
      ${r.avisos.map((a) => `<div class="ocr-aviso">⚠️ ${esc(a)}</div>`).join('')}
      <p class="dica">Confira antes de usar — a leitura é automática. Desmarque o que não quiser preencher.</p>
      <table class="ocr-tab">${linhas}</table>
      ${(r.texto || []).length ? `<details class="ocr-texto"${r.campos.some((c) => c.chave === 'cliente_nome') ? '' : ' open'}><summary>Texto que o computador leu</summary><pre>${esc(r.texto.join('\n'))}</pre></details>` : ''}</div>
      <div class="m-pe"><button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button>
      <button class="bt bt-ouro" onclick="App.aplicarOcr()">Preencher formulário</button></div>`, true);
  }

  // ---- ajustar o texto só deste documento (o modelo continua igual)
  // ---- kit em branco, para imprimir e preencher à mão depois
  const RE_DO_CLIENTE = /^(cliente_|rep_|testemunha|prestador_|ficha_polo|marcar_|inss_)/;
  function valoresBranco() {
    const v = {};
    (S.atual.campos || []).forEach((c) => {
      const val = S.valores[c.chave];
      if (c.chave === 'data_documento') return;                      // data: escreve na hora da assinatura
      if (RE_DO_CLIENTE.test(c.chave) || c.em_branco === 'vazio') {
        if (S.branco.manterDados && val !== undefined && String(val).trim() !== '' && String(val) !== String(c.padrao ?? '')) v[c.chave] = val;
        return;
      }
      if (val !== undefined) v[c.chave] = val;                          // dados do escritório e do documento continuam
    });
    return v;
  }
  // em branco: a qualificação corrida do contrato vira linhas livres; procuração ganha o quadro do representante legal
  const LINHA_B = '<tr><td style="border-bottom:0.6pt solid #000000;padding:0;height:17pt;font-size:12pt">&nbsp;</td></tr>';
  const linhasQualif = (n) => '<p style="margin:0 0 1pt;font-size:7.5pt;color:#808080;line-height:1.2">Nome, nacionalidade, estado civil, profissão, RG, CPF e endereço completo com CEP:</p>' +
    '<table class="sem-margem br-qualif" style="margin:0"><tbody>' + LINHA_B.repeat(n) + '</tbody></table>';
  // em branco: embaixo da assinatura fica só a função (CONTRATANTE, OUTORGANTE, TESTEMUNHA), sem linha para o nome
  function semNomeNaAssinatura(raiz) {
    raiz.querySelectorAll('.assinatura, .assinatura-esq').forEach((el) => {
      el.querySelectorAll('[data-se]').forEach((x) => { if (/_nome$/.test(x.getAttribute('data-se'))) x.remove(); });
      el.innerHTML = el.innerHTML.replace(/(<br>\s*)?(<b>\s*)?\{\{\s*\w+_nome\s*\}\}(\s*<\/b>)?/g, '').replace(/^(\s*<br>)+/, '');
    });
  }
  function rodapeEmBranco(html) {
    const t = document.createElement('template'); t.innerHTML = html || '';
    t.content.querySelectorAll('[data-se="rep_nome"]').forEach((x) => x.remove());
    return t.innerHTML.replace(/\{\{\s*cliente_nome\s*\}\}/g, '');
  }
  function modeloEmBranco(it, valores) {
    const t = document.createElement('template'); t.innerHTML = it.html || '';
    // qualificação corrida (o parágrafo começa com o nome do cliente e traz os outros dados dele) -> linhas livres
    t.content.querySelectorAll('p').forEach((p) => {
      if (p.closest('table.grade') || p.closest('.assinatura, .assinatura-esq')) return;
      const txt = p.textContent.trim();
      if (!/^\{\{\s*cliente_nome\s*\}\}/.test(txt)) return;
      if ((p.innerHTML.match(/\{\{\s*cliente_(?!nome)\w+/g) || []).length < 2) return;
      const d = document.createElement('div'); d.innerHTML = linhasQualif(5);
      p.replaceWith(...d.childNodes);
    });
    // quadro com linhas (procuração em quadro, fichas): a própria linha do quadro serve para escrever — sem "____" na frente
    t.content.querySelectorAll('table.grade td').forEach((td) => {
      const toks = (td.innerHTML.match(/\{\{\s*([\w]+)[^}]*\}\}/g) || []).map((x) => x.replace(/\{\{\s*([\w]+).*/, '$1'));
      if (!toks.length || toks.some((k) => valores[k] !== undefined && String(valores[k]).trim() !== '')) return;
      if (/\(\s*\{\{/.test(td.innerHTML) || toks.some((k) => /^(marcar_|inss_)/.test(k))) return;   // caixinha "( ) Autor": fica como está
      const rots = Array.from(td.querySelectorAll('.rot')).map((x) => x.outerHTML).join('');
      const quebra = /<br>/i.test(td.innerHTML.split('{{')[0]) ? '<br>' : ' ';
      td.innerHTML = (rots ? rots + quebra : '') + '&nbsp;';
    });
    // tabela com bordas (recibos, formulários): a própria célula é o espaço para escrever
    t.content.querySelectorAll('td').forEach((td) => {
      if (td.closest('table.grade') || !/border/.test(td.getAttribute('style') || '')) return;
      td.innerHTML = td.innerHTML.replace(/\{\{\s*([\w]+)\s*(\|[^}]*)?\}\}/g, (m, k) =>
        (/^(marcar_|inss_)/.test(k) || (valores[k] !== undefined && String(valores[k]).trim() !== '')) ? m : '&nbsp;');
    });
    // procuração em quadro: a linha "REPRESENTADO(A) POR" fica com duas linhas do próprio quadro
    t.content.querySelectorAll('tr[data-se="rep_nome"]').forEach((tr) => {
      tr.removeAttribute('data-se');
      const n = Math.max(1, Array.from(tr.children).reduce((a, td) => a + (+td.getAttribute('colspan') || 1), 0));
      tr.innerHTML = `<td colspan="${n}"><span class="rot">REPRESENTADO(A) POR (se houver):</span>&nbsp;</td>`;
      const tr2 = document.createElement('tr'); tr2.innerHTML = `<td colspan="${n}" style="height:15pt">&nbsp;</td>`;
      tr.after(tr2);
    });
    semNomeNaAssinatura(t.content);
    return t.innerHTML;
  }
  function linhasAltas(html) {   // em branco: parágrafo com linha para escrever ganha mais altura (cabe a letra de mão)
    const t = document.createElement('template'); t.innerHTML = html;
    t.content.querySelectorAll('p, div, li').forEach((el) => {
      if (el.closest('table.grade') || !el.querySelector('.cp.br') || el.querySelector('p, div, li')) return;
      el.style.lineHeight = '1.75'; el.style.textAlign = 'left';
    });
    return t.innerHTML;
  }
  function emBranco() {
    if (!S.atual) return;
    if (S.branco) { S.branco = null; desenharBarraBranco(); renderPrevia(); return; }
    const quem = nomeCliente();
    modal(cabModal('📄 Imprimir em branco') + `<div class="m-corpo">
      <p>O documento sai com <b>linhas para preencher à mão</b>: todos os dados do cliente ficam em branco, com espaço para escrever, e a data fica para escrever na hora da assinatura.</p>
      <p class="dica">Os modelos importados de PDF saem como o PDF original, com as linhas dele.</p>
      ${quem ? `<label class="chk-linha"><input type="checkbox" id="brManter"> Manter os dados já digitados (<b>${esc(quem)}</b>) e deixar em branco só o resto</label>` : ''}
      </div><div class="m-pe"><button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button>
      <button class="bt bt-ouro" onclick="App.confirmarBranco()">Ver em branco</button></div>`);
  }
  function confirmarBranco() {
    S.branco = { comRep: false, manterDados: !!($('#brManter') && $('#brManter').checked) };
    fecharModal(); desenharBarraBranco(); renderPrevia();
  }
  function desenharBarraBranco() {
    let el = $('#brancoBarra');
    if (!el) { el = document.createElement('div'); el.id = 'brancoBarra'; el.className = 'branco-barra'; $('#previaRolagem').before(el); }
    el.hidden = !S.branco;
    el.innerHTML = S.branco ? `<span>📄 <b>Em branco</b> — para imprimir e preencher à mão. Word, PDF e Imprimir saem assim.</span>
      <button class="bt bt-cinza bt-mini" onclick="App.emBranco()">Voltar ao preenchimento</button>` : '';
  }
  function chaveItem(it) { return String(S.atual.itens.indexOf(it)); }
  function caixaExtra(e, fonte) {
    const html = e.apagar ? '' : esc(e.texto || '').replace(/\n/g, '<br>');
    return { pagina: e.pagina, x: e.x, y: e.y, w: e.w, h: e.h, tam: e.tam || 11, alinhar: 'esquerda', cobrir: true, fundo: '#FFFFFF',
      negrito: !!e.negrito, fonte, lh: null, texto: '', html, origem: 'ajuste' };
  }
  function desenharAvisoAjuste() {
    let el = $('#ajAviso');
    if (!el) { el = document.createElement('div'); el.id = 'ajAviso'; el.className = 'aj-aviso'; $('#cliAtual').after(el); }
    const its = itensAtivos().filter((it) => S.ajustes[chaveItem(it)]);
    el.hidden = !its.length;
    if (!its.length) { el.innerHTML = ''; return; }
    const html = its.some((it) => S.ajustes[chaveItem(it)].html != null);
    el.innerHTML = `<b>📝 Texto ajustado à mão</b>${S.atual.tipo === 'kit' ? ' em: ' + its.map((it) => esc(it.nome)).join(', ') : ''}.
      <small>${html ? 'Vale só para este documento. O que você mudar no formulário agora não entra no texto ajustado — ajuste de novo ou desfaça.' : 'Vale só para este documento; o modelo continua igual.'}</small>
      <div><button class="bt bt-cinza bt-p" onclick="App.ajustarTexto()">Editar ajuste</button>
      <button class="bt bt-cinza bt-p" onclick="App.desfazerAjustes()">Desfazer ajustes</button></div>`;
  }
  async function desfazerAjustes(idx) {
    if (!await confirmar('Desfazer ajustes', 'Voltar o texto ao original do modelo (com os dados do formulário)?', 'Desfazer')) return;
    if (idx === undefined) S.ajustes = {}; else delete S.ajustes[String(idx)];
    fecharModal(); renderPrevia();
  }
  function ajustarTexto() {
    if (!S.atual) return;
    const its = itensAtivos();
    if (its.length === 1) return abrirAjuste(S.atual.itens.indexOf(its[0]));
    modal(cabModal('📝 Ajustar texto') + `<div class="m-corpo"><p>Qual documento você quer ajustar?</p><div class="aj-lista">
      ${its.map((it) => `<button class="bt bt-cinza" onclick="App.abrirAjuste(${S.atual.itens.indexOf(it)})">${esc(it.nome)}${S.ajustes[chaveItem(it)] ? ' <small>· ajustado</small>' : ''}</button>`).join('')}
      </div></div>`);
  }
  const AJ = {};
  async function abrirAjuste(idx) {
    const it = S.atual.itens[idx], k = String(idx), aj = S.ajustes[k] || {};
    AJ.idx = idx;
    if (it.formato === 'paginas') return abrirAjustePaginas(it, aj);
    const html = aj.html != null ? aj.html : DOC.render(it.html, S.atual.campos, S.valores, { modo: 'final', genero: it.genero, maiusculas: it.valores_maiusculos });
    modal(cabModal('📝 Ajustar texto — ' + esc(it.nome)) + `<div class="m-corpo aj-corpo">
      <div class="aj-barra">
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('bold')" title="Negrito"><b>N</b></button>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('italic')" title="Itálico"><i>I</i></button>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('underline')" title="Sublinhado"><u>S</u></button>
        <span class="sep"></span>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('justifyLeft')" title="Alinhar à esquerda">⇤</button>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('justifyCenter')" title="Centralizar">↔</button>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('justifyFull')" title="Justificar">☰</button>
        <span class="sep"></span>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('undo')" title="Desfazer (Ctrl/⌘+Z)">↶</button>
        <button onmousedown="event.preventDefault()" onclick="App.ajCmd('redo')" title="Refazer">↷</button>
        <span class="aj-dica">Clique no texto e edite como num editor normal: apague, acrescente, negrite…</span>
      </div>
      <div class="aj-papel"><div class="conteudo doc" id="ajTexto" contenteditable="true" spellcheck="true"
        style="--fonte:${esc(DOC.pilhaFonte(it.fonte))};--tam:${it.tamanho || 12}pt;--esp:${it.espacamento || 1.4}">${html}</div></div></div>
      <div class="m-pe">${aj.html != null ? `<button class="bt bt-cinza" style="margin-right:auto" onclick="App.desfazerAjustes(${idx})">Voltar ao original</button>` : ''}
        <button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button>
        <button class="bt bt-ouro" onclick="App.salvarAjuste()">Usar este texto</button></div>`, true);
    $('#modalCaixa').classList.add('aj');
    const ed = $('#ajTexto');
    try { document.execCommand('styleWithCSS', false, false); } catch (e) { /* ok */ }
    ed.addEventListener('paste', (e) => { e.preventDefault(); document.execCommand('insertText', false, (e.clipboardData || window.clipboardData).getData('text/plain')); });
    ed.focus();
  }
  function ajCmd(c) { const ed = $('#ajTexto'); if (ed) ed.focus(); document.execCommand(c, false, null); }
  function salvarAjuste() {
    const k = String(AJ.idx);
    if ($('#ajTexto')) {
      S.ajustes[k] = { html: $('#ajTexto').innerHTML };
    } else {
      const extras = AJ.extras.filter((e) => e.apagar || (e.texto || '').trim());
      if (extras.length) S.ajustes[k] = { extras }; else delete S.ajustes[k];
    }
    fecharModal(); renderPrevia();
    toast('Texto ajustado. Vale só para este documento — o modelo continua igual.');
  }

  // modelo "PDF original": o texto é imagem — dá para apagar trechos e escrever por cima
  async function abrirAjustePaginas(it, aj) {
    AJ.extras = JSON.parse(JSON.stringify(aj.extras || [])); AJ.ferr = 'escrever'; AJ.sel = null;
    modal(cabModal('📝 Ajustar texto — ' + esc(it.nome)) + `<div class="m-corpo aj-corpo">
      <div class="aj-barra">
        <button id="ajF_escrever" onclick="App.ajFerramenta('escrever')" class="on">✍️ Escrever por cima</button>
        <button id="ajF_apagar" onclick="App.ajFerramenta('apagar')">⬜ Apagar trecho</button>
        <span class="sep"></span>
        <button onclick="App.ajNegrito()" title="Negrito no quadro selecionado"><b>N</b></button>
        <button onclick="App.ajTam(-0.5)" title="Letra menor">A−</button><button onclick="App.ajTam(0.5)" title="Letra maior">A+</button>
        <button onclick="App.ajExcluir()" title="Excluir o quadro selecionado">🗑</button>
        <span class="aj-dica">Arraste sobre a página para marcar a área. Em "Escrever", digite o texto novo no quadro (ele cobre o que estava embaixo).</span>
      </div>
      <div class="aj-paginas" id="ajPaginas"></div></div>
      <div class="m-pe">${aj.extras ? `<button class="bt bt-cinza" style="margin-right:auto" onclick="App.desfazerAjustes(${AJ.idx})">Voltar ao original</button>` : ''}
        <button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button>
        <button class="bt bt-ouro" onclick="App.salvarAjuste()">Usar este texto</button></div>`, true);
    $('#modalCaixa').classList.add('aj');
    // a página como está agora (com os dados do formulário), sem os ajustes — eles ficam numa camada por cima
    const salvo = S.ajustes[String(AJ.idx)]; delete S.ajustes[String(AJ.idx)];
    const todos = itensParaRender('final'); if (salvo) S.ajustes[String(AJ.idx)] = salvo;
    const meu = todos[itensAtivos().indexOf(it)];
    const alvo = $('#ajPaginas');
    const pgs = await DOC.paginar(alvo, [meu]);
    pgs.forEach((pg, i) => {
      const cam = document.createElement('div'); cam.className = 'aj-camada'; cam.dataset.pg = i;
      pg.appendChild(cam);
      ligarDesenho(cam, i, (meu.paginas[i] || {}).w || 595.3);
    });
    desenharExtras();
  }
  function ajFerramenta(f) { AJ.ferr = f; ['escrever', 'apagar'].forEach((x) => $('#ajF_' + x).classList.toggle('on', x === f)); }
  function ligarDesenho(cam, pagina, wpt) {
    cam.addEventListener('mousedown', (e) => {
      if (e.target !== cam) return;
      e.preventDefault();
      const r = cam.getBoundingClientRect(), k = r.width / wpt;
      const x0 = (e.clientX - r.left) / k, y0 = (e.clientY - r.top) / k;
      const nova = { pagina, x: x0, y: y0, w: 1, h: 1, tam: 11, negrito: false, apagar: AJ.ferr === 'apagar', texto: '' };
      AJ.extras.push(nova); AJ.sel = nova;
      const mover = (ev) => {
        const x1 = (ev.clientX - r.left) / k, y1 = (ev.clientY - r.top) / k;
        nova.x = Math.min(x0, x1); nova.y = Math.min(y0, y1); nova.w = Math.abs(x1 - x0); nova.h = Math.abs(y1 - y0);
        desenharExtras();
      };
      const soltar = () => {
        document.removeEventListener('mousemove', mover); document.removeEventListener('mouseup', soltar);
        if (nova.w < 6 || nova.h < 6) {        // só um clique: quadro de uma linha a partir dali
          if (nova.apagar) { AJ.extras.splice(AJ.extras.indexOf(nova), 1); AJ.sel = null; desenharExtras(); return; }
          nova.w = 200; nova.h = 15;
        }
        nova.tam = Math.max(7, Math.min(12, +(nova.h * 0.72).toFixed(1)));
        if (nova.h > 22) nova.tam = 11;
        desenharExtras();
        const ed = $(`.aj-extra[data-i="${AJ.extras.indexOf(nova)}"] .aj-txt`);
        if (ed) ed.focus();
      };
      document.addEventListener('mousemove', mover); document.addEventListener('mouseup', soltar);
    });
  }
  function desenharExtras() {
    $$('.aj-camada').forEach((cam) => {
      const pg = +cam.dataset.pg, k = cam.getBoundingClientRect().width / (+cam.dataset.w || 0) || null;
      cam.innerHTML = '';
      AJ.extras.forEach((e, i) => {
        if (e.pagina !== pg) return;
        const d = document.createElement('div');
        d.className = 'aj-extra' + (e.apagar ? ' apagar' : '') + (AJ.sel === e ? ' sel' : '');
        d.dataset.i = i;
        const PT = 25.4 / 72;
        d.style.left = (e.x * PT) + 'mm'; d.style.top = (e.y * PT) + 'mm'; d.style.width = (e.w * PT) + 'mm'; d.style.height = (e.h * PT) + 'mm';
        if (!e.apagar) {
          const t = document.createElement('div'); t.className = 'aj-txt'; t.contentEditable = 'true'; t.spellcheck = true;
          t.style.fontSize = e.tam + 'pt'; t.style.fontWeight = e.negrito ? 'bold' : 'normal';
          t.innerText = e.texto || '';
          t.addEventListener('input', () => { e.texto = t.innerText; });
          t.addEventListener('focus', () => { AJ.sel = e; $$('.aj-extra.sel').forEach((x) => x.classList.remove('sel')); d.classList.add('sel'); });
          d.appendChild(t);
        }
        d.addEventListener('mousedown', (ev) => { if (ev.target === d) { AJ.sel = e; $$('.aj-extra.sel').forEach((x) => x.classList.remove('sel')); d.classList.add('sel'); } });
        cam.appendChild(d);
      });
    });
  }
  function ajNegrito() { if (AJ.sel && !AJ.sel.apagar) { AJ.sel.negrito = !AJ.sel.negrito; desenharExtras(); } }
  function ajTam(d) { if (AJ.sel && !AJ.sel.apagar) { AJ.sel.tam = Math.max(6, Math.min(20, AJ.sel.tam + d)); desenharExtras(); } }
  function ajExcluir() { if (AJ.sel) { AJ.extras.splice(AJ.extras.indexOf(AJ.sel), 1); AJ.sel = null; desenharExtras(); } }
  // ---- escolher de onde vêm os documentos: arquivos do computador ou câmera do celular (QR code)
  function escolherLeitura() {
    if (!S.atual) return toast('Abra um modelo antes de ler os documentos.', { erro: true });
    modal(cabModal('Ler documentos do cliente') + `<div class="m-corpo"><div class="ocr-opcoes">
      <button class="ocr-op" onclick="App.fecharModal(); document.getElementById('arqOcr').click()"><span>💻</span><b>Arquivos do computador</b><small>Fotos ou PDFs que já estão ${WIN ? 'no computador' : 'no Mac'} (pode escolher vários)</small></button>
      <button class="ocr-op" onclick="App.lerPeloCelular()"><span>📱</span><b>Tirar foto com o celular</b><small>Aparece um QR code: aponte a câmera do celular e fotografe os documentos</small></button>
      </div></div>`);
  }
  let tCel = null;
  async function lerPeloCelular() {
    let r;
    try { r = await api('api/celular/novo', { method: 'POST' }); }
    catch (e) { return toast(esc(e.message), { erro: true, tempo: 8000 }); }
    const qr = qrcode(0, 'M'); qr.addData(r.url); qr.make();
    modal(cabModal('📱 Fotografar com o celular') + `<div class="m-corpo cel-qr">
      <div class="qr">${qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true })}</div>
      <ol><li>Abra a <b>câmera do celular</b> e aponte para o código.</li>
        <li>Toque no link que aparecer e tire <b>até 3 fotos</b>: RG/CNH (frente e verso) e comprovante de residência.</li>
        <li>Toque em <b>Enviar para o computador</b>. A leitura começa sozinha aqui.</li></ol>
      <p class="dica">O celular precisa estar no <b>mesmo Wi-Fi</b> deste computador. O código vale por 20 minutos.</p>
      <div class="cel-estado" id="celEstado"><span class="carregando"></span> Aguardando o celular…</div></div>
      <div class="m-pe"><button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button></div>`);
    clearInterval(tCel);
    tCel = setInterval(async () => {
      if ($('#modal').hidden || !$('#celEstado')) { clearInterval(tCel); return; }
      let e; try { e = await api(`api/celular/${r.token}/estado`); } catch (x) { clearInterval(tCel); $('#celEstado').textContent = x.message; return; }
      if (e.visto && !e.pronto) $('#celEstado').innerHTML = '<span class="carregando"></span> Celular conectado. Tire as fotos e toque em <b>Enviar</b>.';
      if (e.pronto) {
        clearInterval(tCel);
        $('#celEstado').innerHTML = `<span class="carregando"></span> ${e.n} foto${e.n > 1 ? 's' : ''} recebida${e.n > 1 ? 's' : ''}. Lendo os documentos…`;
        let res; try { res = await api(`api/celular/${r.token}/ler`, { method: 'POST' }); }
        catch (x) { fecharModal(); return toast(esc(x.message), { erro: true, tempo: 9000 }); }
        mostrarOcr(res);
      }
    }, 1500);
  }
  function aplicarOcr() {
    let n = 0;
    (S.ocr || []).forEach((c, i) => {
      if (!$('#ocrOn' + i).checked) return;
      let v = $('#ocrV' + i).value.trim();
      const d = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(v); if (d) v = `${d[3]}-${d[2]}-${d[1]}`;
      if (v) { S.valores[c.chave] = v; n++; }
    });
    fecharModal(); montarForm(); renderPrevia();
    toast(`${n} campo${n === 1 ? '' : 's'} preenchido${n === 1 ? '' : 's'} a partir dos documentos.`, { acoes: [['💾 Salvar cliente', salvarCliente]] });
  }
  (function ligarOcr() {
    const box = document.getElementById('ocrBox'); if (!box) return;
    box.addEventListener('dragover', (e) => { e.preventDefault(); box.classList.add('sobre'); });
    box.addEventListener('dragleave', () => box.classList.remove('sobre'));
    box.addEventListener('drop', (e) => { e.preventDefault(); box.classList.remove('sobre'); lerDocumentos(e.dataTransfer.files); });
  })();
  async function abrirClientes() {
    const d = await api('api/clientes'); S.clientes = d.clientes;
    const lista = () => S.clientes.map((c) => `<div class="lcli"><button class="lcli-nome" onclick="App.escolherCliente('${c.id}')"><b>${esc(c.nome)}</b>
      <small>${esc(c.dados.cliente_cpf || '')}${(c.docs || []).length ? ` · 📄 ${c.docs.length} documento${c.docs.length > 1 ? 's' : ''} salvo${c.docs.length > 1 ? 's' : ''}` : ''}</small></button>
      <button class="bt bt-cinza bt-mini" onclick="App.escolherCliente('${c.id}')">Abrir</button>
      <button class="bt bt-perigo bt-mini" onclick="App.excluirCliente('${c.id}')">Excluir</button></div>`).join('') || '<p class="dica" style="padding:14px">Nenhum cliente salvo ainda. No formulário, use o botão 💾 para salvar.</p>';
    modal(cabModal('Clientes salvos') + `<div class="m-corpo"><p class="dica" style="margin-bottom:10px">Os dados de cada cliente ficam salvos no seu computador para reaproveitar em qualquer modelo.</p>
      <div class="lista-cli" id="listaCli">${lista()}</div></div>`);
  }
  function escolherCliente(id) {
    const c = S.clientes.find((x) => x.id === id);
    if (!c) return;
    const docs = c.docs || [];
    if (!docs.length) return usarCliente(id);
    const quando = (iso) => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString('pt-BR'); };
    const existe = (mid) => (S.bib.modelos || []).some((m) => m.id === mid);
    modal(cabModal(esc(c.nome)) + `<div class="m-corpo">
      <p class="dica" style="margin-bottom:10px">Abrir um documento salvo deste cliente (com tudo o que foi preenchido) ou usar só os dados dele em outro documento?</p>
      <div class="cli-docs">${docs.map((d, i) => `<div class="cli-doc">
        <button class="cli-doc-abrir" ${existe(d.modelo) ? '' : 'disabled title="Esse modelo foi apagado da biblioteca"'} onclick="App.abrirDocCliente('${c.id}', ${i})">
          <span>📄</span><b>${esc(d.nome || d.modelo)}</b><small>salvo em ${quando(d.salvo)}${Object.keys(d.ajustes || {}).length ? ' · com texto ajustado' : ''}</small></button>
        <button class="x" title="Tirar da lista" onclick="App.excluirDocCliente('${c.id}', '${esc(d.modelo)}')">×</button></div>`).join('')}</div>
      </div><div class="m-pe"><button class="bt bt-cinza" onclick="App.abrirClientes()">‹ Voltar</button>
      <button class="bt bt-ouro" onclick="App.usarCliente('${c.id}')">Usar os dados em outro documento</button></div>`);
  }
  async function abrirDocCliente(id, i) {
    const c = S.clientes.find((x) => x.id === id), d = c && (c.docs || [])[i];
    if (!d) return;
    fecharModal();
    S.valores = { ...c.dados, ...(d.valores || {}) };
    delete S.valores.data_documento;          // a data do documento volta a ser hoje
    salvarRascunho();
    S.ajustes = JSON.parse(JSON.stringify(d.ajustes || {})); S.ajustesDe = d.modelo;
    if (d.kit_on) S.kitSel = { id: d.modelo, on: d.kit_on };
    try { await abrirModelo(d.modelo); }
    catch (e) { return toast('Não encontrei esse modelo na biblioteca.', { erro: true }); }
    toast(`<b>${esc(d.nome)}</b> de <b>${esc(c.nome)}</b> aberto como foi salvo. A data do documento ficou a de hoje — confira os valores antes de gerar.`, { tempo: 7000 });
  }
  async function excluirDocCliente(id, modelo) {
    await api('api/clientes/' + id + '/doc?modelo=' + encodeURIComponent(modelo), { method: 'DELETE' });
    const c = S.clientes.find((x) => x.id === id); if (c) c.docs = (c.docs || []).filter((d) => d.modelo !== modelo);
    escolherCliente(id);
  }
  async function usarCliente(id) {
    const c = S.clientes.find((x) => x.id === id); fecharModal();
    Object.assign(S.valores, c.dados); salvarRascunho();
    if (S.atual && $('#v-preencher').classList.contains('ativa')) { montarForm(); renderPrevia(); }
    toast(`Dados de <b>${esc(c.nome)}</b> prontos. Abra qualquer modelo.`);
  }
  async function excluirCliente(id) {
    await api('api/clientes/' + id, { method: 'DELETE' });
    S.clientes = S.clientes.filter((c) => c.id !== id);
    abrirClientes();
  }

  // ------------------------------------------------------------ EDITOR
  function tokensParaChips(html, campos) {
    const mapa = {}; (campos || []).forEach((c) => { mapa[c.chave] = c; });
    return String(html || '')
      .replace(/\{\{\s*([^{}]+?)\s*\}\}/g, (m, expr) => {
        if (expr === 'pagina') return '{{pagina}}';
        const [k, f] = expr.split('|').map((s) => s.trim());
        const c = mapa[k];
        const rot = (c ? c.rotulo : k) + (f ? ' · ' + f : '');
        return `<span class="chip-campo" contenteditable="false" data-t="${esc(expr.replace(/\s/g, ''))}">${esc(rot)}</span>`;
      })
      .replace(/<div class="quebra-pagina"><\/div>/g, '<div class="quebra-pagina quebra-ed" contenteditable="false"></div>');
  }
  function chipsParaTokens(raiz) {
    const c = raiz.cloneNode(true);
    $$('.chip-campo', c).forEach((ch) => ch.replaceWith(document.createTextNode('{{' + ch.dataset.t + '}}')));
    $$('.quebra-ed', c).forEach((q) => { q.className = 'quebra-pagina'; q.removeAttribute('contenteditable'); q.innerHTML = ''; });
    $$('[contenteditable]', c).forEach((e) => e.removeAttribute('contenteditable'));
    $$('font', c).forEach((f) => f.replaceWith(...f.childNodes));
    let h = c.innerHTML.replace(/&nbsp;/g, '&nbsp;').replace(/<div><br><\/div>/g, '<p class="vazio">&nbsp;</p>');
    // div soltos criados pelo editor viram parágrafos
    h = h.replace(/<div>([\s\S]*?)<\/div>/g, (m, inner) => /<(p|div|table)/.test(inner) ? m : `<p>${inner}</p>`);
    return h;
  }

  async function abrirEditor(id, sugestao) {
    if (sugestao && sugestao.modo === 'paginas') { abrirEditorPaginas(null, sugestao); return; }
    if (!sugestao) {
      const dd = await api('api/modelo/' + encodeURIComponent(id));
      if (dd.modelo.formato === 'paginas') {
        const mm = dd.modelo; mm._paginasMeta = mm.paginas; abrirEditorPaginas(mm); S.pe.docs[0]._paginasMeta = mm.paginas; return;
      }
    }
    let m;
    if (sugestao) {
      m = { ...sugestao, tipo: 'modelo', timbrado: S.bib.config.timbrado_padrao };
      if (sugestao.timbrado_detectado && sugestao.timbrado_detectado.existente) m.timbrado = sugestao.timbrado_detectado.existente;
    } else {
      const d = await api('api/modelo/' + encodeURIComponent(id));
      m = d.modelo;
      if (m.tipo !== 'kit') { m.html = m.itens[0].html; }
    }
    S.ed = { m: JSON.parse(JSON.stringify(m)), importando: !!sugestao, voltar: $('.tela.ativa').id, abertos: {} };
    if (S.ed.importando) S.ed.timbOpcao = sugestao.timbrado_detectado ? (sugestao.timbrado_detectado.existente ? 'existente' : 'criar') : 'padrao';
    $('#edTitulo').textContent = sugestao ? 'REVISAR IMPORTAÇÃO' : (m.tipo === 'kit' ? 'EDITAR KIT' : 'EDITAR MODELO');
    $('#edSub').textContent = sugestao ? 'Confira o que o programa entendeu e salve' : 'Texto, campos e ficha do modelo';
    const aviso = $('#edAviso');
    if (sugestao) {
      const av = (sugestao.avisos || []).map((a) => `<br>⚠️ ${esc(a)}`).join('');
      aviso.innerHTML = `<b>${esc(sugestao.arquivo)}</b> foi lido${sugestao.usou_ia ? ' com ajuda da IA' : ''}: classifiquei na pasta <b>${esc(m.categoria)}</b>, área <b>${esc(m.area)}</b>,
        com o nome <b>${esc(m.nome)}</b> e encontrei <b>${m.campos.length}</b> campo(s). Os campos aparecem em amarelo no texto.
        Para criar outro campo, selecione um trecho e clique em <b>Virar campo</b>.${av}`;
      aviso.hidden = false;
    } else aviso.hidden = true;
    $('#edBarra').hidden = m.tipo === 'kit';
    desenharEditorLateral();
    desenharEditorPagina();
    mostrarTela('v-editor');
  }

  function desenharEditorPagina() {
    const m = S.ed.m;
    const alvo = $('#edPagina');
    if (m.tipo === 'kit') {
      alvo.innerHTML = `<div class="painel" style="padding:30px 36px;max-width:640px;margin-top:20px">
        <h3 style="margin-top:0;color:var(--navy)">Como funciona o kit</h3>
        <p>O kit junta vários modelos num documento só. O formulário mostra os campos de todos eles <b>sem repetir</b>: o nome do cliente é digitado uma vez e vai para a ficha, o contrato, a procuração…</p>
        <p>Cada documento começa numa página nova e pode ter seu próprio timbrado (ex.: o Anexo VI do INSS sai sem timbrado).</p>
        <p class="dica">Monte a lista de documentos no painel ao lado.</p></div>`;
      return;
    }
    const t = S.bib.timbrados.find((x) => x.id === m.timbrado);
    const mg = t ? t.margens : (m.margens || { sup: 2, inf: 2, esq: 2.5, dir: 2.5 });
    alvo.innerHTML = `<div class="pagina">${t ? `<img class="fundo" src="timbrado/${esc(t.id)}/fundo.png" style="height:297mm">` : ''}
      <div class="conteudo doc" id="edTexto" contenteditable="true" spellcheck="true"
        style="--fonte:${esc(DOC.pilhaFonte(m.fonte))};--tam:${m.tamanho || 12}pt;--esp:${m.espacamento || 1.4};margin:${mg.sup * 10}mm ${mg.dir * 10}mm ${mg.inf * 10}mm ${mg.esq * 10}mm;padding-bottom:20mm">
        ${tokensParaChips(m.html, m.campos)}</div></div>`;
    const ed = $('#edTexto');
    try { document.execCommand('styleWithCSS', false, false); } catch (e) { /* ok */ }
    ed.addEventListener('input', () => { S.ed.sujo = true; marcarNaoUsados(); });
    ed.addEventListener('click', (e) => {
      const ch = e.target.closest('.chip-campo');
      $$('.chip-campo.sel', ed).forEach((x) => x.classList.remove('sel'));
      if (ch) { ch.classList.add('sel'); abrirCampoLista(ch.dataset.t.split('|')[0]); }
    });
    ed.addEventListener('paste', (e) => {   // cola só texto
      e.preventDefault();
      const t = (e.clipboardData || window.clipboardData).getData('text/plain');
      document.execCommand('insertText', false, t);
    });
  }

  function desenharEditorLateral() {
    const m = S.ed.m, ehKit = m.tipo === 'kit';
    const timbs = `<option value="nenhum" ${m.timbrado === 'nenhum' ? 'selected' : ''}>Sem timbrado</option>` +
      S.bib.timbrados.map((t) => `<option value="${esc(t.id)}" ${t.id === m.timbrado ? 'selected' : ''}>${esc(t.nome)}</option>`).join('');
    const areas = [...new Set(['Previdenciário', 'Trabalhista', 'Cível', 'Consumidor', 'Família', 'Administrativo do escritório', 'Geral', ...S.bib.modelos.map((x) => x.area)].filter(Boolean))];
    const camposGenero = (m.campos || []).filter((c) => c.tipo === 'opcoes');
    let h = `<label class="rot-sec">FICHA DO ${ehKit ? 'KIT' : 'MODELO'}</label>
      <div class="campo"><label>Nome</label><input id="edNome" value="${esc(m.nome)}"></div>
      <div class="campo"><label>Pasta</label><select id="edPasta" onchange="document.getElementById('edNovaW').hidden=this.value!=='__nova'">
        ${S.bib.categorias.some((c) => c.nome === m.categoria) ? '' : `<option selected>${esc(m.categoria)}</option>`}${opcoesPastas(m.categoria)}</select></div>
      <div class="campo" id="edNovaW" hidden><label>Nome da nova pasta</label><input id="edNova"></div>
      <div class="campo"><label>Área</label><input id="edArea" list="dlAreas" value="${esc(m.area || '')}"><datalist id="dlAreas">${areas.map((a) => `<option value="${esc(a)}">`).join('')}</datalist></div>
      <div class="campo"><label>Descrição</label><textarea id="edDesc" rows="2">${esc(m.descricao || '')}</textarea></div>
      <div class="campo"><label>Timbrado padrão</label><select id="edTimb" onchange="App.edTimbrado(this.value)">${timbs}</select></div>`;
    if (S.ed.importando && m.timbrado_detectado) {
      const td = m.timbrado_detectado;
      h += `<div class="aviso-imp" style="margin-top:12px"><b>Este arquivo tem papel timbrado.</b>
        <div style="display:flex;gap:10px;margin-top:8px;align-items:flex-start"><img src="${td.imagem}" style="width:80px;border:1px solid #ddd;border-radius:4px">
        <div style="display:flex;flex-direction:column;gap:6px;font-size:13px">
        ${td.existente ? `<label><input type="radio" name="tOp" value="existente" ${S.ed.timbOpcao === 'existente' ? 'checked' : ''} onchange="App.edTimbOp(this.value)"> Usar o que já existe: <b>${esc(td.existente_nome)}</b></label>` : ''}
        <label><input type="radio" name="tOp" value="criar" ${S.ed.timbOpcao === 'criar' ? 'checked' : ''} onchange="App.edTimbOp(this.value)"> Salvar como novo timbrado</label>
        <label><input type="radio" name="tOp" value="padrao" ${S.ed.timbOpcao === 'padrao' ? 'checked' : ''} onchange="App.edTimbOp(this.value)"> Não usar (fica o escolhido acima)</label>
        </div></div></div>`;
    }
    if (!ehKit) {
      h += `<div class="duas"><div class="campo"><label>Fonte</label><input id="edFonte" list="dlFontes" value="${esc(m.fonte || 'Calibri')}" onchange="App.edVisual()">
        <datalist id="dlFontes">${['Calibri', 'Arial', 'Helvetica', 'Times New Roman', 'Avenir Next', 'Georgia', 'Garamond', 'Book Antiqua', 'Verdana', 'Lato'].map((f) => `<option value="${f}">`).join('')}</datalist></div>
        <div class="campo"><label>Tamanho (pt)</label><input id="edTam" type="number" step="0.5" min="7" max="20" value="${m.tamanho || 12}" onchange="App.edVisual()"></div></div>
        <div class="duas"><div class="campo"><label>Entrelinhas</label><input id="edEsp" type="number" step="0.05" min="1" max="2.5" value="${m.espacamento || 1.4}" onchange="App.edVisual()"></div>
        <div class="campo"><label>Concordância o(a)</label><select id="edGen"><option value="">Não ajustar</option>
        ${camposGenero.map((c) => `<option value="${esc(c.chave)}" ${m.genero === c.chave ? 'selected' : ''}>${esc(c.rotulo)}</option>`).join('')}</select></div></div>
        <p class="dica">Concordância: escreva "inscrito(a)", "o(a) contratante" no texto e escolha o campo de gênero; o programa troca sozinho para o masculino ou feminino.</p>
        <details style="margin-top:10px"><summary class="dica" style="cursor:pointer">Rodapé repetido em todas as páginas (opcional)</summary>
        <textarea id="edRodape" rows="3" style="margin-top:6px;font-family:monospace;font-size:12px" placeholder="Ex.: &lt;p&gt;Rubrica: ______ {{pagina}}&lt;/p&gt;">${esc(m.rodape || '')}</textarea>
        <p class="dica">Use {{pagina}} para o número da página.</p></details>
        <div class="rot-linha"><label class="rot-sec">CAMPOS (${(m.campos || []).length})</label><button class="lnk" onclick="App.novoCampoLista()">＋ novo campo</button></div>
        <div class="lista-campos" id="edCampos">${(m.campos || []).map(htmlCampoLista).join('')}</div>`;
    } else {
      const opMod = (sel) => S.bib.modelos.filter((x) => x.tipo !== 'kit').map((x) => `<option value="${esc(x.id)}" ${x.id === sel ? 'selected' : ''}>${esc(x.nome)}</option>`).join('');
      const opTimb = (sel) => `<option value="" ${!sel ? 'selected' : ''}>Timbrado do kit</option><option value="nenhum" ${sel === 'nenhum' ? 'selected' : ''}>Sem timbrado</option>`;
      h += `<div class="rot-linha"><label class="rot-sec">DOCUMENTOS DO KIT</label><button class="lnk" onclick="App.kitAdd()">＋ adicionar</button></div>
        <div class="kit-itens">${(m.itens || []).map((it, i) => `<div class="ki"><span class="n">${i + 1}</span>
          <div style="flex:1;display:flex;flex-direction:column;gap:5px"><select onchange="App.kitSet(${i},'modelo',this.value)">${opMod(it.modelo)}</select>
          <select onchange="App.kitSet(${i},'timbrado',this.value)">${opTimb(it.timbrado)}</select></div>
          <div style="display:flex;flex-direction:column;gap:3px"><button class="menu-bt" style="height:26px" onclick="App.kitMov(${i},-1)">↑</button>
          <button class="menu-bt" style="height:26px" onclick="App.kitMov(${i},1)">↓</button></div>
          <button class="menu-bt" title="Remover" onclick="App.kitDel(${i})">×</button></div>`).join('')}</div>`;
    }
    $('#edLateral').innerHTML = h;
    if (!ehKit) marcarNaoUsados();
  }
  function htmlCampoLista(c) {
    const k = esc(c.chave);
    return `<div class="lc ${S.ed.abertos[c.chave] ? 'aberto' : ''}" data-c="${k}"><div class="lc-cab" onclick="App.alternarLc('${k}')"><b>${esc(c.rotulo || c.chave)}</b><code>${esc(TIPOS.find((t) => t[0] === c.tipo) ? c.tipo : 'texto')}</code><span class="nu" hidden title="Não aparece no texto">⚠️</span></div>
      <div class="lc-corpo">
      <div class="campo"><label>Nome que aparece no formulário</label><input value="${esc(c.rotulo || '')}" oninput="App.lcSet('${k}','rotulo',this.value)"></div>
      <div class="duas"><div class="campo"><label>Tipo</label><select onchange="App.lcSet('${k}','tipo',this.value)">${TIPOS.map(([v, r]) => `<option value="${v}" ${v === c.tipo ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
      <div class="campo"><label>Grupo</label><input value="${esc(c.grupo || '')}" oninput="App.lcSet('${k}','grupo',this.value)"></div></div>
      <div class="campo"><label>Valor padrão ${c.tipo === 'data' ? '(escreva hoje)' : ''}</label><input value="${esc(c.padrao === true ? 'sim' : c.padrao || '')}" oninput="App.lcSet('${k}','padrao',this.value)"></div>
      ${c.tipo === 'calculo' ? `<div class="campo"><label>Fórmula (use os códigos dos campos, + − * /)</label><input value="${esc(c.formula || '')}" placeholder="qtd_almoco * valor_almoco" oninput="App.lcSet('${k}','formula',this.value)"></div>` : ''}
      ${c.tipo === 'opcoes' ? `<div class="campo"><label>Opções (separe com ;)</label><input value="${esc((c.opcoes || []).join('; '))}" oninput="App.lcSet('${k}','opcoes',this.value)"></div>` : ''}
      <div class="campo"><label>Dica (opcional)</label><input value="${esc(c.ajuda || '')}" oninput="App.lcSet('${k}','ajuda',this.value)"></div>
      <div class="dica">Código no texto: <code>{{${k}}}</code>${c.tipo === 'moeda' ? ' · sai como "R$ 1.500,00 (mil e quinhentos reais)"; use |numero para só o valor' : ''}${c.tipo === 'data' ? ' · filtros: |curta |semana |dia |mes |ano' : ''}${c.tipo === 'texto' ? ' · |maiusculo para CAIXA ALTA' : ''}</div>
      <div style="display:flex;gap:8px;margin-top:8px"><button class="bt bt-cinza bt-mini" onclick="App.inserirChip('${k}')">Inserir no cursor</button>
      <button class="bt bt-perigo bt-mini" onclick="App.excluirCampo('${k}')">Excluir campo</button></div></div></div>`;
  }
  function marcarNaoUsados() {
    const ed = $('#edTexto'); if (!ed) return;
    const usados = new Set($$('.chip-campo', ed).map((c) => c.dataset.t.split('|')[0]));
    if (S.ed.m.rodape) (S.ed.m.rodape.match(/\{\{\s*([\w]+)/g) || []).forEach((t) => usados.add(t.replace(/\{\{\s*/, '')));
    $$('#edCampos .lc').forEach((lc) => { $('.nu', lc).hidden = usados.has(lc.dataset.c); });
  }
  function alternarLc(k) { S.ed.abertos[k] = !S.ed.abertos[k]; const lc = $(`#edCampos .lc[data-c="${CSS.escape(k)}"]`); lc.classList.toggle('aberto', S.ed.abertos[k]); }
  function abrirCampoLista(k) {
    S.ed.abertos[k] = true;
    const lc = $(`#edCampos .lc[data-c="${CSS.escape(k)}"]`); if (!lc) return;
    $$('#edCampos .lc.ativo').forEach((x) => x.classList.remove('ativo'));
    lc.classList.add('aberto', 'ativo'); lc.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
  function lcSet(k, prop, v) {
    const c = S.ed.m.campos.find((x) => x.chave === k); if (!c) return;
    if (prop === 'opcoes') v = v.split(';').map((s) => s.trim()).filter(Boolean);
    if (prop === 'padrao' && c.tipo === 'caixa') v = /^(s|sim|x|1|true)$/i.test(v);
    c[prop] = v;
    if (prop === 'tipo') { desenharEditorLateral(); abrirCampoLista(k); }
    if (prop === 'rotulo') {
      $$(`#edTexto .chip-campo`).forEach((ch) => { const [kk, f] = ch.dataset.t.split('|'); if (kk === k) ch.textContent = v + (f ? ' · ' + f : ''); });
      $(`#edCampos .lc[data-c="${CSS.escape(k)}"] .lc-cab b`).textContent = v;
    }
  }
  async function excluirCampo(k) {
    const n = $$('#edTexto .chip-campo').filter((ch) => ch.dataset.t.split('|')[0] === k).length;
    if (n && !await confirmar('Excluir campo', `O campo aparece ${n} vez(es) no texto. Excluir mesmo? Os lugares no texto também serão removidos.`, 'Excluir')) return;
    $$('#edTexto .chip-campo').forEach((ch) => { if (ch.dataset.t.split('|')[0] === k) ch.remove(); });
    S.ed.m.campos = S.ed.m.campos.filter((c) => c.chave !== k);
    desenharEditorLateral();
  }
  let rangeSalvo = null;
  function salvarRange() {
    const sel = window.getSelection();
    if (sel.rangeCount && $('#edTexto') && $('#edTexto').contains(sel.anchorNode)) rangeSalvo = sel.getRangeAt(0).cloneRange();
  }
  document.addEventListener('selectionchange', () => { if ($('#v-editor').classList.contains('ativa')) salvarRange(); });
  function restaurarRange() {
    if (!rangeSalvo) return false;
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rangeSalvo); return true;
  }
  function chipHTML(c, filtro) {
    return `<span class="chip-campo" contenteditable="false" data-t="${esc(c.chave + (filtro ? '|' + filtro : ''))}">${esc(c.rotulo + (filtro ? ' · ' + filtro : ''))}</span>`;
  }
  function inserirNoCursor(html) {
    $('#edTexto').focus();
    if (!restaurarRange()) { $('#edTexto').insertAdjacentHTML('beforeend', html); return; }
    document.execCommand('insertHTML', false, html);
    S.ed.sujo = true;
    marcarNaoUsados();
  }
  function inserirChip(k) { const c = S.ed.m.campos.find((x) => x.chave === k); inserirNoCursor(chipHTML(c) + '&nbsp;'); }
  function adivinharTipo(t) {
    if (/^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(t)) return 'cpf';
    if (/^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(t)) return 'cnpj';
    if (/^R\$/.test(t) || /^\d{1,3}(\.\d{3})*,\d{2}$/.test(t)) return 'moeda';
    if (/\d{1,2} de [a-zç]+ de \d{4}/i.test(t) || /^\d{2}\/\d{2}\/\d{4}$/.test(t)) return 'data';
    if (/^\d{5}-?\d{3}$/.test(t)) return 'cep';
    if (/^\(?\d{2}\)?\s?9?\s?\d{4}-?\d{4}$/.test(t)) return 'telefone';
    if (/@/.test(t)) return 'email';
    if (t.length > 80) return 'texto_longo';
    return 'texto';
  }
  function modalCampo(titulo, sugestao, cb) {
    const existentes = (S.ed.m.campos || []).map((c) => `<option value="${esc(c.chave)}">${esc(c.rotulo)} ({{${esc(c.chave)}}})</option>`).join('');
    modal(cabModal(titulo) + `<div class="m-corpo">
      ${sugestao.trecho ? `<p class="dica" style="margin:0 0 10px">Trecho selecionado: <b>${esc(sugestao.trecho.slice(0, 120))}</b></p>` : ''}
      <div class="campo"><label>Usar um campo que já existe</label><select id="mcEx"><option value="">— criar campo novo —</option>${existentes}</select></div>
      <div id="mcNovo"><div class="campo"><label>Nome do campo (aparece no formulário)</label><input id="mcRot" value="${esc(sugestao.rotulo || '')}" placeholder="Ex.: Nome do cliente"></div>
      <div class="duas"><div class="campo"><label>Tipo</label><select id="mcTipo">${TIPOS.map(([v, r]) => `<option value="${v}" ${v === sugestao.tipo ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
      <div class="campo"><label>Grupo no formulário</label><input id="mcGrupo" value="${esc(sugestao.grupo || 'Geral')}" list="dlGrupos"><datalist id="dlGrupos">${[...new Set((S.ed.m.campos || []).map((c) => c.grupo))].map((g) => `<option value="${esc(g)}">`).join('')}</datalist></div></div>
      ${sugestao.trecho ? `<label class="caixa"><input type="checkbox" id="mcPadrao"><span>Usar o texto selecionado como valor padrão</span></label>` : ''}</div>
      <div class="campo"><label>Formato</label><select id="mcFiltro"><option value="">Normal</option><option value="maiusculo">CAIXA ALTA</option>
        <option value="curta">Data curta (17/10/2026)</option><option value="semana">Data com dia da semana</option><option value="numero">Valor sem extenso</option>
        <option value="extenso">Só o extenso</option><option value="dois">Número com 2 dígitos (05)</option><option value="com_extenso">Número + extenso: 05 (cinco)</option></select></div></div>
      <div class="m-pe"><button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button><button class="bt bt-ouro" id="mcOk">Pronto</button></div>`);
    $('#mcEx').onchange = () => { $('#mcNovo').hidden = !!$('#mcEx').value; };
    $('#mcOk').onclick = () => {
      let c;
      const filtro = $('#mcFiltro').value;
      if ($('#mcEx').value) c = S.ed.m.campos.find((x) => x.chave === $('#mcEx').value);
      else {
        const rot = $('#mcRot').value.trim(); if (!rot) { $('#mcRot').focus(); return; }
        let k = slug(rot), n = 2; const base = k;
        while (S.ed.m.campos.some((x) => x.chave === k)) k = base + '_' + (n++);
        c = { chave: k, rotulo: rot, tipo: $('#mcTipo').value, grupo: $('#mcGrupo').value.trim() || 'Geral', padrao: '' };
        if (c.tipo === 'opcoes') c.opcoes = [];
        if (c.tipo === 'data' && !sugestao.trecho) c.padrao = 'hoje';
        if ($('#mcPadrao') && $('#mcPadrao').checked) c.padrao = c.tipo === 'moeda' ? sugestao.trecho.replace(/R\$\s*/, '') : sugestao.trecho;
        S.ed.m.campos.push(c);
      }
      fecharModal();
      cb(c, filtro);
      desenharEditorLateral();
      abrirCampoLista(c.chave);
    };
  }
  function virarCampo() {
    const sel = window.getSelection();
    const r = rangeSalvo;
    const txt = r ? r.toString().trim() : '';
    if (!r || !txt) { toast('Selecione no texto o trecho que deve virar campo (ex.: o nome do cliente) e clique de novo.', { tempo: 5500 }); return; }
    const ctx = (r.startContainer.textContent || '').slice(Math.max(0, r.startOffset - 30), r.startOffset);
    const rotPal = ctx.replace(/[:\-–,]\s*$/, '').trim().split(/\s+/).slice(-3).join(' ');
    const tipo = adivinharTipo(txt);
    const rot = { cpf: 'CPF', cnpj: 'CNPJ', moeda: 'Valor', data: 'Data', cep: 'CEP', telefone: 'Telefone', email: 'E-mail' }[tipo] || (/^[A-ZÀ-Ú][a-zà-ú]+( [A-Za-zÀ-ú]+){1,6}$/.test(txt) || /^[A-ZÀ-Ú ]{6,}$/.test(txt) ? 'Nome' : rotPal);
    modalCampo('Virar campo', { trecho: txt, tipo, rotulo: rot }, (c, filtro) => {
      restaurarRange();
      document.execCommand('insertHTML', false, chipHTML(c, filtro));
      S.ed.sujo = true; marcarNaoUsados();
    });
  }
  function inserirCampo() { salvarRange(); modalCampo('Inserir campo', { tipo: 'texto' }, (c, f) => inserirNoCursor(chipHTML(c, f) + '&nbsp;')); }
  function novoCampoLista() { modalCampo('Novo campo', { tipo: 'texto' }, () => { }); }
  function inserirQuebra() { inserirNoCursor('<div class="quebra-pagina quebra-ed" contenteditable="false"></div><p><br></p>'); }
  function cmd(c) { $('#edTexto') && $('#edTexto').focus(); restaurarRange(); document.execCommand(c, false, null); S.ed.sujo = true; }
  function blocosSelecionados() {
    const ed = $('#edTexto'); restaurarRange();
    const sel = window.getSelection(); if (!sel.rangeCount) return [];
    const r = sel.getRangeAt(0);
    const bloco = (n) => { while (n && n !== ed) { if (n.nodeType === 1 && /^(P|DIV|H\d|LI|TD)$/.test(n.tagName)) return n; n = n.parentNode; } return null; };
    const a = bloco(r.startContainer), b = bloco(r.endContainer);
    if (!a) { document.execCommand('formatBlock', false, 'p'); return blocosSelecionados(); }
    const todos = $$('p,div,h1,h2,h3,li,td', ed).filter((x) => !x.querySelector('p,div,table'));
    const i = todos.indexOf(a), j = todos.indexOf(b);
    return i >= 0 && j >= i ? todos.slice(i, j + 1) : [a];
  }
  function alinhar(cls) {
    blocosSelecionados().forEach((b) => { ['centro', 'direita', 'esquerda', 'justificado'].forEach((c) => b.classList.remove(c)); if (cls !== 'justificado') b.classList.add(cls); b.style.textAlign = ''; });
    S.ed.sujo = true;
  }
  function estiloBloco(v) {
    if (!v) return;
    blocosSelecionados().forEach((b) => {
      ['titulo', 'titulo-grande', 'sec-tit', 'assinatura', 'pequeno'].forEach((c) => b.classList.remove(c));
      if (v !== 'p') b.classList.add(v);
    });
    S.ed.sujo = true;
  }
  function edTimbrado(v) { S.ed.m.timbrado = v; if (S.ed.importando) S.ed.timbOpcao = 'padrao'; guardarTextoEditor(); desenharEditorPagina(); }
  function edTimbOp(v) { S.ed.timbOpcao = v; if (v === 'existente') { S.ed.m.timbrado = S.ed.m.timbrado_detectado.existente; guardarTextoEditor(); desenharEditorLateral(); desenharEditorPagina(); } }
  function edVisual() { guardarTextoEditor(); S.ed.m.fonte = $('#edFonte').value; S.ed.m.tamanho = +$('#edTam').value; S.ed.m.espacamento = +$('#edEsp').value; desenharEditorPagina(); }
  function guardarTextoEditor() { if ($('#edTexto')) S.ed.m.html = chipsParaTokens($('#edTexto')); }
  function kitSet(i, p, v) { S.ed.m.itens[i][p] = v || undefined; if (!v) delete S.ed.m.itens[i][p]; }
  function kitAdd() { const prim = S.bib.modelos.find((x) => x.tipo !== 'kit'); S.ed.m.itens.push({ modelo: prim ? prim.id : '' }); desenharEditorLateral(); }
  function kitDel(i) { S.ed.m.itens.splice(i, 1); desenharEditorLateral(); }
  function kitMov(i, d) { const it = S.ed.m.itens; const j = i + d; if (j < 0 || j >= it.length) return; [it[i], it[j]] = [it[j], it[i]]; desenharEditorLateral(); }

  async function salvarEditor() {
    const m = S.ed.m;
    if (m.tipo !== 'kit') guardarTextoEditor();
    m.nome = $('#edNome').value.trim() || 'Modelo sem nome';
    let pasta = $('#edPasta').value; if (pasta === '__nova') pasta = ($('#edNova').value || '').trim() || 'Outros';
    m.categoria = pasta;
    m.area = $('#edArea').value.trim();
    m.descricao = $('#edDesc').value.trim();
    m.timbrado = $('#edTimb').value;
    if (m.tipo !== 'kit') {
      m.fonte = $('#edFonte').value.trim(); m.tamanho = +$('#edTam').value || 12; m.espacamento = +$('#edEsp').value || 1.4;
      m.genero = $('#edGen').value; m.rodape = $('#edRodape').value.trim();
      // campos que sumiram do texto continuam na ficha (aparecem com ⚠️); campos novos já estão na lista
    } else if (!m.itens.length) { toast('Adicione pelo menos um documento ao kit.', { erro: true }); return; }
    const corpo = {};
    ['id', 'nome', 'categoria', 'area', 'descricao', 'timbrado', 'fonte', 'tamanho', 'espacamento', 'genero', 'rodape', 'campos', 'tipo', 'itens', 'tags', 'origem', 'margens', 'criado', 'original_guardado']
      .forEach((k) => { if (m[k] !== undefined) corpo[k] = m[k]; });
    if (m.tipo === 'kit') { corpo.campos = (S.bib.modelos.find((x) => x.id === m.id) || {}).campos || []; }
    corpo.html = m.tipo === 'kit' ? null : m.html;
    try {
      let r;
      if (S.ed.importando) {
        corpo.token = m.token;
        if (S.ed.timbOpcao === 'criar') corpo.timbrado_novo = { criar: true, nome: 'Timbrado — ' + m.nome, margens: m.timbrado_detectado.margens };
        delete corpo.id;
        r = await api('api/importar/salvar', { json: corpo });
      } else r = await api('api/modelo', { json: corpo });
      toast(`Modelo <b>${esc(r.modelo.nome)}</b> salvo em <b>${esc(r.modelo.categoria)}</b>.`);
      await carregar();
      if (S.ed.importando && S.fila.length) { proximoDaFila(); return; }
      S.ed = null;
      abrirModelo(r.modelo.id);
    } catch (e) { toast('Não salvei: ' + esc(e.message), { erro: true }); }
  }
  async function sairEditor() {
    if (S.ed && S.ed.sujo && !await confirmar('Sair sem salvar', 'As alterações feitas no modelo serão perdidas.', 'Sair sem salvar')) return;
    const volta = S.ed ? S.ed.voltar : 'v-inicio';
    S.ed = null; S.fila = [];
    if (volta === 'v-preencher' && S.atual) { abrirModelo(S.atual.id); } else irInicio();
  }
  async function editarAtual() { if (S.atual) abrirEditor(S.atual.id); }

  // ------------------------------------------------------------ IMPORTAR
  function abrirImportar() {
    modal(cabModal('Importar modelos') + `<div class="m-corpo">
      <div class="soltar" id="soltarImp" onclick="document.getElementById('arqImp').click()">
        <div class="soltar-ico">📥</div><b>Clique ou arraste os arquivos aqui</b>
        <span>Word (.docx/.doc), PDF, Pages, RTF, ODT ou TXT · pode mandar vários de uma vez</span></div>
      <div style="display:flex;justify-content:center;margin-top:10px"><button class="bt bt-azul" onclick="App.abrirDrive()">📁 Escolher do Google Drive</button></div>
      <input type="file" id="arqImp" multiple hidden onchange="App.enviarModelos(this.files)">
      <p class="dica">O programa lê cada documento, acha os espaços em branco e os dados do cliente, vira campos, escolhe a pasta certa (ou cria uma), dá um nome profissional e guarda o original.
      ${S.bib.config.tem_chave_ia ? 'A IA (Gemini) está ligada para refinar.' : 'Dica: com uma chave do Gemini em ⚙️ Configurações, a classificação fica ainda mais precisa.'}</p>
      <div class="fila-imp" id="filaImp"></div></div>
      <div class="m-pe" id="impPe" hidden><button class="bt bt-cinza" id="impTodos">Salvar todos sem revisar</button><button class="bt bt-ouro" id="impRevisar">Revisar um por um</button></div>`);
    ligarSoltar($('#soltarImp'), (fs) => enviarModelos(fs));
  }
  function ligarSoltar(el, fn) {
    el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('sobre'); });
    el.addEventListener('dragleave', () => el.classList.remove('sobre'));
    el.addEventListener('drop', (e) => { e.preventDefault(); el.classList.remove('sobre'); fn(e.dataTransfer.files); });
  }
  async function enviarModelos(files) {
    files = Array.from(files || []); if (!files.length) return;
    const fila = files.map((f) => (f.drive ? { f: { name: f.nome }, drive: f.caminho, st: 'aguardando' } : { f, st: 'aguardando' }));
    const des = () => {
      $('#filaImp').innerHTML = fila.map((x) => `<div class="fi">📄 <span>${esc(x.f.name)}</span>
      ${x.sug && x.sug.modo !== 'paginas' ? `<span class="dica" style="margin:0">→ ${esc(x.sug.categoria)} / <b>${esc(x.sug.nome)}</b> · ${x.sug.campos.length} campos</span>` : ''}
      ${x.sug && x.sug.modo === 'paginas' ? `<span class="dica" style="margin:0">PDF original · ${x.sug.documentos.length} doc(s)</span>` : ''}
      <span class="st ${x.st === 'pronto' ? 'ok' : x.st === 'erro' ? 'err' : ''}">${x.st === 'lendo' ? '<span class="carregando"></span> lendo…' : x.st === 'erro' ? '✖ ' + esc(x.erro) : x.st === 'pronto' ? '✔ pronto' : 'na fila'}</span></div>`).join('');
    };
    des();
    for (const x of fila) {
      x.st = 'lendo'; des();
      try {
        let r;
        if (x.drive) r = await api('api/drive/importar', { json: { caminho: x.drive } });
        else { const fd = new FormData(); fd.append('arquivo', x.f); r = await api('api/importar', { method: 'POST', body: fd }); }
        x.sug = r.sugestao; x.st = 'pronto';
      } catch (e) { x.st = 'erro'; x.erro = e.message; }
      des();
    }
    const prontos = fila.filter((x) => x.sug);
    if (!prontos.length) return;
    $('#impPe').hidden = false;
    if (prontos.length === 1) $('#impTodos').textContent = 'Salvar sem revisar';
    $('#impRevisar').onclick = () => { S.fila = prontos.map((x) => x.sug); fecharModal(); proximoDaFila(); };
    $('#impTodos').onclick = async () => {
      for (const x of prontos) {
        const s = x.sug;
        if (s.modo === 'paginas') {
          const campos = {}; s.documentos.forEach((d) => d.campos.forEach((c) => { campos[c.chave] = c; }));
          await api('api/importar/salvar-paginas', { json: { token: s.token, tamanhos: s.tamanhos, kit: s.kit, palavras: s.palavras,
            documentos: s.documentos.map((d) => ({ ...d, genero: 'cliente_genero' })) } });
          continue;
        }
        const corpo = { nome: s.nome, categoria: s.categoria, area: s.area, descricao: s.descricao, campos: s.campos, html: s.html, fonte: s.fonte, tamanho: s.tamanho,
          espacamento: s.espacamento, genero: s.genero, token: s.token, timbrado: (s.timbrado_detectado && s.timbrado_detectado.existente) || S.bib.config.timbrado_padrao };
        if (s.timbrado_detectado && !s.timbrado_detectado.existente) corpo.timbrado_novo = { criar: true, nome: 'Timbrado — ' + s.nome, margens: s.timbrado_detectado.margens };
        await api('api/importar/salvar', { json: corpo });
      }
      fecharModal(); toast(`${prontos.length} modelo(s) importado(s) e organizados.`); carregar(); irInicio();
    };
  }
  // ---- Google Drive
  async function abrirDrive(caminho) {
    let d;
    try {
      if (!caminho) {
        const r = await api('api/drive/raizes');
        if (!r.raizes.length) {
          modal(cabModal('Google Drive') + `<div class="m-corpo"><p><b>O Google Drive para computador ainda não está instalado neste ${WIN ? 'computador' : 'Mac'}.</b></p>
            <p>Com ele, o seu Drive aparece ${WIN ? 'no Explorador de Arquivos' : 'no Finder'} como uma pasta comum e o programa importa direto de lá:</p>
            <ol style="line-height:1.6"><li>Baixe em <b>google.com/drive/download</b> e instale.</li><li>Entre com a sua conta Google.</li>
            <li>Volte aqui e clique de novo em <b>Escolher do Google Drive</b>.</li></ol>
            <p class="dica">Arquivos nativos do Google Docs precisam ser baixados como Word ou PDF antes (Arquivo › Fazer download).</p></div>
            <div class="m-pe"><button class="bt bt-ouro" onclick="App.fecharModal()">Entendi</button></div>`);
          return;
        }
        if (r.raizes.length === 1) caminho = r.raizes[0].caminho;
        else {
          S.drive = { raizes: r.raizes, sel: new Map() };
          return desenharDrive({ caminho: '', itens: r.raizes.map((x) => ({ nome: x.nome, caminho: x.caminho, pasta: true })) }, true);
        }
      }
      d = await api('api/drive/listar?caminho=' + encodeURIComponent(caminho));
    } catch (e) { toast(esc(e.message), { erro: true, tempo: 9000 }); return; }
    if (!S.drive) S.drive = { sel: new Map() };
    if (!S.drive.raizes) { try { S.drive.raizes = (await api('api/drive/raizes')).raizes; } catch (e) { S.drive.raizes = []; } }
    desenharDrive(d);
  }
  function desenharDrive(d, inicio) {
    const D = S.drive; D.atual = d;
    const raiz = (D.raizes || []).find((r) => d.caminho && (d.caminho === r.caminho || d.caminho.startsWith(r.caminho + '/')));
    let migalhas = '<a onclick="App.abrirDrive()">Google Drive</a>';
    if (raiz) {
      migalhas += ` › <a onclick="App.abrirDrive(${esc(JSON.stringify(raiz.caminho))})">${esc(raiz.nome.replace(/ \(.*\)$/, ''))}</a>`;
      let acc = raiz.caminho;
      d.caminho.slice(raiz.caminho.length).split('/').filter(Boolean).forEach((p) => { acc += '/' + p; migalhas += ` › <a onclick="App.abrirDrive(${esc(JSON.stringify(acc))})">${esc(p)}</a>`; });
    }
    const linhas = d.itens.map((it) => it.pasta
      ? `<div class="dr-it pasta" onclick="App.abrirDrive(${esc(JSON.stringify(it.caminho))})"><span>📁</span><b>${esc(it.nome)}</b><span class="dr-meta">›</span></div>`
      : `<label class="dr-it ${it.google ? 'off' : ''}"><input type="checkbox" ${it.google ? 'disabled' : ''} ${D.sel.has(it.caminho) ? 'checked' : ''}
          onchange="App.driveMarcar(${esc(JSON.stringify(it.caminho))}, ${esc(JSON.stringify(it.nome))}, this.checked)">
          <span>${/\.pdf$/i.test(it.nome) ? '📕' : it.google ? '🔗' : '📄'}</span><span class="dr-nome">${esc(it.nome)}</span>
          <span class="dr-meta">${it.google ? 'Google Docs: baixe como Word/PDF' : esc(it.modificado || '')}</span></label>`).join('')
      || '<p class="dica" style="padding:14px">Nenhum documento nesta pasta.</p>';
    modal(cabModal('Escolher do Google Drive') + `<div class="m-corpo"><div class="dr-mig">${migalhas}</div>
      <input id="drFiltro" placeholder="Filtrar nesta pasta…" oninput="App.driveFiltrar(this.value)" style="margin:8px 0">
      <div class="dr-lista" id="drLista">${linhas}</div></div>
      <div class="m-pe"><span class="dica" style="margin-right:auto" id="drQtd">${D.sel.size} selecionado(s)</span>
      <button class="bt bt-cinza" onclick="App.abrirImportar()">Voltar</button>
      <button class="bt bt-ouro" onclick="App.driveImportar()" id="drOk" ${D.sel.size ? '' : 'disabled'}>Importar selecionados</button></div>`, true);
  }
  function driveMarcar(c, n, v) { if (v) S.drive.sel.set(c, n); else S.drive.sel.delete(c); $('#drQtd').textContent = S.drive.sel.size + ' selecionado(s)'; $('#drOk').disabled = !S.drive.sel.size; }
  function driveFiltrar(q) { q = norm(q); $$('#drLista .dr-it').forEach((el) => { el.hidden = q && !norm(el.textContent).includes(q); }); }
  function driveImportar() {
    const lst = [...S.drive.sel.entries()].map(([caminho, nome]) => ({ drive: true, caminho, nome }));
    S.drive.sel = new Map();
    abrirImportar();
    enviarModelos(lst);
  }

  function proximoDaFila() {
    const s = S.fila.shift();
    if (!s) { irInicio(); return; }
    abrirEditor(null, s);
  }

  // ------------------------------------------------------------ TIMBRADOS
  async function abrirTimbrados() {
    await carregar();
    desenharTimbrados();
    mostrarTela('v-timbrados');
    ligarSoltar($('#soltarTimb'), (fs) => enviarTimbrado(fs));
  }
  function areaTxt(m) { return `top:${m.sup / 29.7 * 100}%;bottom:${m.inf / 29.7 * 100}%;left:${m.esq / 21 * 100}%;right:${m.dir / 21 * 100}%`; }
  function desenharTimbrados() {
    $('#gradeTimb').innerHTML = S.bib.timbrados.map((t) => `<div class="timb" onclick="App.editarTimbrado('${esc(t.id)}')">
      <div class="mini"><img src="timbrado/${esc(t.id)}/fundo.png?v=${Date.now()}" alt=""><div class="area-txt" style="${areaTxt(t.margens)}"></div></div>
      <h5>${esc(t.nome)}${t.padrao ? '<span class="padrao">PADRÃO</span>' : ''}</h5>
      <p>Margens: topo ${t.margens.sup} · base ${t.margens.inf} · lados ${t.margens.esq}/${t.margens.dir} cm</p></div>`).join('') ||
      '<div class="vazio-lista">Nenhum timbrado ainda. Envie um ao lado.</div>';
  }
  async function enviarTimbrado(files) {
    const f = (files || [])[0]; if (!f) return;
    toast('<span class="carregando"></span> Lendo o timbrado…', { tempo: 2500 });
    try {
      const fd = new FormData(); fd.append('arquivo', f);
      const r = await api('api/timbrados', { method: 'POST', body: fd });
      await carregar(); desenharTimbrados();
      editarTimbrado(r.timbrado.id, true);
    } catch (e) { toast('Não consegui ler: ' + esc(e.message), { erro: true }); }
    $('#arqTimb').value = '';
  }
  function editarTimbrado(id, novo) {
    const t = S.bib.timbrados.find((x) => x.id === id);
    const m = { ...t.margens };
    modal(cabModal(novo ? 'Novo timbrado — confira as margens' : 'Timbrado') + `<div class="m-corpo"><div class="timb-edit">
      <div class="mini"><img src="timbrado/${esc(t.id)}/fundo.png?v=${Date.now()}"><div class="area-txt" id="mtArea" style="${areaTxt(m)}"></div></div>
      <div><div class="campo"><label>Nome</label><input id="mtNome" value="${esc(t.nome)}"></div>
      <label class="rot-sec">ÁREA DO TEXTO (cm)</label>
      <div class="margens">${[['sup', 'Topo'], ['inf', 'Base'], ['esq', 'Esquerda'], ['dir', 'Direita']].map(([k, r]) =>
        `<div class="campo"><label>${r}</label><input type="number" step="0.1" min="0" max="12" value="${m[k]}" data-m="${k}"></div>`).join('')}</div>
      <p class="dica">O retângulo tracejado mostra onde o texto vai ficar. Ajuste para não encostar no logotipo nem no rodapé.</p>
      <label class="caixa" style="margin-top:10px"><input type="checkbox" id="mtPadrao" ${t.padrao ? 'checked' : ''}><span>Usar como timbrado padrão</span></label></div></div></div>
      <div class="m-pe"><button class="bt bt-perigo" id="mtDel" style="margin-right:auto">Excluir</button><button class="bt bt-cinza" onclick="App.fecharModal()">Fechar</button><button class="bt bt-ouro" id="mtOk">Salvar</button></div>`, true);
    $$('#modalCaixa [data-m]').forEach((i) => i.addEventListener('input', () => { m[i.dataset.m] = +i.value || 0; $('#mtArea').setAttribute('style', areaTxt(m)); }));
    $('#mtOk').onclick = async () => {
      await api('api/timbrado/' + id, { json: { nome: $('#mtNome').value.trim() || t.nome, margens: m, padrao: $('#mtPadrao').checked } });
      fecharModal(); toast('Timbrado salvo.'); await carregar(); desenharTimbrados();
    };
    $('#mtDel').onclick = async () => {
      const usando = S.bib.modelos.filter((x) => x.timbrado === id).length;
      if (!await confirmar('Excluir timbrado', `Excluir <b>${esc(t.nome)}</b>?${usando ? ` ${usando} modelo(s) usam este timbrado e passarão a sair no padrão.` : ''}`, 'Excluir')) return;
      await api('api/timbrado/' + id, { method: 'DELETE' }); await carregar(); desenharTimbrados();
    };
  }

  // ------------------------------------------------------------ configurações
  async function abrirConfig() {
    const d = await api('api/config'); const c = d.config;
    modal(cabModal('Configurações') + `<div class="m-corpo">
      <label class="rot-sec" style="margin-top:0">BIBLIOTECA</label>
      <p class="dica" style="margin-top:0">Seus modelos ficam em <b>${esc(d.pasta)}</b> — pastas comuns, que você pode copiar para backup.</p>
      <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap"><button class="bt bt-cinza bt-mini" onclick="App.abrirPasta('biblioteca')">Abrir pasta</button>
      <button class="bt bt-cinza bt-mini" onclick="App.abrirPasta('originais')">Arquivos originais</button><button class="bt bt-cinza bt-mini" onclick="App.abrirPasta('lixeira')">Lixeira</button></div>
      <div class="duas"><div class="campo"><label>Local padrão das assinaturas</label><input id="cfLocal" value="${esc(c.local_padrao || '')}"></div>
      <div class="campo"><label>PDF</label><input disabled value="${d.chrome ? 'Pelo Google Chrome ✔' : 'Chrome não encontrado: usa Imprimir'}"></div></div>
      <label class="caixa" style="margin-top:10px"><input type="checkbox" id="cfCopia" ${c.salvar_copia ? 'checked' : ''}><span>Guardar uma cópia de cada documento gerado em "Gerados"</span></label>
      <label class="rot-sec">INTELIGÊNCIA ARTIFICIAL NA IMPORTAÇÃO (OPCIONAL)</label>
      <p class="dica" style="margin-top:0">Sem chave, a importação funciona por regras. Com uma chave do Google Gemini, a IA refina a pasta, o nome e acha dados de cliente que viram campo.</p>
      <div class="duas"><div class="campo"><label>Chave do Gemini</label><input type="password" id="cfChave" value="${esc(c.gemini_chave || '')}" placeholder="AIza…"></div>
      <div class="campo"><label>Modelo</label><input id="cfModelo" value="${esc(c.gemini_modelo || 'gemini-2.5-flash')}"></div></div>
      <label class="caixa" style="margin-top:8px"><input type="checkbox" id="cfIA" ${c.usar_ia_importacao ? 'checked' : ''}><span>Usar a IA ao importar</span></label>
      <label class="rot-sec">LEITURA DE DOCUMENTOS DO CLIENTE</label>
      <p class="dica" style="margin-top:0">Com internet e chave, a leitura é feita pelo Gemini (mais precisa). Sem internet, o programa lê no próprio computador, sozinho.</p>
      <label class="caixa"><input type="checkbox" id="cfLocal1" ${c.ocr_so_local ? 'checked' : ''}><span>Ler sempre no próprio computador (não envia as fotos dos documentos para o Google)</span></label>
      <p class="dica">Versão ${esc(S.bib.versao)}</p></div>
      <div class="m-pe"><button class="bt bt-cinza" id="cfTestar" style="margin-right:auto">Testar IA</button><button class="bt bt-cinza" onclick="App.fecharModal()">Fechar</button><button class="bt bt-ouro" id="cfOk">Salvar</button></div>`);
    const salvar = () => api('api/config', { json: { local_padrao: $('#cfLocal').value.trim(), salvar_copia: $('#cfCopia').checked, gemini_chave: $('#cfChave').value.trim(),
      gemini_modelo: $('#cfModelo').value.trim(), usar_ia_importacao: $('#cfIA').checked, ocr_so_local: $('#cfLocal1').checked } });
    $('#cfOk').onclick = async () => { await salvar(); fecharModal(); toast('Configurações salvas.'); carregar(); };
    $('#cfTestar').onclick = async () => {
      await salvar();
      try { await api('api/testar-ia', { method: 'POST' }); toast('IA respondeu. Tudo certo ✔'); } catch (e) { toast(esc(e.message), { erro: true, tempo: 8000 }); }
    };
  }

  // ------------------------------------------------------------ EDITOR DE PÁGINAS (PDF original)
  // S.pe = { modo:'importar'|'editar', token, docs:[...], imagens:[url por página], tamanhos:[[w,h]],
  //          campos:{chave:def}, sel:{d,i}|null, zoom, desenhar:false, kit:{criar,nome,categoria} }
  const PX_PT = 1.55;
  function abrirEditorPaginas(m, sugestao) {
    const pe = { zoom: 1, desenhar: false, sel: null, campos: {}, voltar: $('.tela.ativa').id, sujo: false };
    if (sugestao) {
      pe.modo = 'importar'; pe.token = sugestao.token; pe.arquivo = sugestao.arquivo;
      pe.tamanhos = sugestao.tamanhos;
      pe.imagens = sugestao.tamanhos.map((t, n) => `api/importar/${encodeURIComponent(sugestao.token)}/p/${n}.png`);
      pe.docs = sugestao.documentos.map((d) => ({ ...d, caixas: d.caixas.map((c) => ({ ...c })) }));
      pe.kit = { ...sugestao.kit };
      pe.palavras = sugestao.palavras || [];
      pe.docs.forEach((d) => d.campos.forEach((c) => { if (!pe.campos[c.chave]) pe.campos[c.chave] = { ...c }; }));
    } else {
      pe.modo = 'editar';
      pe.imagens = m.paginas.map((p) => p.img); pe.tamanhos = m.paginas.map((p) => [p.w, p.h]);
      pe.docs = [{ ...m, paginas: m.paginas.map((_, i) => i), caixas: (m.caixas || []).map((c) => ({ ...c })) }];
      pe.palavras = m.palavras || [];
      (m.campos || []).forEach((c) => { pe.campos[c.chave] = { ...c }; });
    }
    S.pe = pe;
    $('#pgTitulo').textContent = sugestao ? 'REVISAR IMPORTAÇÃO' : 'EDITAR MODELO';
    const av = $('#pgAviso');
    if (sugestao) {
      const n = pe.docs.reduce((a, d) => a + d.caixas.length, 0);
      av.innerHTML = `<b>${esc(sugestao.arquivo)}</b>: mantive o PDF exatamente como ele é e coloquei <b>${n}</b> campo(s) por cima, nos espaços em branco.
        Encontrei <b>${pe.docs.length}</b> documento(s)${pe.docs.length > 1 ? ' e vou montar um <b>kit</b> com eles' : ''}.
        Os retângulos amarelos são os campos: <b>arraste</b> para mover, puxe o <b>canto</b> para aumentar, clique para trocar o campo.
        Faltou algum? Clique em <b>＋ Novo campo</b> e desenhe na página.
        <div class="pergunta"><b>❓ Algum trecho do texto também muda de um caso para outro?</b> (um valor, um percentual, o nome da ação, uma cidade…)
        <button class="bt bt-azul bt-mini" onclick="App.peTexto(true)">✎ Sim, escolher os trechos</button>
        <button class="bt bt-cinza bt-mini" onclick="this.closest('.pergunta').remove()">Não, só os espaços em branco</button></div>`;
      av.hidden = false;
    } else av.hidden = true;
    desenharPe(); desenharPeLateral();
    mostrarTela('v-paginas');
    $('#pgRolagem').scrollTop = 0;
  }
  function tokensDe(txt) { return (String(txt || '').match(/\{\{\s*([^{}|]+?)\s*(\|[^{}]*)?\}\}/g) || []).map((t) => t.replace(/^\{\{\s*|\s*(\|[^{}]*)?\}\}$/g, '')); }
  function rotuloCaixa(cx) {
    const ks = tokensDe(cx.texto);
    if (!ks.length) return cx.texto || '(vazio)';
    if (ks.length > 3) return 'Qualificação completa';
    return ks.map((k) => (S.pe.campos[k] && S.pe.campos[k].rotulo) || k).join(', ');
  }
  function desenharPe() {
    const pe = S.pe, alvo = $('#pgPaginas'), e = PX_PT * pe.zoom;
    let h = '';
    pe.docs.forEach((d, di) => {
      if (pe.docs.length > 1) h += `<div class="pg-doc-tit"><span>${di + 1}</span> ${esc(d.nome)}</div>`;
      d.paginas.forEach((g) => {
        const [w, hh] = pe.tamanhos[g] || [595.3, 841.9];
        h += `<div class="pg-pag ${pe.desenhar ? 'desenhar' : ''}" data-d="${di}" data-g="${g}" style="width:${w * e}px;height:${hh * e}px">
          <img src="${esc(pe.imagens[g])}" draggable="false">` +
          (pe.texto ? (pe.palavras[g] || []).map((w, wi) => `<i class="pg-w" data-g="${g}" data-w="${wi}" style="left:${w.x0 * e - 1}px;top:${w.top * e - 1}px;width:${(w.x1 - w.x0) * e + 2}px;height:${(w.bottom - w.top) * e + 2}px"></i>`).join('') : '') +
          d.caixas.map((cx, i) => cx.pagina !== g ? '' : `<div class="pg-cx ${pe.sel && pe.sel.d === di && pe.sel.i === i ? 'sel' : ''}" data-d="${di}" data-i="${i}"
            style="left:${cx.x * e}px;top:${cx.y * e}px;width:${cx.w * e}px;height:${cx.h * e}px" title="${esc(rotuloCaixa(cx))}">
            <span>${esc(rotuloCaixa(cx))}</span><i class="pg-al"></i></div>`).join('') + '</div>';
      });
    });
    alvo.innerHTML = h;
    $('#pgZoom').textContent = Math.round(pe.zoom * 100) + '%';
    $('#pgDesenhar').classList.toggle('ativo', pe.desenhar);
    $('#pgTexto').classList.toggle('ativo', !!pe.texto);
    $('#pgPaginas').classList.toggle('modo-texto', !!pe.texto);
  }
  function peZoom(d) { S.pe.zoom = Math.min(2, Math.max(0.5, +(S.pe.zoom + d).toFixed(2))); desenharPe(); }
  function peTexto(v) {
    S.pe.texto = v === undefined ? !S.pe.texto : v; S.pe.desenhar = false; desenharPe();
    if (S.pe.texto) {
      const p = $('#pgAviso .pergunta'); if (p) p.remove();
      toast('Clique numa palavra, ou arraste por cima do trecho, para ele virar variável.', { tempo: 4500 });
    }
  }
  function peDesenhar() { S.pe.desenhar = !S.pe.desenhar; S.pe.texto = false; desenharPe(); if (S.pe.desenhar) toast('Desenhe um retângulo na página onde o dado deve aparecer.', { tempo: 3500 }); }
  // arrastar / redimensionar / desenhar
  let arr = null;
  $('#pgPaginas').addEventListener('mousedown', (ev) => {
    const pe = S.pe; if (!pe) return;
    const e = PX_PT * pe.zoom;
    const cxEl = ev.target.closest('.pg-cx'), pag = ev.target.closest('.pg-pag');
    if (!pag) return;
    ev.preventDefault();
    if (pe.texto) {
      const r = pag.getBoundingClientRect();
      const sel = document.createElement('div'); sel.className = 'pg-selrect'; pag.appendChild(sel);
      arr = { tipo: 'trecho', pag, g: +pag.dataset.g, di: +pag.dataset.d, r, sel, x0: ev.clientX, y0: ev.clientY, e };
      return;
    }
    if (cxEl && !pe.desenhar) {
      const d = +cxEl.dataset.d, i = +cxEl.dataset.i, cx = pe.docs[d].caixas[i];
      pe.sel = { d, i };
      $$('.pg-cx.sel').forEach((x) => x.classList.remove('sel')); cxEl.classList.add('sel');
      desenharPeLateral();
      arr = { tipo: ev.target.classList.contains('pg-al') ? 'tam' : 'mover', cx, el: cxEl, x0: ev.clientX, y0: ev.clientY, ox: cx.x, oy: cx.y, ow: cx.w, oh: cx.h, e };
      return;
    }
    if (pe.desenhar) {
      const r = pag.getBoundingClientRect();
      const x = (ev.clientX - r.left) / e, y = (ev.clientY - r.top) / e;
      const di = +pag.dataset.d, g = +pag.dataset.g;
      const cx = { pagina: g, x, y, w: 10, h: 10, tam: 9, alinhar: 'esquerda', texto: '', cobrir: false, lh: null, negrito: !!pe.docs[di].valores_maiusculos };
      pe.docs[di].caixas.push(cx);
      pe.sel = { d: di, i: pe.docs[di].caixas.length - 1 };
      desenharPe();
      const el = $(`.pg-cx[data-d="${di}"][data-i="${pe.sel.i}"]`);
      arr = { tipo: 'novo', cx, el, x0: ev.clientX, y0: ev.clientY, ox: x, oy: y, ow: 0, oh: 0, e };
    }
  });
  document.addEventListener('mousemove', (ev) => {
    if (!arr) return;
    if (arr.tipo === 'trecho') {
      const x = Math.min(arr.x0, ev.clientX) - arr.r.left, y = Math.min(arr.y0, ev.clientY) - arr.r.top;
      Object.assign(arr.sel.style, { left: x + 'px', top: y + 'px', width: Math.abs(ev.clientX - arr.x0) + 'px', height: Math.abs(ev.clientY - arr.y0) + 'px' });
      arr.fim = [ev.clientX, ev.clientY];
      return;
    }
    const dx = (ev.clientX - arr.x0) / arr.e, dy = (ev.clientY - arr.y0) / arr.e, c = arr.cx;
    if (arr.tipo === 'mover') { c.x = Math.max(0, arr.ox + dx); c.y = Math.max(0, arr.oy + dy); }
    else { c.w = Math.max(10, arr.ow + dx); c.h = Math.max(8, arr.oh + dy); }
    Object.assign(arr.el.style, { left: c.x * arr.e + 'px', top: c.y * arr.e + 'px', width: c.w * arr.e + 'px', height: c.h * arr.e + 'px' });
    arr.mexeu = true;
  });
  document.addEventListener('mouseup', () => {
    if (!arr) return;
    const a = arr; arr = null;
    if (a.tipo === 'trecho') { a.sel.remove(); trechoSelecionado(a); return; }
    if (a.mexeu) S.pe.sujo = true;
    if (a.tipo === 'novo') {
      if (a.cx.w < 14) { a.cx.w = 160; a.cx.h = Math.max(a.cx.h, 13); }
      S.pe.desenhar = false;
      ['x', 'y', 'w', 'h'].forEach((k) => { a.cx[k] = +a.cx[k].toFixed(1); });
      desenharPe(); desenharPeLateral();
      escolherCampoCaixa(true);
    } else ['x', 'y', 'w', 'h'].forEach((k) => { a.cx[k] = +(+a.cx[k]).toFixed(1); });
  });
  function trechoSelecionado(a) {
    const pe = S.pe, e = a.e;
    const [cx1, cy1] = a.fim || [a.x0 + 1, a.y0 + 1];
    const X0 = (Math.min(a.x0, cx1) - a.r.left) / e, X1 = (Math.max(a.x0, cx1) - a.r.left) / e;
    const Y0 = (Math.min(a.y0, cy1) - a.r.top) / e, Y1 = (Math.max(a.y0, cy1) - a.r.top) / e;
    const ws = (pe.palavras[a.g] || []).filter((w) => w.x1 >= X0 - 1 && w.x0 <= X1 + 1 && w.bottom >= Y0 - 1 && w.top <= Y1 + 1);
    if (!ws.length) { toast('Nenhum texto nesse ponto. Clique em cima das palavras.'); return; }
    ws.sort((p, q) => (Math.round(p.top) - Math.round(q.top)) || (p.x0 - q.x0));
    const linhas = []; ws.forEach((w) => { const l = linhas.find((l) => Math.abs(l.top - w.top) < 3); if (l) l.ws.push(w); else linhas.push({ top: w.top, ws: [w] }); });
    const texto = linhas.map((l) => l.ws.map((w) => w.t).join(' ')).join(' ');
    const base = ws[0];
    const caixa = { pagina: a.g, x: +(Math.min(...ws.map((w) => w.x0)) - 1).toFixed(1), y: +(Math.min(...ws.map((w) => w.top)) - 1).toFixed(1),
      w: +(Math.max(...ws.map((w) => w.x1)) - Math.min(...ws.map((w) => w.x0)) + 2).toFixed(1),
      h: +(Math.max(...ws.map((w) => w.bottom)) - Math.min(...ws.map((w) => w.top)) + 2).toFixed(1),
      tam: base.size, fonte: base.fonte, cor: base.cor, negrito: base.negrito, cobrir: true, alinhar: 'esquerda',
      lh: linhas.length > 1 ? +((linhas[linhas.length - 1].top - linhas[0].top) / (linhas.length - 1)).toFixed(1) : null, texto: '' };
    // folga para o texto novo ser um pouco maior que o original
    if (!caixa.lh) caixa.w = +(caixa.w + Math.min(60, caixa.w * 0.4)).toFixed(1);
    const di = a.di; pe.docs[di].caixas.push(caixa); pe.sel = { d: di, i: pe.docs[di].caixas.length - 1 };
    desenharPe(); desenharPeLateral();
    const tipo = adivinharTipo(texto);
    modal(cabModal('Este trecho vai virar variável') + `<div class="m-corpo">
      <p class="dica" style="margin:0 0 10px">Trecho: <b>${esc(texto.slice(0, 160))}</b></p>
      <div class="campo"><label>Nome do campo (aparece no formulário)</label><input id="tvRot" value="${esc(tipo === 'moeda' ? 'Valor' : tipo === 'data' ? 'Data' : '')}" placeholder="Ex.: Honorários mínimos"></div>
      <div class="campo"><label>Tipo</label><select id="tvTipo">${TIPOS.map(([v, r]) => `<option value="${v}" ${v === tipo ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
      <label class="caixa" style="margin-top:8px"><input type="checkbox" id="tvPad" checked><span>Começar com o texto atual (você só muda quando precisar)</span></label></div>
      <div class="m-pe"><button class="bt bt-cinza" id="tvNao">Cancelar</button><button class="bt bt-ouro" id="tvOk">Criar variável</button></div>`);
    setTimeout(() => $('#tvRot').focus(), 50);
    $('#tvNao').onclick = () => { fecharModal(); pe.docs[di].caixas.pop(); pe.sel = null; desenharPe(); desenharPeLateral(); };
    $('#tvOk').onclick = () => {
      const rot = $('#tvRot').value.trim(); if (!rot) { $('#tvRot').focus(); return; }
      let k = slug(rot), n = 2; const b = k; while (pe.campos[k]) k = b + '_' + (n++);
      const t = $('#tvTipo').value;
      let pad = $('#tvPad').checked ? texto : '';
      if (t === 'moeda') pad = pad.replace(/R\$\s*/, '').replace(/\s*\(.*$/, '');
      pe.campos[k] = { chave: k, rotulo: rot, tipo: t, grupo: 'Variáveis do texto', padrao: pad };
      caixa.texto = '{{' + k + (t === 'moeda' ? '|numero' : '') + '}}';
      pe.sujo = true; fecharModal(); desenharPe(); desenharPeLateral();
      toast(`Pronto: <b>${esc(rot)}</b> agora é variável. Pode escolher outro trecho.`);
    };
  }
  function caixaSel() { const s = S.pe && S.pe.sel; return s ? S.pe.docs[s.d].caixas[s.i] : null; }
  function escolherCampoCaixa(nova) {
    const cx = caixaSel(); if (!cx) return;
    const ops = Object.values(S.pe.campos).sort((a, b) => (a.rotulo || '').localeCompare(b.rotulo || '', 'pt'))
      .map((c) => `<option value="${esc(c.chave)}">${esc(c.rotulo)}</option>`).join('');
    modal(cabModal(nova ? 'Que dado vai neste lugar?' : 'Trocar o campo') + `<div class="m-corpo">
      <div class="campo"><label>Campo que já existe</label><select id="ecEx"><option value="">— criar campo novo —</option>${ops}</select></div>
      <div id="ecNovo"><div class="campo"><label>Nome do campo novo</label><input id="ecRot" placeholder="Ex.: Número do processo"></div>
      <div class="campo"><label>Tipo</label><select id="ecTipo">${TIPOS.map(([v, r]) => `<option value="${v}">${r}</option>`).join('')}</select></div></div>
      <label class="caixa" style="margin-top:8px"><input type="checkbox" id="ecQual"><span>Qualificação completa do cliente (nome, nacionalidade, estado civil, profissão, RG, CPF, endereço…)</span></label></div>
      <div class="m-pe">${nova ? '<button class="bt bt-perigo" id="ecDel" style="margin-right:auto">Remover este campo</button>' : ''}<button class="bt bt-cinza" onclick="App.fecharModal()">Cancelar</button><button class="bt bt-ouro" id="ecOk">Pronto</button></div>`);
    $('#ecEx').onchange = () => { $('#ecNovo').hidden = !!$('#ecEx').value; };
    if ($('#ecDel')) $('#ecDel').onclick = () => { fecharModal(); peExcluir(); };
    $('#ecOk').onclick = () => {
      if ($('#ecQual').checked) {
        cx.texto = QUALIF_TXT; QUALIF_CAMPOS.forEach((k) => { if (!S.pe.campos[k]) S.pe.campos[k] = campoPadraoJS(k); });
        cx.lh = cx.lh || 13; cx.alinhar = 'justificado';
      } else if ($('#ecEx').value) {
        const c = S.pe.campos[$('#ecEx').value];
        cx.texto = '{{' + c.chave + (c.tipo === 'data' ? '|curta' : '') + '}}';
      } else {
        const rot = $('#ecRot').value.trim(); if (!rot) { $('#ecRot').focus(); return; }
        let k = slug(rot), n = 2; const b = k; while (S.pe.campos[k]) k = b + '_' + (n++);
        S.pe.campos[k] = { chave: k, rotulo: rot, tipo: $('#ecTipo').value, grupo: 'Geral', padrao: '' };
        cx.texto = '{{' + k + '}}';
      }
      if (cx.h > (cx.tam || 9) * 2.4 && !cx.lh) cx.lh = +((cx.tam || 9) * 1.35).toFixed(1);
      S.pe.sujo = true; fecharModal(); desenharPe(); desenharPeLateral();
    };
  }
  const QUALIF_TXT = '{{cliente_nome}}, {{cliente_nacionalidade}}, {{cliente_estado_civil}}, {{cliente_profissao}}, portador(a) do RG nº {{cliente_rg}}, inscrito(a) no CPF sob o nº {{cliente_cpf}}, residente e domiciliado(a) em {{cliente_endereco}}, bairro {{cliente_bairro}}, {{cliente_cidade}}/{{cliente_uf}}, CEP {{cliente_cep}}, telefone {{cliente_telefone}}';
  const QUALIF_CAMPOS = ['cliente_nome', 'cliente_genero', 'cliente_nacionalidade', 'cliente_estado_civil', 'cliente_profissao', 'cliente_rg', 'cliente_cpf', 'cliente_endereco', 'cliente_bairro', 'cliente_cidade', 'cliente_uf', 'cliente_cep', 'cliente_telefone'];
  function campoPadraoJS(k) {
    const T = { cliente_nome: ['Nome completo', 'texto', 'Cliente', 'nome'], cliente_genero: ['Gênero (ajusta o/a no texto)', 'opcoes', 'Cliente'],
      cliente_nacionalidade: ['Nacionalidade', 'texto', 'Cliente', 'minusculo'], cliente_estado_civil: ['Estado civil', 'opcoes', 'Cliente'],
      cliente_profissao: ['Profissão', 'texto', 'Cliente', 'minusculo'], cliente_rg: ['RG / Identidade', 'texto', 'Cliente'], cliente_cpf: ['CPF', 'cpf', 'Cliente'],
      cliente_endereco: ['Endereço (rua, nº)', 'texto', 'Endereço', 'nome'], cliente_bairro: ['Bairro', 'texto', 'Endereço', 'nome'],
      cliente_cidade: ['Cidade', 'texto', 'Endereço', 'nome'], cliente_uf: ['UF', 'uf', 'Endereço'], cliente_cep: ['CEP', 'cep', 'Endereço'],
      cliente_telefone: ['Telefone', 'telefone', 'Contato'] }[k] || [k, 'texto', 'Geral'];
    const c = { chave: k, rotulo: T[0], tipo: T[1], grupo: T[2], padrao: '' };
    if (T[3]) c.formato = T[3];
    if (k === 'cliente_estado_civil') c.opcoes = ['solteiro(a)', 'casado(a)', 'divorciado(a)', 'separado(a) judicialmente', 'viúvo(a)', 'em união estável'];
    if (k === 'cliente_genero') c.opcoes = ['Masculino', 'Feminino'];
    if (k === 'cliente_nacionalidade') c.padrao = 'brasileiro(a)';
    if (k === 'cliente_cidade') c.padrao = 'Mossoró';
    if (k === 'cliente_uf') c.padrao = 'RN';
    return c;
  }
  function peExcluir() {
    const s = S.pe.sel; if (!s) return;
    S.pe.docs[s.d].caixas.splice(s.i, 1); S.pe.sel = null; S.pe.sujo = true; desenharPe(); desenharPeLateral();
  }
  function peDuplicar() {
    const cx = caixaSel(); if (!cx) return;
    const s = S.pe.sel; const n = { ...cx, y: cx.y + cx.h + 4 };
    S.pe.docs[s.d].caixas.push(n); S.pe.sel = { d: s.d, i: S.pe.docs[s.d].caixas.length - 1 }; desenharPe(); desenharPeLateral();
  }
  function peSet(prop, v) {
    const cx = caixaSel(); if (!cx) return;
    if (['tam', 'lh'].includes(prop)) v = v === '' ? null : +v;
    cx[prop] = v; S.pe.sujo = true;
    if (prop === 'texto') desenharPe();
  }
  function peFiltro(f) {
    const cx = caixaSel(); if (!cx) return;
    const ks = tokensDe(cx.texto); if (ks.length !== 1) return;
    cx.texto = '{{' + ks[0] + (f ? '|' + f : '') + '}}'; S.pe.sujo = true;
  }
  function peDoc(di, prop, v) { S.pe.docs[di][prop] = v; S.pe.sujo = true; if (prop === 'nome') desenharPe(); }
  function peCampo(k, prop, v) { const c = S.pe.campos[k]; if (!c) return; c[prop] = v; S.pe.sujo = true; if (prop === 'rotulo') desenharPe(); }
  function desenharPeLateral() {
    const pe = S.pe;
    const pastas = (sel) => S.bib.categorias.map((c) => `<option ${c.nome === sel ? 'selected' : ''}>${esc(c.nome)}</option>`).join('') +
      (S.bib.categorias.some((c) => c.nome === sel) ? '' : `<option selected>${esc(sel)}</option>`);
    let h = `<label class="rot-sec">${pe.docs.length > 1 ? 'DOCUMENTOS ENCONTRADOS' : 'FICHA DO MODELO'}</label>`;
    pe.docs.forEach((d, di) => {
      h += `<div class="pg-docbox">${pe.docs.length > 1 ? `<div class="n">${di + 1}</div>` : ''}<div style="flex:1">
        <div class="campo"><label>Nome</label><input value="${esc(d.nome)}" oninput="App.peDoc(${di},'nome',this.value)"></div>
        <div class="duas"><div class="campo"><label>Pasta</label><input list="dlPastasPe" value="${esc(d.categoria)}" oninput="App.peDoc(${di},'categoria',this.value)"></div>
        <div class="campo"><label>Área</label><input value="${esc(d.area || '')}" oninput="App.peDoc(${di},'area',this.value)"></div></div>
        <label class="caixa"><input type="checkbox" ${d.valores_maiusculos ? 'checked' : ''} onchange="App.peDoc(${di},'valores_maiusculos',this.checked)"><span>Preencher em CAIXA ALTA</span></label>
        <div class="dica" style="margin-top:2px">${d.paginas.length} página(s) · ${d.caixas.length} campo(s)</div></div></div>`;
    });
    h += `<datalist id="dlPastasPe">${S.bib.categorias.map((c) => `<option value="${esc(c.nome)}">`).join('')}</datalist>`;
    if (pe.modo === 'importar' && pe.docs.length > 1) {
      h += `<div class="pg-docbox kit"><div style="flex:1"><label class="caixa"><input type="checkbox" ${pe.kit.criar ? 'checked' : ''} onchange="App._S.pe.kit.criar=this.checked">
        <span><b>Montar um kit</b> com os ${pe.docs.length} documentos</span></label>
        <div class="campo"><label>Nome do kit</label><input value="${esc(pe.kit.nome)}" oninput="App._S.pe.kit.nome=this.value"></div></div></div>`;
    }
    const cx = caixaSel();
    h += `<label class="rot-sec">CAMPO SELECIONADO</label>`;
    if (!cx) h += `<p class="dica" style="margin-top:0">Clique num retângulo amarelo na página para ajustar. Para criar, use <b>＋ Novo campo</b>.</p>`;
    else {
      const ks = tokensDe(cx.texto);
      const f = (String(cx.texto).match(/\|(\w+)\}\}/) || [])[1] || '';
      const c1 = ks.length === 1 ? pe.campos[ks[0]] : null;
      h += `<div class="pg-sel"><div class="pg-sel-nome">${esc(rotuloCaixa(cx))}</div>
        <button class="bt bt-cinza bt-mini" onclick="App.escolherCampoCaixa()">Trocar o campo…</button>
        ${c1 ? `<div class="campo"><label>Nome no formulário</label><input value="${esc(c1.rotulo)}" oninput="App.peCampo('${esc(c1.chave)}','rotulo',this.value)"></div>
        <div class="duas"><div class="campo"><label>Tipo</label><select onchange="App.peCampo('${esc(c1.chave)}','tipo',this.value)">${TIPOS.map(([v, r]) => `<option value="${v}" ${v === c1.tipo ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
        <div class="campo"><label>Formato</label><select onchange="App.peFiltro(this.value)"><option value="">Normal</option>
          ${[['maiusculo', 'CAIXA ALTA'], ['curta', 'Data 17/10/2026'], ['semana', 'Data com dia da semana'], ['numero', 'Valor sem extenso'], ['dois', 'Número 05']].map(([v, r]) => `<option value="${v}" ${v === f ? 'selected' : ''}>${r}</option>`).join('')}</select></div></div>` :
        `<div class="campo"><label>Texto (avançado)</label><textarea rows="4" oninput="App.peSet('texto',this.value)" style="font-size:12px">${esc(cx.texto)}</textarea></div>`}
        <div class="duas"><div class="campo"><label>Tamanho da letra</label><input type="number" step="0.5" min="5" max="20" value="${cx.tam || 9}" onchange="App.peSet('tam',this.value)"></div>
        <div class="campo"><label>Alinhamento</label><select onchange="App.peSet('alinhar',this.value)">${[['esquerda', 'Esquerda'], ['centro', 'Centro'], ['direita', 'Direita'], ['justificado', 'Justificado']].map(([v, r]) => `<option value="${v}" ${v === cx.alinhar ? 'selected' : ''}>${r}</option>`).join('')}</select></div></div>
        <div class="duas"><div class="campo"><label>Várias linhas: altura de cada (pt)</label><input type="number" step="0.5" min="0" value="${cx.lh || ''}" placeholder="uma linha" onchange="App.peSet('lh',this.value)"></div><div></div></div>
        <label class="caixa"><input type="checkbox" ${cx.negrito ? 'checked' : ''} onchange="App.peSet('negrito',this.checked)"><span>Negrito</span></label>
        <label class="caixa"><input type="checkbox" ${cx.cobrir ? 'checked' : ''} onchange="App.peSet('cobrir',this.checked)"><span>Cobrir o que está embaixo (fundo branco)</span></label>
        <div style="display:flex;gap:8px;margin-top:8px"><button class="bt bt-cinza bt-mini" onclick="App.peDuplicar()">⧉ Duplicar</button><button class="bt bt-perigo bt-mini" onclick="App.peExcluir()">Remover</button></div></div>`;
    }
    $('#pgLateral').innerHTML = h;
  }
  function camposDoDoc(d) {
    const usados = new Set(); d.caixas.forEach((cx) => tokensDe(cx.texto).forEach((k) => usados.add(k)));
    if (d.caixas.some((cx) => /\w\([aA]\)/.test(cx.texto)) || usados.has('cliente_nome')) usados.add('cliente_genero');
    return [...usados].map((k) => S.pe.campos[k] || campoPadraoJS(k));
  }
  async function salvarPaginas() {
    const pe = S.pe;
    try {
      let r;
      if (pe.modo === 'importar') {
        const docs = pe.docs.map((d) => ({ nome: d.nome, categoria: d.categoria || 'Outros', area: d.area, descricao: d.descricao || '',
          paginas: d.paginas, caixas: d.caixas, campos: camposDoDoc(d), genero: 'cliente_genero', valores_maiusculos: !!d.valores_maiusculos }));
        r = await api('api/importar/salvar-paginas', { json: { token: pe.token, documentos: docs, kit: pe.kit, tamanhos: pe.tamanhos, palavras: pe.palavras } });
      } else {
        const d = pe.docs[0];
        const corpo = semExtras(d); delete corpo.itens;
        corpo.paginas = S.atualPaginas || d.paginas_originais;
        corpo.caixas = d.caixas; corpo.campos = camposDoDoc(d);
        r = await api('api/modelo', { json: { ...corpo, paginas: d._paginasMeta, html: '' } });
      }
      toast(`Salvo: <b>${esc(r.modelo.nome)}</b> em <b>${esc(r.modelo.categoria)}</b>.`);
      S.pe = null; await carregar();
      if (S.fila.length) { proximoDaFila(); return; }
      abrirModelo(r.modelo.id);
    } catch (e) { toast('Não salvei: ' + esc(e.message), { erro: true }); }
  }
  async function sairPaginas() {
    if (S.pe && S.pe.sujo && !await confirmar('Sair sem salvar', 'As alterações serão perdidas.', 'Sair sem salvar')) return;
    const volta = S.pe ? S.pe.voltar : 'v-inicio'; S.pe = null; S.fila = [];
    if (volta === 'v-preencher' && S.atual) abrirModelo(S.atual.id); else irInicio();
  }

  // ------------------------------------------------------------ navegação e filtros
  function irInicio() { mostrarTela('v-inicio'); if (S.bib) desenharInicio(); }
  function filtroPasta(p) { S.filtro.pasta = p; desenharInicio(); }
  function filtroArea(a) { S.filtro.area = a; desenharInicio(); }
  let tBusca;
  function filtrar() { clearTimeout(tBusca); tBusca = setTimeout(() => { S.filtro.busca = $('#busca').value.trim(); desenharGrade(); }, 120); }
  function limparFiltros() { S.filtro = { pasta: '', area: '', busca: '', aba: S.filtro.aba }; $('#busca').value = ''; desenharInicio(); }
  function trocarAba(b) { $$('#abasInicio .aba').forEach((x) => x.classList.toggle('ativa', x === b)); S.filtro.aba = b.dataset.aba; desenharGrade(); }
  async function novaPasta() {
    const n = await perguntar('Nova pasta', 'Nome da pasta', '');
    if (!n) return;
    await api('api/categoria', { json: { nome: n } }); toast(`Pasta <b>${esc(n)}</b> criada.`); carregar();
  }
  async function renomearPasta(cat) {
    const n = await perguntar('Renomear pasta', 'Novo nome da pasta', cat);
    if (!n || n === cat) return;
    await api('api/categoria', { json: { de: cat, para: n } });
    if (S.filtro.pasta === cat) S.filtro.pasta = n;
    toast('Pasta renomeada.'); carregar();
  }
  function abrirPasta(pasta, categoria) { api('api/abrir', { json: pasta ? { pasta } : { categoria } }).catch((e) => toast(esc(e.message), { erro: true })); }

  // ------------------------------------------------------------ atualização do programa
  const UPD = { info: null };
  function pintarVersao() {
    const b = $('#btVersao'); if (!b) return;
    const i = UPD.info || {};
    if (i.tem_nova) { b.className = 'bt bt-ouro bt-versao'; b.innerHTML = '⬆ Atualizar <small>(nova versão)</small>'; b.title = `Versão ${i.nova} disponível — você está na ${i.atual}`; }
    else { b.className = 'bt bt-claro bt-versao'; b.textContent = '🔄 Versão ' + (UPD.atual || ''); b.title = 'Ver se há versão nova do programa'; }
  }
  async function iniciarVersao() {
    try {
      const v = await api('api/versao'); UPD.atual = v.atual; pintarVersao();
      if (v.reiniciou && v.notas && v.notas.length) {
        modal(cabModal('✅ Programa atualizado — versão ' + esc(v.atual)) + `<div class="m-corpo"><p>O que mudou:</p><ul>${v.notas.map((n) => `<li>${esc(n)}</li>`).join('')}</ul></div>
          <div class="m-pe"><button class="bt bt-ouro" onclick="App.fecharModal()">OK</button></div>`);
      }
    } catch (e) { return; }
    try { UPD.info = await api('api/versao?checar=1'); if (!UPD.info.erro) pintarVersao(); } catch (e) { /* sem internet: segue normal */ }
  }
  async function clicarVersao() {
    const b = $('#btVersao'); b.disabled = true; const rot = b.innerHTML; b.textContent = 'Verificando…';
    try { UPD.info = await api('api/versao?checar=1'); } catch (e) { UPD.info = { erro: e.message }; }
    b.disabled = false; b.innerHTML = rot; pintarVersao();
    const i = UPD.info;
    if (i.erro) return toast('Não consegui verificar agora. Confira a internet e tente de novo.<br><small>' + esc(i.erro) + '</small>', { erro: true });
    if (!i.tem_nova) return toast(`Você já está na versão mais recente (${esc(i.atual)}).`);
    const preenchendo = $('#v-preencher').classList.contains('ativa');
    modal(cabModal('⬆ Nova versão ' + esc(i.nova)) + `<div class="m-corpo">
      <p>Você está na versão <b>${esc(i.atual)}</b>.</p>
      ${i.notas && i.notas.length ? `<p>O que muda:</p><ul>${i.notas.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : ''}
      <p class="dica">Só o programa é trocado. Seus modelos, clientes, timbrados, documentos gerados e configurações continuam como estão. O programa fecha e abre de novo sozinho.</p>
      ${preenchendo ? '<p class="dica" style="color:#b45309">⚠️ Você está com um documento aberto. Exporte ou salve antes de atualizar.</p>' : ''}
      </div><div class="m-pe"><button class="bt bt-cinza" onclick="App.fecharModal()">Agora não</button><button class="bt bt-ouro" id="mAtualizar" onclick="App.atualizarAgora()">Atualizar agora</button></div>`);
  }
  async function atualizarAgora() {
    const alvo = UPD.info && UPD.info.nova;
    modal(cabModal('Atualizando…') + `<div class="m-corpo"><p>⏳ Baixando e instalando a versão ${esc(alvo || '')}.</p><p class="dica">Não feche o programa. Ele vai reabrir sozinho em alguns segundos.</p></div>`);
    try { await api('api/atualizar', { method: 'POST' }); } catch (e) {
      modal(cabModal('Não deu para atualizar') + `<div class="m-corpo"><p>${esc(e.message)}</p><p class="dica">Nada foi alterado. Tente de novo mais tarde.</p></div><div class="m-pe"><button class="bt bt-ouro" onclick="App.fecharModal()">OK</button></div>`);
      return;
    }
    // se estiver no navegador, espera a nova versão subir e recarrega
    const t0 = Date.now();
    const espera = async () => {
      if (Date.now() - t0 > 60000) { location.reload(); return; }
      try { const v = await (await fetch('api/versao', { cache: 'no-store' })).json(); if (v.atual === alvo) { location.reload(); return; } } catch (e) { /* ainda reiniciando */ }
      setTimeout(espera, 1000);
    };
    setTimeout(espera, 2500);
  }

  // ------------------------------------------------------------ início
  window.App = {
    clicarVersao, atualizarAgora,
    emBranco, confirmarBranco, ajustarTexto, abrirAjuste, ajCmd, salvarAjuste, desfazerAjustes, ajFerramenta, ajNegrito, ajTam, ajExcluir,
    abrirEditorPaginas, peZoom, peTexto, peDesenhar, peExcluir, peDuplicar, peSet, peFiltro, peDoc, peCampo, escolherCampoCaixa, salvarPaginas, sairPaginas,
    irInicio, filtrar, filtroPasta, filtroArea, limparFiltros, trocarAba, novaPasta, renomearPasta, abrirPasta, menuModelo,
    abrirModelo, alternarRec, clicarCard, kpi, kitMarcar, kitTodos, alternarGrupo, limparForm, trocarTimbrado, zoom, exportar, imprimir, editarAtual,
    carregarCliente, salvarCliente, novoCliente, exportarSeparados, lerDocumentos, aplicarOcr, escolherLeitura, lerPeloCelular, abrirClientes, usarCliente, excluirCliente, escolherCliente, abrirDocCliente, excluirDocCliente,
    abrirEditor, sairEditor, salvarEditor, cmd, alinhar, estiloBloco, virarCampo, inserirCampo, inserirQuebra, inserirChip, novoCampoLista,
    alternarLc, lcSet, excluirCampo, edTimbrado, edTimbOp, edVisual, kitSet, kitAdd, kitDel, kitMov,
    abrirImportar, enviarModelos, abrirDrive, driveMarcar, driveFiltrar, driveImportar, abrirTimbrados, enviarTimbrado, editarTimbrado, abrirConfig, fecharModal, _S: S,
  };
  S.valores = lsGet('bm_valores', {});
  // a data do documento sempre começa no dia de hoje
  delete S.valores.data_documento;
  S.zoom = lsGet('bm_zoom', 1);
  iniciarVersao();
  carregar().catch((e) => toast('Erro ao carregar a biblioteca: ' + esc(e.message), { erro: true, tempo: 10000 }));
  window.addEventListener('resize', () => { if ($('#v-preencher').classList.contains('ativa')) caberNaLargura(); });
})();
